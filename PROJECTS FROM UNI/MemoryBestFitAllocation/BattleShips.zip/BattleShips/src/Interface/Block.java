package Interface;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JLabel;

/**
 * Block class allows for the creation of ship blocks. Used for the purpose of setting up ships on a grid.
 * 
 * @author Team 1-M.
 * 
 */
public class Block extends JLabel {

    ArrayList<Block> ships = new ArrayList<Block>();

    private String shipName;
    private int blocksPerShip;
    private int numberOfShips;
    private Color blockColour;
    private int initialNumberOfShips;

    private JLabel numberOfShipsLabel;
    public int columnCount;

    private Point startPoint;
    private Point endPoint;

    public List<Rectangle> cells;

    private boolean isHorizontal = true;

    private Block fiveShip;
    private Block fourShip;
    private Block threeShip;
    private Block twoShip;

    /**
     * Constructs a Block object to initialise the ships for the game.
     */
    public Block() {
        setupBlocks();
    }

    /**
     * Constructs a Block (Ship) with the number of blocks per ship and the quantity of the ships that will be
     * available. Assigns a name to each ship depending on the number of blocks per ship.
     * 
     * @param blocks
     *            The size of the block(ship).
     * @param no
     *            The number of blocks(ships) of this size.
     */
    public Block(int blocks, int no) {

        blocksPerShip = blocks;
        numberOfShips = no;

        initialNumberOfShips = no;

        numberOfShipsLabel = new JLabel("Number of ships remaining: "
                + String.valueOf(numberOfShips));

        if (blocksPerShip == 2) {
            shipName = "Patrol boat";
        }
        else if (blocksPerShip == 3) {
            shipName = "Submarine";
        }

        else if (blocksPerShip == 4) {
            shipName = "Battleship";
        }
        else if (blocksPerShip == 5) {
            shipName = "Aircraft Carrier";
        }

        columnCount = blocksPerShip;

        cells = new ArrayList<>();

    }

    /**
     * Initialises the blocks(ships) for the game with their respective size and quantity.
     */
    private void setupBlocks() {

        fiveShip = new Block(5, 1);
        fourShip = new Block(4, 1);
        threeShip = new Block(3, 2);
        twoShip = new Block(2, 1);

        ships.add(fiveShip);
        ships.add(fourShip);
        ships.add(threeShip);
        ships.add(twoShip);

    }

    /**
     * Resets the blocks(ships) to their initial quantity.
     */
    public void resetBlocks() {

        fiveShip.setNumberOfShips(fiveShip.getInitialNumberOfShips());
        fourShip.setNumberOfShips(fourShip.getInitialNumberOfShips());
        threeShip.setNumberOfShips(threeShip.getInitialNumberOfShips());
        twoShip.setNumberOfShips(twoShip.getInitialNumberOfShips());

    }

    /**
     * Gets the list of blocks(ships) for the game.
     * 
     * @return an ArrayList of blocks(ships).
     */
    public ArrayList<Block> getShips() {
        return ships;
    }

    /**
     * Returns the component to choose between horizontal or vertical alignment.
     * 
     * @return a JComboBox with the horizontal and vertical options.
     */
    public JComboBox<String> getComboBox() {

        String[] stringOptions = {"Horizontal", "Vertical" };

        final JComboBox<String> optionBox = new JComboBox<String>(stringOptions);
        optionBox.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                if (optionBox.getSelectedItem().equals("Horizontal")) {

                    isHorizontal = true;
                    repaint();
                }
                else {

                    isHorizontal = false;
                    repaint();
                }

            }

        });

        return optionBox;

    }

    /**
     * Check if a block(ship) is horizontal.
     * 
     * @return true if it's horizontal. false if it's vertical.
     */
    public boolean getIsHorizontal() {
        return isHorizontal;
    }

    /**
     * A method to set the horizontal or vertical alignment.
     * 
     * @param newValue
     *            Boolean value to set a block to horizontal or vertical (true: horizontal, false: vertical).
     */
    public void setIsHorizontal(Boolean newValue) {
        isHorizontal = newValue;
    }

    /**
     * Returns a label which displays the number of blocks(ships) available in a particular size.
     * 
     * @return a JLabel for the number of blocks(ships) available.
     */
    public JLabel getNumberOfShipsLabel() {

        return numberOfShipsLabel;
    }

    /**
     * Sets the number of blocks(ships) for a particular size ship.
     * 
     * @param newNumberOfShips
     *            how many blocks(ships) are available of the particular size ship.
     */
    public void setNumberOfShips(int newNumberOfShips) {
        numberOfShips = newNumberOfShips;
    }

    /**
     * Assigns a block with a start and end point on the grid once they have been placed.
     * 
     * @param newStart
     *            Start point.
     * @param newEnd
     *            End point.
     */
    public void setBlockPos(Point newStart, Point newEnd) {
        startPoint = newStart;
        endPoint = newEnd;

    }

    /**
     * Returns the start position of a block(ship).
     * 
     * @return start coordinate of the block(ship) on the grid.
     */
    public Point getStartPos() {
        return startPoint;
    }

    /**
     * Returns the end position of a block(ship).
     * 
     * @return end coordinate of the block(ship) on the grid.
     */
    public Point getEndPos() {
        return endPoint;
    }

    /**
     * Returns the name of a ship.
     * 
     * @return String with the ship name.
     */
    public String getShipName() {
        return shipName;
    }

    // Paints the blocks(ships).
    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();

        if (cells.isEmpty()) {

            for (int col = 0; col < columnCount; col++) {
                if (isHorizontal) {
                    Rectangle cell = new Rectangle(60 + (col * 20), 45, 20, 20);
                    cells.add(cell);
                }
                else {
                    Rectangle cell = new Rectangle(60, 20 + (col * 20), 20, 20);
                    cells.add(cell);
                }
            }
        }

        for (Rectangle cell : cells) {
            if (this.getBlocksPerShip() == 5) {
                g2d.setColor(Color.RED);
                this.setBlockColour(Color.RED);

            }
            else if (this.getBlocksPerShip() == 4) {
                g2d.setColor(Color.BLUE);
                this.setBlockColour(Color.BLUE);

            }
            else if (this.getBlocksPerShip() == 3) {
                g2d.setColor(Color.GREEN);
                this.setBlockColour(Color.GREEN);

            }
            else if (this.getBlocksPerShip() == 2) {
                g2d.setColor(Color.ORANGE);
                this.setBlockColour(Color.ORANGE);

            }
            g2d.fill(cell);

            g2d.setColor(Color.BLACK);
            g2d.draw(cell);

        }
        cells.clear();
    }

    /**
     * Returns the number of blocks(ships) available in a particular size.
     * 
     * @return number of blocks(ships) available.
     */
    public int getNumberOfShips() {
        return numberOfShips;
    }

    /**
     * Returns the size of the block(ship)
     * 
     * @return number of squares used to form the block(ship).
     */
    public int getBlocksPerShip() {
        return blocksPerShip;
    }

    /**
     * Decrements the amount of blocks(ships) left to place.
     */
    public void decreaseShips() {
        numberOfShips--;
    }

    /**
     * Increments the amount of blocks(ships) left to place.
     */
    public void increaseShips() {
        numberOfShips++;
    }

    /**
     * Sets the colour of a block(ship).
     * 
     * @param newColour
     *            The new colour of the block(ship).
     */
    public void setBlockColour(Color newColour) {
        blockColour = newColour;
    }

    /**
     * Returns the colour of a block(ship).
     * 
     * @return colour of a block(ship).
     */
    public Color getBlockColour() {
        return blockColour;
    }

    /**
     * Updates the JLabel for the number of blocks(ships) left of that particular size.
     * 
     * @param newNumberOfShips
     *            New number of blocks(ships) available for the particular sized ship.
     */
    public void updateLabel(int newNumberOfShips) {
        numberOfShipsLabel.setText("Number of ships remaining: " + String.valueOf(numberOfShips));
    }

    /**
     * Returns the initial quantity of ships at start of game
     * 
     * @return initial quantity of ships
     */
    public int getInitialNumberOfShips() {
        return initialNumberOfShips;
    }

}
