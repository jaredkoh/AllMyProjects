package Interface;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import GridOutlines.PlayerGridHolder;
import Server.GamePlayerClient;

/**
 * Class Grid that displays the "Game Screen".
 *
 * @author Team 1-M.
 *
 */
public class Grid extends JFrame {

    private Player1Pane player1Pane;
    private Player2Pane player2Pane;
    private JTextArea chatBox;
    public JLabel statusLabel = new JLabel();

    GamePlayerClient gamePlayerClient;

    /**
     * Constructs a Grid with Player1Pane and Player2Pane.
     *
     * @param p1pane
     *            Player1Pane.
     * @param p2pane
     *            Player2Pane.
     * @param inputGamePlayerClient
     *            GamePlayerClient.
     */
    public Grid(Player1Pane p1pane, Player2Pane p2pane, GamePlayerClient inputGamePlayerClient) {

        // Title with player and opponent nicknames.
        super("Battleships - " + p1pane.getPlayer().getNickname() + " v.s. "
                + p2pane.getPlayer().getNickname());

        player1Pane = p1pane;
        player2Pane = p2pane;

        player2Pane.setGrid(this);

        this.gamePlayerClient = inputGamePlayerClient;

        // Initialises components for game and chat.
        GridLayout gameLayout = new GridLayout(1, 3);
        gameLayout.setHgap(30);
        setLayout(gameLayout);

        PlayerGridHolder playerGridHolder1 = new PlayerGridHolder(player1Pane);
        PlayerGridHolder playerGridHolder2 = new PlayerGridHolder(player2Pane);

        JPanel panel = new JPanel();
        chatBox = new JTextArea();
        chatBox.setEditable(false);
        final JTextField messageField = new JTextField();
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setViewportView(chatBox);
        scrollPane.getVerticalScrollBar().addAdjustmentListener(new AdjustmentListener() {

            @Override
            public void adjustmentValueChanged(AdjustmentEvent e) {
                e.getAdjustable().setValue(e.getAdjustable().getMaximum());

            }

        });

        // When enter is pressed, the message from the field is sent and appears in the chatbox
        messageField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent evt) {
                if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
                    if (!messageField.getText().equals("")) {
                        DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
                        Date dateobj = new Date();
                        String chatText = messageField.getText();
                        // Message is 100 char max.
                        if (chatText.length() < 100) {
                            chatBox.append("\n" + df.format(dateobj) + " - <"
                                    + player1Pane.getPlayer().getNickname() + "> : " + chatText);
                            gamePlayerClient.sendData(4, messageField.getText());
                            messageField.setText("");
                            messageField.requestFocus();
                        }
                        else {
                            JOptionPane.showMessageDialog(null, "Message is too long",
                                    "100 characters max", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }

        });
        messageField.setText("Type here to chat!");
        messageField.setToolTipText("Type here to chat!");

        messageField.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                messageField.setText("");
            }
        });

        chatBox.setLineWrap(true);
        chatBox.setWrapStyleWord(true);

        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panel.setLayout(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(messageField, BorderLayout.SOUTH);
        panel.add(statusLabel, BorderLayout.NORTH);

        add(playerGridHolder1);
        add(panel);
        add(playerGridHolder2);

        player1Pane.setStatus(false);

        // Makes opponent client aware that the current player is terminating the game.
        WindowListener playerOut = new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
                gamePlayerClient.sendData(0, "closing");
                System.exit(0);
            }
        };

        this.setMinimumSize(new Dimension(1300, 420));
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(playerOut);

        pack();
        setVisible(true);

        player2Pane.updateStatusLabel();
    }

    /**
     * Returns the chat box.
     *
     * @return The chat box.
     */
    public JTextArea getChatBox() {
        return chatBox;
    }

}
