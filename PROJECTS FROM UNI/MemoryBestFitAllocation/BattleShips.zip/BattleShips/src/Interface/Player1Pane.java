package Interface;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;

import Models.Board;
import Models.Player;

/**
 * Player1Pane class, the grid that the player will start with and take to the "Grid Class"(Game Screen).
 *
 * @author Team 1-M.
 *
 */
public class Player1Pane extends GridPane {

    private List<Rectangle> initialBlackCells;
    private Graphics2D g2f;

    private Board p1Board;
    private Player player1;
    private boolean status = true;

    private boolean isEmpty;

    /**
     * Constructs Player1Pane with a player
     *
     * @param p1
     *            Player.
     */
    public Player1Pane(Player p1) {

        player1 = p1;

        initialBlackCells = new ArrayList<>();

        p1Board = p1.getBoard();

        isEmpty = p1Board.isEmpty();

    }

    /**
     * Checks if the client sets a ship or not.
     *
     * @return boolean for if the client set a ship or not.
     */
    public boolean isEmpty() {
        isEmpty = p1Board.isEmpty();
        return isEmpty;
    }

    /**
     * Sets the status to allow Player1Pane to store the data(selected coordinate) from opponent.
     *
     * @param inputStatus
     */
    public void setStatus(boolean inputStatus) {
        this.status = inputStatus;
    }

    /**
     * Updates the Player1Board with the received opponent selected coordinates.
     *
     * @param inputPoint
     *            opponent coordinates.
     */
    public void updateBoard(Point inputPoint) {

        int x = inputPoint.x;
        int y = inputPoint.y;
        if (p1Board.getSquare(x, y).isShip()) {
            p1Board.bomb(x, y);
            p1Board.getSquare(x, y).removeShip();
            player1.removeShipSquare();
        }

        p1Board.display(x, y);
        repaint();

    }

    // Paints the ships onto the grid depending on whether it has been hit, miss or only set (during setup).
    @Override
    protected void paintComponent(Graphics g) {

        super.paintComponent(g);
        g2f = (Graphics2D) g.create();

        for (int row = 0; row < rowCount; row++) {
            for (int col = 0; col < columnCount; col++) {
                int index = (row * rowCount) + col;
                if (p1Board.getSquare(col, row).isBombed()
                        && p1Board.getSquare(col, row).isDisplay()) {

                    // Fire animation.
                    ImageIcon image = new ImageIcon("Images/hit.gif");
                    Point p = cells.get(index).getLocation();
                    g.drawImage(image.getImage(), p.x, p.y, getWidth() / 10, getHeight() / 10,
                            null, this);

                }
                else if (p1Board.getSquare(col, row).isDisplay()) {

                    // Water animation.
                    ImageIcon image = new ImageIcon("Images/miss.gif");
                    Point p = cells.get(index).getLocation();
                    g.drawImage(image.getImage(), p.x, p.y, getWidth() / 10, getHeight() / 10,
                            null, this);

                }
                else if (p1Board.getSquare(col, row).isShip()) {

                    // Block colour.
                    this.initialBlackCells.add(cells.get(index));
                    g2f.setColor(p1Board.getSquare(col, row).getOwnerBlock().getBlockColour());
                    g2f.fill(this.initialBlackCells.get(this.initialBlackCells.size() - 1));

                }

            }

        }

        drawGrid();
        g2f.dispose();

    }

    /**
     * Resets the board.
     */
    public void resetBoard() {

        for (int row = 0; row < rowCount; row++) {
            for (int col = 0; col < columnCount; col++) {

                if (p1Board.getSquare(row, col).isShip()) {
                    p1Board.getSquare(row, col).removeShip();
                }

            }
        }

    }

    /**
     * Returns the player of Player1Pane.
     *
     * @return Player 1.
     */
    public Player getPlayer() {
        return player1;
    }

    /**
     * Sets the pane as empty or not empty.
     *
     * @param newValue
     *            boolean value for if the pane is empty or not.
     */
    public void setIsEmpty(boolean newValue) {
        isEmpty = newValue;
    }

}
