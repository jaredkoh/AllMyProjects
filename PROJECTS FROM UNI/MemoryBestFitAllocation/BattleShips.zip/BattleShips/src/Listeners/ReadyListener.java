package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import Interface.Block;
import Models.Player;
import Server.GamePlayerClient;

/**
 * ReadyListener Class for the ready button.
 *
 * @author Team 1-M.
 *
 */
public class ReadyListener implements ActionListener {

    private JTextField nickname;
    private String nicknameField;
    private Player player;
    private GamePlayerClient gamePlayerClient;
    private JButton resetButton;
    private JButton undoButton;
    private JButton playButton;
    private JButton readyButton;
    private ArrayList<Block> ships;
    private DragListener blockDrag;

    /**
     * Constructs a ReadyListener
     *
     * @param name
     * @param nameField
     * @param p
     * @param client
     * @param reset
     * @param undo
     * @param play
     * @param ready
     * @param shipList
     * @param drag
     */
    public ReadyListener(JTextField name, String nameField, Player p, GamePlayerClient client,
            JButton reset, JButton undo, JButton play, JButton ready, ArrayList<Block> shipList,
            DragListener drag) {

        nickname = name;
        nicknameField = nameField;
        player = p;
        gamePlayerClient = client;
        resetButton = reset;
        undoButton = undo;
        playButton = play;
        readyButton = ready;
        ships = shipList;
        blockDrag = drag;

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!nickname.getText().equals("") && nickname.getText() != null
                && !nickname.getText().equals(nicknameField)) {

            if (shipsReady()) {
                // Switch number 1 means the sending data will be of type Player.
                player.setNickname(nickname.getText());
                gamePlayerClient.sendData(1, player);

                // Disables all other buttons when Ready clicked.
                nickname.setEnabled(false);
                readyButton.setEnabled(false);
                resetButton.setEnabled(false);
                undoButton.setEnabled(false);
                playButton.setEnabled(true);

                // Removes block dragging feature when Ready clicked.
                for (int i = 0; i < ships.size(); i++) {
                    ships.get(i).removeMouseListener(blockDrag);
                    ships.get(i).removeMouseMotionListener(blockDrag);
                }
            }
            else {
                JOptionPane.showMessageDialog(null, "Please place all your ships");
            }

        }

        else {
            JOptionPane.showMessageDialog(null, "Please enter a nickname ");
        }

    }

    /**
     * Checks if all the ships available has been set on the board.
     *
     * @return Boolean value for if the ships are all set on the board or not.
     */
    public boolean shipsReady() {

        for (int i = 0; i < ships.size(); i++) {
            if (ships.get(i).getNumberOfShips() != 0) {
                return false;
            }

        }
        return true;

    }

}
