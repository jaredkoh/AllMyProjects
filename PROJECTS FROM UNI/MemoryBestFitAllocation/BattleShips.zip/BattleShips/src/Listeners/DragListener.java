package Listeners;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import GridOutlines.PlayerGridHolder;
import Interface.Block;
import Interface.Player1Pane;

/**
 * DragListener class for the dragging of the ships.
 *
 * @author Team 1-M.
 *
 */
public class DragListener extends MouseAdapter {

    /**
     * Block that has been clicked to be dragged.
     */
    private Block dragBlock;

    /**
     * Grid panel of a player for setting up ships.
     */
    private Player1Pane playerGrid;

    /**
     * A list of blocks(ships) that are available to be set from the ship storage panel.
     */
    private ArrayList<Block> availableShips = new ArrayList<Block>();
    /**
     * A panel that holds the available ships to be dragged onto the grid during setup.
     */
    private JPanel shipStorage;

    /**
     * Holds the player's setup grid panel and surrounds it with two axis. (A, B, C) and (1, 2, 3).
     */
    private PlayerGridHolder playerGridHolder;

    /**
     * The X coordinate of a point on the grid that the mouse drag is released on.
     */
    private int column;
    /**
     * The Y coordinate of a point on the grid that the mouse drag is released on.
     */
    private int row;

    /**
     * The point (x, y) on the grid that the mouse drag is released on.
     */
    private Point selectedCell;

    /**
     * The number of columns in the grid.
     */
    private static int columnCount = 10;

    /**
     * The number of rows in the grid.
     */
    private static int rowCount = 10;

    /**
     * A ship that is to be placed on the grid when the mouse drag ends.
     */
    private Block newShip;

    /**
     * The last ship that has been placed on the grid.
     */
    private Block lastShipPlaced;

    /**
     * An ordered list of ships that have been placed on the grid.
     */
    private ArrayList<Block> blockPlaceHistory = new ArrayList<Block>();

    private ArrayList<Block> dragHistory = new ArrayList<Block>();

    private JPanel messagePanel;

    /**
     * Constructs a DragListener
     *
     * @param grid
     * @param storedShips
     * @param shipsPane
     * @param holder
     * @param clickedCell
     * @param latestShipPlaced
     * @param blockHistory
     * @param draggedBlocks
     */
    public DragListener(Player1Pane grid, ArrayList<Block> storedShips, JPanel shipsPane,
            PlayerGridHolder holder, Point clickedCell, Block latestShipPlaced,
            ArrayList<Block> blockHistory, ArrayList<Block> draggedBlocks, JPanel topPanel) {

        playerGrid = grid;
        availableShips = storedShips;
        shipStorage = shipsPane;
        playerGridHolder = holder;
        selectedCell = clickedCell;
        lastShipPlaced = latestShipPlaced;
        blockPlaceHistory = blockHistory;
        dragHistory = draggedBlocks;
        messagePanel = topPanel;

    }

    @Override
    public void mousePressed(MouseEvent e) {
        dragBlock = (Block) e.getSource();
    }

    @Override
    public void mouseDragged(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

        // Get current width and height of setup grid.
        int width = playerGrid.getWidth();
        int height = playerGrid.getHeight();

        int cellWidth = width / columnCount;
        int cellHeight = height / rowCount;

        int extraHeight = calculateBlockLocation();

        // Creates a point using column and row for the current positon of the mouse.
        column = (e.getX() - shipStorage.getWidth() - playerGridHolder.getWestHolder().getWidth())
                / cellWidth;
        row = (e.getY() - playerGridHolder.getNorthHolder().getHeight() + messagePanel.getHeight() + extraHeight)
                / cellHeight;

        selectedCell = new Point(column, row);

        if (dragBlock.getNumberOfShips() > 0) {
            if (column < 10 && column >= 0 && row < 10 && row >= 0) {
                // If block is horizontal.
                if (dragBlock.getIsHorizontal() == true) {
                    if (column + dragBlock.getBlocksPerShip() < 11) {

                        // Creates start and end point of block on the grid.
                        Point start = new Point(column, row);
                        Point end = new Point(column + dragBlock.getBlocksPerShip() - 1, row);

                        prepareShip(start, end);
                        setBlock();

                    }
                    else {
                        JOptionPane.showMessageDialog(null, "Invalid ship placement");
                    }
                }
                else {
                    // If block is vertical.
                    if (row + dragBlock.getBlocksPerShip() < 11) {

                        Point start = new Point(column, row);
                        Point end = new Point(column, row + dragBlock.getBlocksPerShip() - 1);

                        prepareShip(start, end);
                        newShip.setIsHorizontal(false);

                        setBlock();

                    }
                    else {
                        JOptionPane.showMessageDialog(null, "Invalid ship placement");
                    }
                }

            }

            playerGrid.repaint();

        }
        else {
            JOptionPane.showMessageDialog(null, "No " + dragBlock.getShipName() + "s left");
        }
    }

    /**
     * Checks whether the ship has been placed in a valid position on the board without overlapping another
     * ship.
     *
     * @return true if the whole ship was placed on an empty space on the grid. false if it was put on a
     *         another ship.
     */
    private boolean isNotOverlapping() {

        for (int j = 0; j < dragBlock.getBlocksPerShip(); j++) {
            // Checks whether any square that the currently dragged block will cover, is already occupied.
            if (dragBlock.getIsHorizontal() == true) {
                if (playerGrid.getPlayer().getBoard().getSquare(selectedCell.x + j, selectedCell.y)
                        .isShip()) {
                    return false;
                }
            }
            else {
                if (playerGrid.getPlayer().getBoard().getSquare(selectedCell.x, selectedCell.y + j)
                        .isShip()) {
                    return false;
                }

            }
        }

        return true;

    }

    /**
     * Prepares the dragged block to be added onto the grid. Sets colour and gives it a start and end point on
     * the board.
     *
     * @param start
     * @param end
     */
    private void prepareShip(Point start, Point end) {
        newShip = new Block(dragBlock.getBlocksPerShip(), dragBlock.getNumberOfShips());
        newShip.setBlockColour(dragBlock.getBlockColour());
        newShip.setBlockPos(start, end);
    }

    /**
     * Sets the dragged block onto the grid as a new ship. Updates player ship squares and the amount of ships
     * left.
     */
    private void setBlock() {

        if (isNotOverlapping()) {
            // Sets block on player's grid and adds ship squares.
            playerGrid.getPlayer().getBoard().setShip(newShip);
            for (int i = 0; i < dragBlock.getBlocksPerShip(); i++) {
                playerGrid.getPlayer().addShipSquare();
            }

            // For undo button.
            updateBlockHistory();

            // Updates the number of blocks left to drag onto the grid.
            dragBlock.decreaseShips();
            dragBlock.updateLabel(dragBlock.getNumberOfShips());

            playerGrid.setIsEmpty(playerGrid.getPlayer().getBoard().isEmpty());

        }
        else {
            JOptionPane.showMessageDialog(null, "There is already a ship in this position");
        }
    }

    /**
     * Keeps history of the last blocks to be dragged onto the grid. Used for Undo button functionality.
     */
    private void updateBlockHistory() {
        lastShipPlaced = newShip;
        blockPlaceHistory.add(lastShipPlaced);
        dragHistory.add(dragBlock);
    }

    /**
     * Calculates the location of the selected block in the ship storage panel.
     *
     * @return extraHeight gap from top of ship storage panel to the location of the selected block.
     */
    private int calculateBlockLocation() {
        int blockCounter = 0;
        int extraHeight = 0;

        for (int i = 0; i < availableShips.size(); i++) {
            if (dragBlock.equals(availableShips.get(i))) {
                break;
            }
            blockCounter++;
        }

        for (int j = 0; j < blockCounter; j++) {
            extraHeight += availableShips.get(j).getHeight();
        }

        return extraHeight;
    }
}
