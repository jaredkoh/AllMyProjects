package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import Interface.Block;
import Interface.Player1Pane;

/**
 * UndoListener class for the undo button.
 *
 * @author Team 1-M.
 *
 */
public class UndoListener implements ActionListener {

    private Player1Pane playerGrid;
    private ArrayList<Block> blockPlaceHistory;
    private ArrayList<Block> dragHistory;
    private ArrayList<Block> ships;

    /**
     * Constructs a UndoListener
     *
     * @param p1pane
     * @param blockHistory
     * @param dragRecord
     * @param shipList
     */
    public UndoListener(Player1Pane p1pane, ArrayList<Block> blockHistory,
            ArrayList<Block> dragRecord, ArrayList<Block> shipList) {
        playerGrid = p1pane;
        blockPlaceHistory = blockHistory;
        dragHistory = dragRecord;
        ships = shipList;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (!playerGrid.isEmpty()) {
            if (!blockPlaceHistory.isEmpty()) {
                if (!dragHistory.isEmpty()) {
                    for (int i = 0; i < ships.size(); i++) {
                        if (ships.get(i).equals(dragHistory.get(dragHistory.size() - 1))) {
                            // To make sure number of ships can never be more than initial amount.
                            if (ships.get(i).getNumberOfShips() < ships.get(i)
                                    .getInitialNumberOfShips()) {
                                ships.get(i).increaseShips();
                                ships.get(i).updateLabel(ships.get(i).getNumberOfShips());
                                dragHistory.remove(dragHistory.size() - 1);
                                break;
                            }
                        }

                    }
                    // Remove ship from player's board.
                    playerGrid.getPlayer().getBoard()
                            .removeShip(blockPlaceHistory.remove(blockPlaceHistory.size() - 1));
                }
            }
        }

        playerGrid.repaint();

    }

}
