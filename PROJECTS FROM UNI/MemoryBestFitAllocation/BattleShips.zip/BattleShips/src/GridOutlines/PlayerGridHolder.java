package GridOutlines;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * PlayerGridHolder class which holds the grid which surrounds it with the North and West panels.
 * @author Team 1-M.
 * 
 */
public class PlayerGridHolder extends JPanel {

    private WestPanel west;
    private NorthPanel north;

    /**
     * Constructs a PlayerGridHolder with the playerGrid.
     * 
     * @param playerGrid
     */
    public PlayerGridHolder(JPanel playerGrid) {

        this.setLayout(new BorderLayout());

        this.add(playerGrid, BorderLayout.CENTER);

        north = new NorthPanel();

        JPanel northHolder = new JPanel(new BorderLayout());
        northHolder.add(north, BorderLayout.CENTER);

        JPanel placeHolderPanel = new JPanel();

        placeHolderPanel.setPreferredSize(new Dimension(29, 21));
        placeHolderPanel.setBackground(Color.GRAY);

        placeHolderPanel.setBorder(BorderFactory.createDashedBorder(Color.BLACK));
        JLabel inBetween = new JLabel(" ");

        placeHolderPanel.add(inBetween);
        northHolder.add(placeHolderPanel, BorderLayout.WEST);

        west = new WestPanel();
        west.setPreferredSize(new Dimension(29, playerGrid.getHeight()));

        this.add(northHolder, BorderLayout.NORTH);
        this.add(west, BorderLayout.WEST);

    }

    /**
     * A method that returns the NorthPanel.
     * 
     * @return JPanel NorthPanel.
     */
    public JPanel getNorthHolder() {
        return north;

    }

    /**
     * A method that returns the WestPanel.
     * 
     * @return JPanel WestPanel.
     */
    public JPanel getWestHolder() {
        return west;

    }

}
