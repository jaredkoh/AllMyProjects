package Models;

import java.io.Serializable;

import Interface.Block;

/**
 * Square class which gives the blocks(ships) properties.
 *
 * @author Team 1-M.
 *
 */
public class Square implements Serializable {

    private static final long serialVersionUID = 1013807061944362971L;
    private boolean isBombed;
    private boolean isShip;
    private boolean display;

    private Block ownerBlock;

    /**
     * Constructs a square which is initially not bombed and has no ship
     */
    public Square() {
        isBombed = false;
        isShip = false;
        display = false;
    }

    /**
     * Assigns the square on the board with a block(ship) that is currently set on it.
     *
     * @param newBlock
     */
    public void setOwnerBlock(Block newBlock) {
        ownerBlock = newBlock;
    }

    /**
     * Returns the block(ship) that is currently set on a square.
     *
     * @return
     */
    public Block getOwnerBlock() {
        return ownerBlock;
    }

    /**
     * Checks if the square is bombed or not.
     *
     * @return true if square is bombed; else false.
     */
    public boolean isBombed() {
        return isBombed;
    }

    /**
     * Checks if the square contains a ship.
     *
     * @return true if a ship(or part of a ship) is in this square; else false.
     */
    public boolean isShip() {
        return isShip;
    }

    /**
     * Checks if the image/colour on the square is shown.
     *
     * @return
     */
    public boolean isDisplay() {
        return display;
    }

    /**
     * Sets this square to bombed.
     */
    public void bomb() {
        isBombed = true;
    }

    /**
     * Makes the square a ship.
     */
    public void setShip() {
        isShip = true;
    }

    /**
     * Removes ship from the square.
     */
    public void removeShip() {
        isShip = false;
        ownerBlock = null;

    }

    /**
     * Sets display to true
     */
    public void display() {
        display = true;
    }

}
