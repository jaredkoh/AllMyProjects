package Models;

import java.io.Serializable;
/**
 * Data Class that combine a switch code and core data
 * @author Team 1-M
 */
public class Data implements Serializable{
    
    private static final long serialVersionUID = 1L;
    private int switchCode;
    private Object data;
    /**
     * Sets Data with a switch code and core value data    
     * @param inputSwitchCode
     * @param inputData
     */
    public void setDataPackage(int inputSwitchCode, Object inputData) {
        this.switchCode = inputSwitchCode;
        this.data = inputData;
    }
    /**
     * Returns current switch code    
     * @return switchCode
     */
    public int getSwitchCode() {
        return this.switchCode;
    }
    
    /**
     * Returns core value data
     * @return data
     */
    public Object getData() {
        return this.data;
    }
}
