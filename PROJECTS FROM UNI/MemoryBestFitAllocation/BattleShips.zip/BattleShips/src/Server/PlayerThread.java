package Server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;

import Models.Data;
/**
 * Player Thread class which makes a new thread per Player connection.
 * @author Team 1-M.
 *
 */
public class PlayerThread extends Thread implements Serializable  {
    private static final long serialVersionUID = 1L;
    private int playerSelector;
    private int opponentSelector; 
    private Socket playerSocketForObjects;
    private ObjectInputStream fromPlayerObject;
    private ObjectOutputStream toPlayerObject;   
    private ServerGameController serverGameController;  
    private boolean isPlaying = false; 
    protected boolean threadSignal = true;  
    private boolean startingSign;
    
    /**
     * Changes current isPlaying value to true
     */
    protected void setIsPlaying() {
        this.isPlaying = true;
    }
    
    /**
     * Return current isPlaying value
     * @return isPlaying
     */
    protected boolean isPlaying() {
        return isPlaying;
    }
    
    /**
     * Returns data type boolean value starting sign with switch code to send over to opponent player
     * @return startingSignData     includes switch code and current boolean startingSign
     */
    private Data isStartingGame() {
        Data startingSignData = new Data();
        startingSignData.setDataPackage(3, startingSign);
        return startingSignData;
    }
    
    /**
     * Constructs PlayerThread
     * @param inputClientSocketForObjects
     * @param inputPlayerSelector
     * @param inputServerGameController
     * @param inputStartingSign
     */
    public PlayerThread(Socket inputClientSocketForObjects, int inputPlayerSelector, ServerGameController inputServerGameController, boolean inputStartingSign) {
        this.playerSocketForObjects = inputClientSocketForObjects;
        this.playerSelector = inputPlayerSelector;
        this.serverGameController = inputServerGameController;
        this.startingSign = inputStartingSign;
        if(playerSelector == 1) {
            this.opponentSelector = 2;
        } else {
            this.opponentSelector = 1;
        }
    }
    
    /**
     * Sets object input/output streams to send and receive data
     */
    private void setPlayerInputOutputStreams() {
        try {      
            //if ObjectInputStream is called earlier than ObjectOutputStream in the server side,
            //ObjectOutputStream should come first in the client side to avoid a deadlock and vice versa.
            /*Creates an ObjectInputStream that reads from the specified InputStream. 
             * A serialisation stream header is read from the stream and verified. 
             * This constructor will block until the corresponding 
             * ObjectOutputStream has written and flushed the header. from the Java doc.
             */
            fromPlayerObject = new ObjectInputStream(playerSocketForObjects.getInputStream());
            toPlayerObject = new ObjectOutputStream(playerSocketForObjects.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }     
    }
 
    /**
     * Runs playerThread
     */
    public void run() {  
        setPlayerInputOutputStreams();          
        objectReceiver.start();
        objectSender.start();
    }
    
    /**
     * Keep receiving data from current player
     */
    Thread objectReceiver = new Thread(new Runnable(){
        public synchronized void run() {
            while(threadSignal) {
                try { 
                    Thread.sleep(300);
                    if(serverGameController.getTempObject(playerSelector) == null) {
                        Data temp = (Data)fromPlayerObject.readObject();
                        serverGameController.setTempObject(temp, playerSelector);
                        //Switchcodes 0, 4 should work in the server as well as opponent client.
                        if(temp.getSwitchCode() == 0) {
                          
                            playerOut();
                        } else if (temp.getSwitchCode() == 5) {
                            setIsPlaying();
                        }
                        
                    }
                } catch (ClassNotFoundException | IOException | InterruptedException e) {
                    e.printStackTrace();
                }
            }
            Thread.interrupted();
        }
        
    });
    
    /**
     * Keep sending data to current player
     * If your opponent data is sent to the server, it will send them over to current player
     */
    Thread objectSender = new Thread(new Runnable(){
        public synchronized void run() {
            try {
               
                toPlayerObject.writeObject(isStartingGame());
                while(threadSignal) {
                    Thread.sleep(300);
                    if(serverGameController.getTempObject(opponentSelector) != null) {
                        Data temp = (Data)serverGameController.getTempObject(opponentSelector); 
                        toPlayerObject.writeObject(temp);
                        serverGameController.setTempObject(null, opponentSelector);
                      
                    }

                }
            } catch (IOException | InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } 
            Thread.interrupted();
        }  
    }); 
    
    /**
     * Stops this thread by changing threadSignal value to false
     */
    public void killThreads() {
        this.threadSignal = false;
    }
    
    /**
     * Stops everything alive related to the game if current player leave the game
     */
    public void playerOut() {
        serverGameController.stopController();
        killThreads();
        Thread.interrupted();
    }
}
