package Server;

import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;

import Models.Data;
import Models.ServerPlayerModel;

/**
 * Plays as if a game room in the game ServerGameController is created every two players connected
 * @author Team 1-M.
 */
public class ServerGameController {
    // Players' objects
    private Data firstPlayerTempObject = null;
    private Data secondPlayerTempObject = null;
    protected ArrayList<ServerPlayerModel> playerList = new ArrayList<ServerPlayerModel>();
    boolean startingSignal1 = false;
    boolean startingSignal2 = false;
    boolean signal = true;

    /**
     * Changes signal value to false it is called only if a player leave the window setting ships to prepare
     * the remaining player for matching new player
     */
    public void stopController() {
        signal = false;
    }

    /**
     * Returns signal value
     * 
     * @return signal boolean value being used in ConnectionManager
     */
    public boolean getSignal() {
        return this.signal;
    }

    /**
     * checks players are starting a game
     * 
     * @return boolean value if both player press play buttons, it returns true, otherwise false
     */
    public boolean isGamePlaying() {
        if (playerList.get(0).getFirstPlayerThread().isPlaying()
                && playerList.get(1).getFirstPlayerThread().isPlaying()) {
            return true;
        }
        else {
            return false;
        }
    }

    /**
     * Returns the number of players in ServerGameController
     * 
     * @return 0, 1, 2 depends on how many players are in ServerGameController
     */
    public int numberOfPlayers() {
        if (playerList.get(0).isEmpty() && playerList.get(1).isEmpty()) {
            return 0;
        }
        else if (playerList.get(0).isEmpty() || playerList.get(1).isEmpty()) {
            return 1;
        }
        else {
            return 2;
        }
    }

    /**
     * Constructs ServerGameController
     */
    public ServerGameController() {
        // To make player spaces in ArrayList
        for (int i = 0; i < 2; i++) {
            playerList.add(new ServerPlayerModel());
        }
        // playerList.get(0) is for firstPlayer space, playerList.get(1) is for secondPlayer one.
        chooseFirstStartingPlayer();
    }

    /**
     * Stores received data in order to send the data to opponent
     * 
     * @param inputObject
     *            includes switch code and real data
     * @param selector
     *            the number to differentiate if a player is first player or second
     */
    public void setTempObject(Data inputObject, int selector) {
        // selector value 1 means firstPlayer, 2 is secondPlayer
        if (selector == 1) {
            this.firstPlayerTempObject = inputObject;
        }
        else if (selector == 2) {
            this.secondPlayerTempObject = inputObject;
        }
    }

    /**
     * Returns Data type object to the player which needs opponent Data
     * 
     * @param selector
     *            the number to differentiate if a player is first player or second
     * @return firstPlayerTempObject, secondPlayerTempObject
     */
    public Object getTempObject(int selector) {
        // selector value 1 means firstPlayer, 2 is secondPlayer
        if (selector == 1) {
            return firstPlayerTempObject;
        }
        else {
            return secondPlayerTempObject;
        }
    }

    /**
     * Chooses which player to take first turn randomly
     */
    private void chooseFirstStartingPlayer() {
        int startingPlayer = new Random().nextInt(2) + 1;
        if (startingPlayer == 1) {
            startingSignal1 = true;
        }
        else {
            startingSignal2 = true;
        }
    }

    /**
     * Sets existing ServerPlayerModel with player socket sent from ConnectionManager and unique player number
     * 
     * @param inputPlayerSocketForObjects
     * @param inputIndividualPlayerNumber
     */
    public void setup(Socket inputPlayerSocketForObjects, int inputIndividualPlayerNumber) {
        if (playerList.get(0).isEmpty()) {
        
            playerList.get(0).setupServerPlayerModel(inputIndividualPlayerNumber,
                    inputPlayerSocketForObjects, 1, this, startingSignal1);
        }
        else {
            playerList.get(1).setupServerPlayerModel(inputIndividualPlayerNumber,
                    inputPlayerSocketForObjects, 2, this, startingSignal2);
   
        }
    }
}
