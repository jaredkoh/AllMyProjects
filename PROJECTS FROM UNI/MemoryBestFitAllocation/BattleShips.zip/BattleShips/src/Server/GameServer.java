package Server;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import javax.swing.JOptionPane;

/**
 * Main Server Class for Battleship game. This opens server socket.
 *
 * @author Team 1-M.
 */
public class GameServer {

    private int portNumber;
    private ServerSocket serverSocket;

    /**
     * Starts server by calling setServerSocket(), serverConnectionChecker() and creating ConnectionManager
     * object
     */
    public void startServer() {
        setServerSocket();
    }

    /**
     * Sets new server socket with a port number
     */
    private void setServerSocket() {
        this.portNumber = 4444;
        try {
            serverSocket = new ServerSocket(portNumber);
            serverConnectionChecker();
            // Calls connectionManager
            new ConnectionManager(serverSocket);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "There is already a server running", "Warning",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Checks validity of the Internet connection
     */
    private void serverConnectionChecker() {
        try {
            String ip = Inet4Address.getLocalHost().getHostAddress();
            if (!ip.equals("127.0.0.1")) {

                JOptionPane.showMessageDialog(null, "The server IP is ( " + ip
                        + " ) and the port number is ( " + this.portNumber + " )",
                        "You're connected on the server.", JOptionPane.INFORMATION_MESSAGE);
            }
            else {
                // If there is no internet connection, the server terminates.

                JOptionPane.showMessageDialog(null,
                        "Your computer doesn't seem to have the internet connection", "Warning",
                        JOptionPane.ERROR_MESSAGE);
                System.exit(0);
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        }
    }
}

/**
 * Manages connections between two clients via the server
 */
class ConnectionManager {
    private int playerNumber = 1;
    private ServerSocket serverSocket;
    private Socket playerSocketForObjects;
    private ServerGameController serverGameController = null;

    /**
     * Constructs a ConnectionManager
     *
     * @param inputServerSocket
     *            server socket created in GameServer class
     */
    public ConnectionManager(ServerSocket inputServerSocket) {
        this.serverSocket = inputServerSocket;
        createController();
    }

    /**
     * Returns PlayerNumber
     *
     * @return playerNumber unique number to differentiate each player
     */
    public int getPlayerNumber() {
        return this.playerNumber;
    }

    /**
     * Returns ServerSocket
     *
     * @return serverSocket serverSocket sent from GameServer class
     */
    public ServerSocket getServerSocket() {
        return this.serverSocket;
    }

    /**
     * Add players to ServerGameController If the number of players in serverGameController reaches two, it
     * creates new ServerGameController
     */
    private void createController() {
        while (true) {
            addPlayer();
            if (serverGameController == null || serverGameController.getSignal() == false) {
                serverGameController = new ServerGameController();
            }
            // If serverGameController has at least one space for a new player, current connected player is
            // sent.
            int numberOfPlayers = serverGameController.numberOfPlayers();
            if (numberOfPlayers < 2) {
                // Send data to ServerGameController
                serverGameController.setup(playerSocketForObjects, playerNumber);
                // To increase player's individual number.
                this.playerNumber++;
                if (numberOfPlayers == 1) {
                    serverGameController = null;
                }
            }
        }
    }

    /**
     * Gets serverSocket wait until new client try to connect to the server
     */
    private void addPlayer() {
        try {

            playerSocketForObjects = serverSocket.accept();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
