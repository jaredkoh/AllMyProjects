import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.UnknownHostException;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import Server.GamePlayerClient;
import Server.GameServer;

/**
 * Class which launches the option screen for starting the server or game.
 *
 * @author Team 1-M.
 *
 */
public class MainApp extends JFrame {

	private static final long serialVersionUID = 1L;

	public static void main(String[] args) {
		MainApp gameLaunch = new MainApp();
		gameLaunch.setupGUI();
	}

	/**
	 * Sets up GUI for the MainApp.
	 */
	public void setupGUI() {

		setTitle("Welcome to Battleships: Multiplayer");

		// Setup components of opening frame.
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new GridLayout(1, 2));

		Icon serverImage = new ImageIcon("Images/servericon.jpg");
		Icon clientImage = new ImageIcon("Images/clienticon.jpg");

		// Buttons with icons.
		JButton serverButton = new JButton(serverImage);
		JButton clientButton = new JButton(clientImage);

		serverButton.setSize(100, 100);
		clientButton.setSize(100, 100);

		JPanel topPanel = new JPanel();
		JLabel optionLabel = new JLabel(
				"Please choose from one of the following options:");
		topPanel.add(optionLabel, BorderLayout.CENTER);

		mainPanel.add(serverButton);
		mainPanel.add(clientButton);

		// Panel colours and borders.
		topPanel.setBackground(Color.WHITE);
		mainPanel.setBackground(Color.WHITE);

		serverButton.setBorder(BorderFactory.createEtchedBorder(Color.BLACK,
				Color.BLACK));
		clientButton.setBorder(BorderFactory.createEtchedBorder(Color.BLACK,
				Color.BLACK));
		topPanel.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, null));

		// Added listener for Server button
		serverButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Closes frame and starts new server.
				dispose();
				new GameServer().startServer();
			}

		});

		clientButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// Closes frame and starts new client.
				dispose();
				GamePlayerClient gpc = new GamePlayerClient();
				String ipInput = JOptionPane
						.showInputDialog("Please put your ip address");
				if(gpc.connectServer(ipInput)){
					gpc.startClient();
				}
			}

		});

		add(topPanel, BorderLayout.NORTH);
		add(mainPanel, BorderLayout.CENTER);

		setResizable(false);
		setSize(new Dimension(650, 370));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		pack();
		setVisible(true);
	}
}
