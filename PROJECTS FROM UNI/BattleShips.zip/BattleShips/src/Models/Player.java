package Models;

import java.io.Serializable;

/**
 * Player class which has all player properties.
 * @author Team 1-M.
 * 
 */
public class Player implements Serializable {

    private static final long serialVersionUID = 8999765707435830945L;

    /**
     * Number of remaining squares on the board that the player has marked as ships.
     */
    private int shipSquaresRemaining;

    /**
     * Board which stores the ships for the player.
     */
    private Board playerBoard;

    /**
     * Nickname to identify a player.
     */
    private String nickname = "";

    /**
     * Constructs a Player with a new Board, and 0 shipSquaresRemaining.
     */
    public Player() {
        shipSquaresRemaining = 0;
        playerBoard = new Board();
    }

    /**
     * Gets the board of the player
     * 
     * @return the board of this player
     */
    public Board getBoard() {
        return playerBoard;
    }

    /**
     * Sets a new board for the player. For testing purposes. May not be needed in future.
     * 
     * @param newBoard
     *            Board that you want to give to the player.
     */
    public void setBoard(Board newBoard) {
        playerBoard = newBoard;
    }

    /**
     * Checks whether a player has any ships remaining to continue playing the game.
     * 
     * @return Returns true if this player has any non-bombed ship squares remaining; else return false
     */
    public boolean hasShipsRemaining() {
        if (shipSquaresRemaining > 0) {
            return true;
        }
        return false;
    }

    /**
     * Decrements the number of non-bombed ship squares that a player has remaining.
     */
    public void removeShipSquare() {
        shipSquaresRemaining--;
    }

    /**
     * Sets a nickname for a player.
     * 
     * @param newName
     *            nickname of the player.
     */
    public void setNickname(String newName) {
        if (newName != null && !newName.equals("")) {
            nickname = newName;
        }

    }

    /**
     * Gets the nickname of a player.
     * 
     * @return nickname the nickname of the player.
     */
    public String getNickname() {
        return nickname;
    }

    /**
     * Increment the number of ship squares that a player has remaining.
     */
    public void addShipSquare() {
        shipSquaresRemaining++;
    }

}
