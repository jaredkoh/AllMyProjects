package Models;

import java.net.Socket;

import Server.PlayerThread;
import Server.ServerGameController;
/**
 * Basic player model only used in the server
 * @author Team 1-M.
 */
public class ServerPlayerModel {
    private int individualPlayerNumber;
    private Socket playerSocketForObjects = null;
    private PlayerThread firstPlayerThread;
    private PlayerThread secondPlayerThread;
    
    /**
     * Checks if this model is empty or not
     * @return true, false
     */
    public boolean isEmpty() {
        if(playerSocketForObjects == null) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Returns unique player number
     * @return individualPlayerNumber
     */
    public int getIndividualPlayerNumber() {
        return this.individualPlayerNumber;
    }
    
    /**
     * Returns playerSocketForObjects
     * @return playerSocketForObjects
     */
    public Socket getPlayerSocketForObjects() {
        return this.playerSocketForObjects;
    }
    
    /**
     * Returns first player thread
     * If second player thread is stored, firstPlayerThread will be null 
     * @return firstPlayerThread
     */
    public PlayerThread getFirstPlayerThread() {
        return this.firstPlayerThread;
    }
    
    /**
     * Returns second player thread
     * If first player thread is stored, secondPlayerThread will be null 
     * @return secondPlayerThread
     */
    public PlayerThread getSecondPlayerThread() {
        return this.secondPlayerThread;
    }
    
    /**
     * Constructs setupServerPlayerModel
     * @param inputPlayerNumber
     * @param inputPlayerSocketForObjects
     * @param inputPlayerSelector
     * @param inputServerGameController
     * @param inputStartingSign
     */
    public void setupServerPlayerModel(int inputPlayerNumber, Socket inputPlayerSocketForObjects, 
            int inputPlayerSelector, ServerGameController inputServerGameController, boolean inputStartingSign) {
        this.individualPlayerNumber = inputPlayerNumber;
        this.playerSocketForObjects = inputPlayerSocketForObjects;
        
        if(inputPlayerSelector == 1) {
            firstPlayerThread = new PlayerThread(this.playerSocketForObjects, inputPlayerSelector, inputServerGameController, inputStartingSign);
            firstPlayerThread.start();
        } else if(inputPlayerSelector == 2) {
            secondPlayerThread = new PlayerThread(this.playerSocketForObjects, inputPlayerSelector, inputServerGameController, inputStartingSign);
            secondPlayerThread.start();
        }
    }
}
