package Models;

import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import Interface.Block;

/**
 * Board Class which holds the blocks(ships).
 *
 * @author Team 1-M.
 *
 */
public class Board implements Serializable {

    private static final long serialVersionUID = -7273673124205624064L;
    private Square[][] board;
    private static final int BOARD_SIZE = 10;

    /**
     * List of ships that are currently on the board.
     */
    private ArrayList<Block> shipsOnBoard = new ArrayList<Block>();

    /**
     * List of ships that have been bombed and no longer considered to be on the board.
     */
    private ArrayList<Block> bombedShips = new ArrayList<Block>();

    /**
     * Constructor of board which initially contains non-bombed squares with no ships.
     */
    public Board() {
        board = new Square[10][10];
        for (int row = 0; row < BOARD_SIZE; row++) {
            for (int col = 0; col < BOARD_SIZE; col++) {
                board[col][row] = new Square();
            }
        }
    }

    /**
     * Gets a square with specified coordinates.
     *
     * @param x
     *            x-coordinate of square
     * @param y
     *            y-coordinate of square
     * @return the square with said coordinates
     */
    public Square getSquare(int x, int y) {
        return board[x][y];
    }

    /**
     * Uses coordinates of a block to place it on a board.
     *
     * @param newShip
     *            ship to be set on the board
     */
    public void setShip(Block newShip) {
        if (newShip.getIsHorizontal() == true) {
            for (int i = newShip.getStartPos().x; i <= newShip.getEndPos().x; i++) {
                board[i][newShip.getStartPos().y].setShip();
                board[i][newShip.getStartPos().y].setOwnerBlock(newShip);
            }
        }
        else {
            for (int i = newShip.getStartPos().y; i <= newShip.getEndPos().y; i++) {
                board[newShip.getStartPos().x][i].setShip();
                board[newShip.getStartPos().x][i].setOwnerBlock(newShip);
            }
        }
        shipsOnBoard.add(newShip);
    }

    /**
     * Checks if a block(ship) has been fully bombed. If it has been bombed, a dialog box is displayed to
     * alert the current player that they have bombed their opponents ship. A message is also returned to the
     * opponent to alert them that their ship has been destroyed.
     *
     * @param blockToVerify
     * @return destroyMessage: name of
     */
    public String checkShipStatus(Block blockToVerify) {
        String destroyMessage = null;

        if (verifyBombing(blockToVerify)) {
            shipsOnBoard.remove(blockToVerify);
            bombedShips.add(blockToVerify);
            destroyMessage = blockToVerify.getShipName() + " (" + blockToVerify.getBlocksPerShip()
                    + " block ship)";

            JOptionPane.showMessageDialog(null, "You have destroyed your opponent's "
                    + destroyMessage + "!", "Ship destroyed!", JOptionPane.INFORMATION_MESSAGE,
                    new ImageIcon("Images/skull.png"));

        }

        return destroyMessage;
    }

    /**
     * Checks whether all squares of a block(ship) have been bombed or not.
     *
     * @param shipOnBoard
     * @return true if all squares of a block(ship) have been bombed. Otherwise, false.
     */
    public boolean verifyBombing(Block shipOnBoard) {
        if (shipOnBoard.getIsHorizontal() == true) {
            for (int j = shipOnBoard.getStartPos().x; j <= shipOnBoard.getEndPos().x; j++) {
                if (!board[j][shipOnBoard.getStartPos().y].isBombed()) {
                    return false;
                }
            }
        }
        else {
            for (int j = shipOnBoard.getStartPos().y; j <= shipOnBoard.getEndPos().y; j++) {
                if (!board[shipOnBoard.getStartPos().x][j].isBombed()) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Sets a square with given coordinates as bombed.
     *
     * @param x
     *            x-coordinate of square
     * @param y
     *            y-coordinate of square
     */
    public void bomb(int x, int y) {
        board[x][y].bomb();
    }

    /**
     * Sets a square on the board to be displayed.
     *
     * @param x
     *            x-coordinate of square
     * @param y
     *            y-coordinate of square
     */
    public void display(int x, int y) {
        board[x][y].display();
    }

    /**
     * Removes all the ships that are currently on the board.
     */
    public void resetBoard() {

        for (int row = 0; row < 10; row++) {
            for (int col = 0; col < 10; col++) {

                if (this.getSquare(row, col).isShip()) {
                    this.getSquare(row, col).removeShip();

                }

            }
        }

    }

    /**
     * Removes a block(ship) from the board.
     *
     * @param shipToRemove
     */
    public void removeShip(Block shipToRemove) {

        if (shipToRemove.getIsHorizontal() == true) {
            for (int i = shipToRemove.getStartPos().x; i <= shipToRemove.getEndPos().x; i++) {
                board[i][shipToRemove.getStartPos().y].removeShip();
                board[i][shipToRemove.getStartPos().y].setOwnerBlock(null);
            }
        }
        else {

            for (int i = shipToRemove.getStartPos().y; i <= shipToRemove.getEndPos().y; i++) {
                board[shipToRemove.getStartPos().x][i].removeShip();
                board[shipToRemove.getStartPos().x][i].setOwnerBlock(null);
            }
        }

        shipsOnBoard.remove(shipToRemove);

    }

    /**
     * Checks whether a board is empty.
     *
     * @return true if board is empty. false if board contains ships.
     */
    public boolean isEmpty() {

        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if (board[i][j].isShip()) {
                    return false;
                }
            }
        }
        return true;
    }
}
