package GridOutlines;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * WestPanel class which will display the numbers along side the grid.
 * @author Team 1-M.
 * 
 */
public class WestPanel extends JPanel {

    /**
     * Constructs a WestPanel with numbers up to 10.
     * 
     */
    public WestPanel() {
        this.setLayout(new GridLayout(10, 1));

        for (int i = 1; i <= 10; i++) {
            JPanel currentPanel = new JPanel();
            currentPanel.setBackground(Color.gray);
            currentPanel.setBorder(BorderFactory.createDashedBorder(Color.BLACK));
            currentPanel.add(new JLabel(String.valueOf(i)));
            this.add(currentPanel);
        }
    }
}
