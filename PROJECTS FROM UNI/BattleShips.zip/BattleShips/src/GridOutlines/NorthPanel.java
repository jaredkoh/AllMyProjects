package GridOutlines;

import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * NorthPanel class which will display the letters above the grid.
 * @author Team 1-M.
 * 
 */
public class NorthPanel extends JPanel {

    /**
     * Constructs a WestPanel with letters up to J.
     * 
     */
    public NorthPanel() {

        for (char i = 'A'; i <= 'J'; i++) {
            this.setLayout(new GridLayout(1, 10));
            JPanel currentPanel = new JPanel();

            currentPanel.setBackground(Color.gray);
            currentPanel.setBorder(BorderFactory.createDashedBorder(Color.BLACK));
            currentPanel.add(new JLabel(String.valueOf(i)));

            this.add(currentPanel);

        }
    }

}
