package Listeners;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Interface.Block;
import Interface.Player1Pane;

/**
 * ResetListener Class for reset button.
 *
 * @author Team 1-M.
 *
 */
public class ResetListener implements ActionListener {

    private Player1Pane playerGrid;
    private Block shipCarrier;
    private ArrayList<Block> ships;

    /**
     * Constructs a ResetListener
     *
     * @param p1pane
     * @param shipTransfer
     * @param shipList
     */
    public ResetListener(Player1Pane p1pane, Block shipTransfer, ArrayList<Block> shipList) {
        playerGrid = p1pane;
        shipCarrier = shipTransfer;
        ships = shipList;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!playerGrid.isEmpty()) {

            if (JOptionPane.showConfirmDialog(null, "Are you sure you want to reset the grid?",
                    "WARNING", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
                playerGrid.getPlayer().getBoard().resetBoard();
                playerGrid.repaint();

                // Resets number of ships for each blocks(ships).
                shipCarrier.resetBlocks();
                ships = shipCarrier.getShips();

                for (int i = 0; i < ships.size(); i++) {
                    ships.get(i).updateLabel(ships.get(i).getNumberOfShips());
                    ships.get(i).repaint();
                }
            }
        }
    }

}
