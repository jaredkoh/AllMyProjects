package Interface;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

/**
 * Grid Pane class that draws the grid for Player1Pane and Player2Pane.
 * 
 * @author Team 1-M.
 *
 */
public class GridPane extends JPanel {

    public static int columnCount = 10;
    public static int rowCount = 10;
    public List<Rectangle> cells;

    public Point selectedCell;
    public Graphics2D g2d;

    /**
     * Constructs a GridPane.
     */
    public GridPane() {

        this.setBackground(Color.WHITE);
        cells = new ArrayList<>(columnCount * rowCount);

        this.setMinimumSize(new Dimension(400, 400));

        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                int width = getWidth();
                int height = getHeight();

                int cellWidth = width / columnCount;
                int cellHeight = height / rowCount;

                int column = e.getX() / cellWidth;
                int row = e.getY() / cellHeight;

                if (column < 10 && row < 10 && column >= 0 && row >= 0) {
                    selectedCell = new Point(column, row);

                }
            }
        });

    }

    /**
     * Returns the selected cell.
     *
     * @return Selected Cell.
     */
    public Point getPoint() {
        return selectedCell;
    }

    @Override
    public void invalidate() {
        cells.clear();
        selectedCell = null;
        super.invalidate();
    }

    // Paints the grid.
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g2d = (Graphics2D) g.create();

        int width = getWidth();
        int height = getHeight();

        int cellWidth = width / columnCount;
        int cellHeight = height / rowCount;

        int xOffset = (width - (columnCount * cellWidth)) / 2;
        int yOffset = (height - (rowCount * cellHeight)) / 2;

        if (cells.isEmpty()) {

            for (int row = 0; row < rowCount; row++) {
                for (int col = 0; col < columnCount; col++) {
                    Rectangle cell = new Rectangle(xOffset + (col * cellWidth), yOffset
                            + (row * cellHeight), cellWidth, cellHeight);
                    cells.add(cell);
                }
            }
        }

    }

    /**
     * Draws the grid.
     */
    void drawGrid() {

        g2d.setColor(Color.BLACK);
        for (Rectangle cell : cells) {
            g2d.draw(cell);
        }

    }
}
