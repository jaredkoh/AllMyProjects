package Interface;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import GridOutlines.PlayerGridHolder;
import Listeners.DragListener;
import Listeners.ReadyListener;
import Listeners.ResetListener;
import Listeners.UndoListener;
import Models.Player;
import Server.GamePlayerClient;

/**
 * SetShips class which creates the setup ships screen (Start of the game).
 *
 * @author Team 1-M.
 *
 */
public class SetShips extends JFrame {

    private GamePlayerClient gamePlayerClient;
    private Player1Pane player1Pane;
    private Player2Pane player2Pane;
    private Player gamePlayer;
    private Player opponentPlayer;
    private Grid gameGrid;

    private JButton playButton = new JButton("Play");
    private JButton resetButton = new JButton("Reset Ships");
    private JButton undoButton = new JButton("Undo");
    private JButton readyButton = new JButton("Ready");
    private static String nicknameField = "Enter a nickname";
    private JTextField nickname = new JTextField(10);

    private ArrayList<Block> shipList;
    private JPanel shipStorage;
    private JPanel messagePanel = new JPanel();;
    private Player1Pane playerGrid;
    private PlayerGridHolder playerGridHolder;
    private Point selectedCell;
    private Block shipCarrier;

    private Block lastShipPlaced;
    private ArrayList<Block> blockPlaceHistory = new ArrayList<Block>();
    private ArrayList<Block> dragHistory = new ArrayList<Block>();

    /**
     * Constructs SetShips with the GamePlayerClient and Player.
     *
     * @param inputGamePlayerClient
     *            GamePlayerClient.
     * @param inputPlayer
     *            The player which will use the setup screen(Player 1).
     */
    public SetShips(GamePlayerClient inputGamePlayerClient, Player inputPlayer) {
        this.gamePlayerClient = inputGamePlayerClient;
        this.gamePlayer = inputPlayer;
        guiSetup();
    }

    /**
     * Sets up the GUI for the SetShips window.
     */
    public void guiSetup() {

        this.setTitle("Battleship: Setup your ships!");

        shipStorage = new JPanel();
        GridLayout shipStorageLayout = new GridLayout(4, 1);
        shipStorage.setLayout(shipStorageLayout);

        // Gets blocks for ship storage.
        shipCarrier = new Block();
        shipList = shipCarrier.getShips();

        JPanel rightPane = new JPanel(new BorderLayout());
        JPanel optionPane = new JPanel();

        playerGrid = new Player1Pane(gamePlayer);
        playerGridHolder = new PlayerGridHolder(playerGrid);

        // Initialise listener for ship dragging.
        DragListener dragListener = new DragListener(playerGrid, shipList, shipStorage,
                playerGridHolder, selectedCell, lastShipPlaced, blockPlaceHistory, dragHistory,
                messagePanel);

        for (int i = 0; i < shipList.size(); i++) {

            // Add listeners to block(ships) for drag feature.
            shipList.get(i).addMouseListener(dragListener);
            shipList.get(i).addMouseMotionListener(dragListener);

            // Setup components of left panel.
            JPanel shipPane = new JPanel(new BorderLayout());
            shipPane.setBackground(Color.WHITE);
            JLabel shipBlock = shipList.get(i);
            shipPane.add(shipBlock);

            JLabel setShipAs = new JLabel("Set ship alignment as: ");

            JPanel miniPane = new JPanel(new BorderLayout());
            miniPane.setBackground(Color.WHITE);
            miniPane.add(setShipAs, BorderLayout.WEST);
            miniPane.add(shipList.get(i).getComboBox(), BorderLayout.EAST);

            JPanel comboBoxHolder = new JPanel(new BorderLayout());
            comboBoxHolder.setLayout(new GridLayout(2, 1));
            comboBoxHolder.setBackground(Color.WHITE);
            comboBoxHolder.add(miniPane, BorderLayout.NORTH);
            comboBoxHolder.add(shipList.get(i).getNumberOfShipsLabel(), BorderLayout.CENTER);

            JPanel mainPanel = new JPanel(new GridLayout(1, 2));
            mainPanel.add(shipPane);
            mainPanel.add(comboBoxHolder);
            mainPanel.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, null));

            shipStorage.add(mainPanel);

        }

        // Setup right and left panels.
        rightPane.add(playerGridHolder, BorderLayout.CENTER);
        rightPane.add(optionPane, BorderLayout.SOUTH);

        shipStorage.setBackground(Color.WHITE);
        optionPane.setBackground(Color.WHITE);

        JLabel dragMessage = new JLabel("Drag your ships to the grid for setup");
        dragMessage.setOpaque(true);
        dragMessage.setBackground(Color.WHITE);

        messagePanel.add(dragMessage);
        messagePanel.setBackground(Color.WHITE);
        JPanel leftPane = new JPanel(new BorderLayout());
        leftPane.add(messagePanel, BorderLayout.NORTH);
        leftPane.add(shipStorage, BorderLayout.CENTER);

        // Ships pane and board pane added to frame.
        add(leftPane, BorderLayout.WEST);
        add(rightPane, BorderLayout.CENTER);

        // Border for panels.
        leftPane.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, Color.BLACK));
        rightPane.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, null));
        optionPane.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, null));
        messagePanel.setBorder(BorderFactory.createEtchedBorder(Color.BLACK, null));

        // When nickname field is clicked, tool-tip text is removed.
        nickname.setText(nicknameField);
        nickname.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (nickname.getText().equals(nicknameField)) {
                    nickname.setText("");
                }
            }
        });
        optionPane.add(nickname);
        nickname.setToolTipText(nicknameField);

        // Adds a listener to the play button to close frame and open a game window
        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                player1Pane = new Player1Pane(gamePlayer);
                gamePlayerClient.setPane(player1Pane, 1);
                player2Pane = null;

                if (opponentPlayer != null) {
                    // Closes the setting window and opens game window.
                    dispose();
                    player2Pane = new Player2Pane(opponentPlayer, gamePlayerClient,
                            gamePlayerClient.isMyTurn());
                    gamePlayerClient.setPane(player2Pane, 2);

                    if (gamePlayerClient.isMyTurn()) {
                        player2Pane.enableEdit();
                    }
                    else {
                        player2Pane.disableEdit();
                    }
                    gameGrid = new Grid(player1Pane, player2Pane, gamePlayerClient);
                    gamePlayerClient.setGrid(gameGrid);

                    // Send Data with switch code 5 to represent that client is playing.
                    gamePlayerClient.setIsPlaying();
                    gamePlayerClient.sendData(5, true);
                }
                else {
                    // If there is no opponent player yet.
                    JOptionPane
                    .showMessageDialog(null, "Please wait until your opponent is ready!");
                }
            }
        });

        // Add listener to Reset button.
        ResetListener resetListener = new ResetListener(playerGrid, shipCarrier, shipList);
        resetButton.addActionListener(resetListener);

        // Add listener to Undo button.
        UndoListener undoListener = new UndoListener(playerGrid, blockPlaceHistory, dragHistory,
                shipList);
        undoButton.addActionListener(undoListener);

        // Add listener to Ready button.
        ReadyListener readyListener = new ReadyListener(nickname, nicknameField, gamePlayer,
                gamePlayerClient, resetButton, undoButton, playButton, readyButton, shipList,
                dragListener);

        readyButton.addActionListener(readyListener);

        // Play button be clicked initially.
        playButton.setEnabled(false);

        // Add buttons to frame.
        optionPane.add(playButton);
        optionPane.add(readyButton);
        optionPane.add(resetButton);
        optionPane.add(undoButton);

        // Sizing of components.
        leftPane.setPreferredSize(new Dimension(600, 500));
        rightPane.setPreferredSize(new Dimension(600, 500));

        this.setPreferredSize(new Dimension(1200, 600));
        this.setMinimumSize(new Dimension(1200, 600));

        // To alert a player that the opponent has closed their game window.
        WindowListener playerOut = new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                gamePlayerClient.sendData(0, "closing");
                gamePlayerClient.closeSockets();
                System.exit(0);
            }
        };
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(playerOut);

        pack();
        setVisible(true);
    }

    /**
     * Checks if the blocks(ships) overlap when dragging the ships onto the grid.
     *
     * @return A boolean value for if the ships overlapped or not (true(overlap)).
     */
    public void setOpponentPlayer(Player inputOpponentPlayer) {
        this.opponentPlayer = inputOpponentPlayer;
    }

}
