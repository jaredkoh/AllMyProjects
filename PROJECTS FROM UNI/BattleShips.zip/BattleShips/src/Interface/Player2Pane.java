package Interface;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import Models.Board;
import Models.Player;
import Server.GamePlayerClient;
/**
 * Player2Pane class, the grid that is the opponent's pane but with hidden ships on the Grid Class(Game
 * Screen).
 *
 * @author Team 1-M.
 *
 */
public class Player2Pane extends GridPane {

    private Graphics2D g2f;
    private Player player2;
    private Board p2Board;

    private Grid gridPane;

    private GamePlayerClient gamePlayerClient;
    private Player2Pane player2Pane = this;
    private boolean isMyTurn;
    private Object objForThread = new Object();
    private boolean mouseActivator = false;
    private boolean isGameOver = false;
    private boolean amIWinner;
    private ArrayList<Point> usedSquares = new ArrayList<Point>();

    /**
     * Constructs a Player2Pane.
     *
     * @param p2
     *            Player 2 (Opponent).
     * @param inputGamePlayerClient
     *            GamePlayerClient.
     * @param inputIsMyTurn
     *            Turn checker.
     */
    public Player2Pane(Player p2, GamePlayerClient inputGamePlayerClient, boolean inputIsMyTurn) {

        this.isMyTurn = inputIsMyTurn;
        this.player2 = p2;
        this.gamePlayerClient = inputGamePlayerClient;

        this.p2Board = p2.getBoard();

        // Add listener to the player 2 pane for when bombing happens.
        this.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if (mouseActivator) {

                    if (selectedCell != null && gamePlayerClient.opponentIsPlaying()) {
                        int xCoord = selectedCell.x;
                        int yCoord = selectedCell.y;
                        if (!usedSquares.contains(selectedCell)) {
                            usedSquares.add(selectedCell);
                            player2Pane.disableEdit();

                            // Bomb and display the clicked point.
                            p2Board.bomb(xCoord, yCoord);
                            p2Board.display(xCoord, yCoord);

                            if (p2Board.getSquare(xCoord, yCoord).getOwnerBlock() != null) {
                                gamePlayerClient.sendData(7, p2Board.checkShipStatus(p2Board
                                        .getSquare(xCoord, yCoord).getOwnerBlock()));
                            }

                            // Send selected grid point to the opponent player via GameServer.
                            gamePlayerClient.sendData(2, getPoint());

                            repaint();
                            giveWayTurn();

                        }
                        else {
                            JOptionPane.showMessageDialog(null, "You've already tried this area!");
                        }
                    }
                }
            }
        });

    }

    /**
     * Sets the turn to the opponent.
     */
    public void giveWayTurn() {
        disableEdit();
        isMyTurn = false;
        gamePlayerClient.sendData(3, true);
    }

    // Paints the selected cells onto the pane.
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g2f = (Graphics2D) g.create();

        for (int row = 0; row < rowCount; row++) {
            for (int col = 0; col < columnCount; col++) {
                int index = (row * rowCount) + col;
                if (p2Board.getSquare(col, row).isShip() && p2Board.getSquare(col, row).isDisplay()) {

                    // Fire animation.
                    ImageIcon image = new ImageIcon("Images/hit.gif");
                    Point p = cells.get(index).getLocation();
                    g.drawImage(image.getImage(), p.x, p.y, getWidth() / 10, getHeight() / 10,
                            null, this);

                }
                else if (p2Board.getSquare(col, row).isDisplay()) {

                    // Water animation.
                    ImageIcon image = new ImageIcon("Images/miss.gif");
                    Point p = cells.get(index).getLocation();
                    g.drawImage(image.getImage(), p.x, p.y, getWidth() / 10, getHeight() / 10,
                            null, this);

                }

            }
        }

        drawGrid();
        g2f.dispose();

    }

    /**
     * Returns the player of the Player2Pane.
     *
     * @return (Player 2 (Opponent))
     */
    public Player getPlayer() {
        return player2;

    }

    /**
     * Disables the pane from being edited.
     */
    public void disableEdit() {
        this.mouseActivator = false;
    }

    /**
     * Enables the pane for editing.
     */
    public void enableEdit() {
        this.mouseActivator = true;
    }

    /**
     * Set the turns.
     *
     * @param inputTurn
     *            boolean input for whose turn it is.
     */
    public void setMyTurn(boolean inputTurn) {
        isMyTurn = inputTurn;
        if (isMyTurn) {
            updateStatusLabel();
        }
    }

    /**
     * Sets the grid to another grid.
     *
     * @param inputGrid
     *            the Grid you set.
     */
    public void setGrid(Grid inputGrid) {
        this.gridPane = inputGrid;
    }

    /**
     * Checks if the game is over or not.
     *
     * @param inputGameStatus
     *            boolean value for if you won the game or not.
     */
    public void setIsGameOver(boolean inputGameStatus) {
        this.isGameOver = inputGameStatus;
    }

    /**
     * Checks if you are the winner of the game or not.
     *
     * @param inputWinner
     *            boolean value for if you won the game or not.
     */
    public void setAmIWinner(boolean inputWinner) {
        this.amIWinner = inputWinner;
    }

    /**
     * Updates the label on the GridClass(GameScreen) for whos turn it is.
     */
    public void updateStatusLabel() {
        if (!updateStatusLabelThread.isAlive() && !isGameOver) {
            gridPane.statusLabel.setText("Now " + getPlayer().getNickname() + "'s turn!");
            updateStatusLabelThread.start();
        }
        else if (isMyTurn) {
            // Need to use synchronized block to get this thread to wait without
            // java.lang.IllegalMonitorStateException
            synchronized (objForThread) {
                objForThread.notifyAll();
            }
        }
    }

    /**
     * Returns if you are the winner of the game or not.
     *
     * @return the Winner or Loser.
     */
    public boolean amIWinner() {
        return this.amIWinner;
    }

    /**
     * Thread that limits the time of each player's turns.
     */
    Thread updateStatusLabelThread = new Thread(new Runnable() {
        @Override
        public void run() {
            while (!isGameOver) {
                try {
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                // If block prevents counter starting before the opponent press the play button
                if (gamePlayerClient.opponentIsPlaying() && isMyTurn) {
                    int timer = 20;
                    enableEdit();
                    do {
                        gridPane.statusLabel.setText("It's your turn, you have " + timer
                                + " second(s) left.");
                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        timer--;
                    } while (timer >= 0 && isMyTurn && !isGameOver);

                    if (!isGameOver) {
                        if (mouseActivator) {
                            giveWayTurn();
                        }
                        gridPane.statusLabel.setText("Now " + getPlayer().getNickname()
                                + "'s turn!");
                        // Need to use synchronized block to get this thread wait without
                        // java.lang.IllegalMonitorStateException
                        synchronized (objForThread) {
                            try {
                                objForThread.wait();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            }
            player2Pane.disableEdit();
            whoWins();
        }
    });

    /**
     * Sets the Turn JLabel to tell you who won or lost the game.
     */
    public void whoWins() {
        if (amIWinner) {
            gridPane.statusLabel.setText("You win!");
        }
        else {
            gridPane.statusLabel.setText("You lose!");
        }
        
    }

    public boolean isGameOver() {
        return isGameOver;
    }

}
