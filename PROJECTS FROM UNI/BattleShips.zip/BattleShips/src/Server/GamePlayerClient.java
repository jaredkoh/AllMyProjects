package Server;

import java.awt.Point;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import Interface.Grid;
import Interface.Player1Pane;
import Interface.Player2Pane;
import Interface.SetShips;
import Models.Data;
import Models.Player;

/**
 * GamePlayerClient Class
 *
 * @author Team 1-M.
 *
 */
public class GamePlayerClient implements Serializable {
	private static final long serialVersionUID = 1L;

	private ObjectInputStream inObject;
	private ObjectOutputStream outObject;
	private Socket socketForObject;
	private Player1Pane p1pane;
	private Player2Pane p2pane;
	private Grid grid;
	private Player player = new Player();

	// Opponent player initial value is null so that guiSetup method knows if
	// the opponentPlayer's data is
	// ready to use.
	// If player press Start button before opponentPlayer's data comes it will
	// make Null pointer error.
	private Player opponentPlayer = null;
	private Point opponentCoordinate;
	boolean isMyTurn;
	// To send this class reference to other GUI classes
	GamePlayerClient gamePlayerClient = this;
	boolean isPlaying = false;
	boolean opponentIsPlaying = false;
	private SetShips setShips;
	private String ip;

	/**
	 * This method allows us to access the players panels in GamePlayerClient
	 * Class from setShips Class
	 *
	 * @param inputPane
	 *            The panel to be placed in GamePlayerClient
	 * @param paneSelector
	 *            the integer value which defines which Panel to place in
	 *            GamePlayerClient
	 */
	public void setPane(Object inputPane, int paneSelector) {
		if (paneSelector == 1) {
			p1pane = (Player1Pane) inputPane;
		} else {
			p2pane = (Player2Pane) inputPane;
		}
	}

	/**
	 * This method allows us to access the Grid class from the GUI in
	 * GamePlayerClient
	 *
	 * @param inputGrid
	 *            Grid from setShip class
	 */
	public void setGrid(Grid inputGrid) {
		this.grid = inputGrid;
	}

	/**
	 * This method sets the Player to be playing the game
	 */
	public void setIsPlaying() {
		this.isPlaying = true;
	}

	/**
	 * This method checks whether it is the Player's turn
	 *
	 * @return returns a boolean value of if it is the player's turn
	 */
	public boolean isMyTurn() {
		return this.isMyTurn;
	}

	/**
	 * This method creates a socket to be connected to the server with port 4444
	 * and to a ip address.( In this case "local host is used" to play on the
	 * same machine )
	 *
	 */
	public boolean connectServer(String ip) {
		try {
			this.ip = ip;
			System.out.println(ip);
			socketForObject = new Socket(ip, 4444);
			return true;
		} catch (java.net.ConnectException e) {

			JOptionPane.showMessageDialog(null,
					"Check Server status: couldn't find server", "Warning",
					JOptionPane.ERROR_MESSAGE);
			// If no server is found, this client terminates.
			return false;

		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,
					"Check Server status: couldn't find server", "Warning",
					JOptionPane.ERROR_MESSAGE);

			return false;

		}

	}

	/**
	 * This method creates both the input and output streams for the player , to
	 * receive and send out objects to the server.
	 */
	private void setInputOutputStreams() {
		try {
			// If ObjectInputStream is called earlier than ObjectOutputStream in
			// the server side,
			// ObjectOutputStream should come first in the client side to avoid
			// a deadlock and vice versa.
			/*
			 * Creates an ObjectInputStream that reads from the specified
			 * InputStream. A serialisation stream header is read from the
			 * stream and verified. This constructor will block until the
			 * corresponding ObjectOutputStream has written and flushed the
			 * header. from the Java doc.
			 */
			System.out.println(socketForObject);
			outObject = new ObjectOutputStream(
					socketForObject.getOutputStream());
			inObject = new ObjectInputStream(socketForObject.getInputStream());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This method is the basic setup for the player and calls the basic GUI to
	 * start up.
	 */
	public void startClient() {
		setInputOutputStreams();
		new threadManager(this);
		setShips = new SetShips(this, player);
	}

	/**
	 * Method sends that sends objects for online game functionality
	 * inputSwichCode instruction (Usage: sendData(1,message)) 0 - close
	 * connection 1 - Player (Player type) data 2 - coordinate (Point type) data
	 * 3 - Turning (boolean type) data 4 - text (String type) for the chat
	 * system 5 - IsPlaying setup 6 - popup message (String type)
	 *
	 * @param inputSwitchCode
	 * @param inputData
	 */
	public void sendData(int inputSwitchCode, Object inputData) {
		try {
			Data dataPackage = new Data();
			dataPackage.setDataPackage(inputSwitchCode, inputData);

			outObject.writeObject(dataPackage);
			outObject.flush();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * This class is the main thread for the player , this thread mainly
	 * involves controlling the receiving and sending data throughout the game
	 * when it is being played.
	 */
	class threadManager {
		GamePlayerClient gamePlayerClient;
		int counter = 0;

		/**
		 * Constructor of the class
		 *
		 * @param inputGamePlayerClient
		 */
		public threadManager(GamePlayerClient inputGamePlayerClient) {
			getData.start();
			this.gamePlayerClient = inputGamePlayerClient;
		}

		/**
		 * This method stops the thread
		 */
		public void stopThreads() {
			getData.interrupt();
		}

		// To get objects from other client (ValidityResult to check if the
		// guess is true)
		Thread getData = new Thread(new Runnable() {

			@Override
			public synchronized void run() {
				while (true) {
					switcher();
				}
			}
		});

		/**
		 * This method handles all the data that is being received and uses a
		 * switch case to distinguished what steps or methods to use when
		 * handling the different data switch code it received.
		 */
		private void switcher() {
			try {
				Data tempDataPackage = (Data) inObject.readObject();
				switch (tempDataPackage.getSwitchCode()) {
				case 0:

					if (isPlaying && !p2pane.isGameOver()) {
						p2pane.setAmIWinner(true);
						p2pane.setIsGameOver(true);
						p2pane.whoWins();
					}
					JOptionPane.showMessageDialog(null,
							"Your opponent left the game!");

					sendData(0, "closing");
					setShips.dispose();
					stopThreads();
					// If it is playing, it doesn't make new client;
					if (!isPlaying) {

						GamePlayerClient gpc = new GamePlayerClient();
						if (gpc.connectServer(ip)){
							gpc.startClient();
						}
					}
					break;
				case 1:
					opponentPlayer = (Player) tempDataPackage.getData();
					setShips.setOpponentPlayer(opponentPlayer);

					JOptionPane.showMessageDialog(null, "Your opponent "
							+ opponentPlayer.getNickname() + " is Ready!");
					break;

				case 2:
					opponentCoordinate = (Point) tempDataPackage.getData();
					p1pane.updateBoard(opponentCoordinate);
					break;

				case 3:
					if (counter == 0) {
						isMyTurn = (boolean) tempDataPackage.getData();
						counter++;
					} else {
						// If block is used to prevent
						// java.lang.IllegalThreadStateException
						isMyTurn = (boolean) tempDataPackage.getData();
						p2pane.setMyTurn(isMyTurn);
						if (isMyTurn) {
							if (player.hasShipsRemaining()) {
								p2pane.enableEdit();
							} else {
								// When user loses the game
								p2pane.setIsGameOver(true);
								p2pane.setAmIWinner(false);
								sendData(6, true);
							}
						}

					}

					break;

				case 4:
					String chatText = (String) tempDataPackage.getData();
					DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
					Date dateobj = new Date();
					if ((chatText != null) && (p2pane != null)) {
						grid.getChatBox().append(
								"\n" + df.format(dateobj) + " - <"
										+ p2pane.getPlayer().getNickname()
										+ "> : " + chatText);
					}
					break;

				case 5:
					opponentIsPlaying = (boolean) tempDataPackage.getData();

					break;

				case 6:
					p2pane.setAmIWinner((boolean) tempDataPackage.getData());
					p2pane.setIsGameOver(true);
					// setMyTurn is used to update the label for displaying
					// "You win"
					p2pane.setMyTurn(true);

					break;
				case 7:
					if (tempDataPackage.getData() != null) {
						JOptionPane.showMessageDialog(null, "Your "
								+ (String) tempDataPackage.getData()
								+ " has been destroyed!", "Ship destroyed!",
								JOptionPane.INFORMATION_MESSAGE, new ImageIcon(
										"Images/skull.png"));
					}
					break;
				// Exception. If unknown data is delivered.
				default:
					break;

				}
			} catch (ClassNotFoundException | IOException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * This method checks if there is a opponent connected to the server
	 *
	 * @return Boolean value to see if someone is connected
	 */
	public boolean opponentIsPlaying() {
		return this.opponentIsPlaying;
	}

	public void closeSockets() {
		try {
			inObject.close();
			outObject.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}