package lecho.lib.hellocharts.util;

/**
 * A simple class representing axis label values used only for auto generated axes.
 */
public class AxisAutoValues {
    public float[] values = new float[]{};
    public int valuesNumber;
    public int decimals;
}
