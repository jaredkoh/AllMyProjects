package team2c.com.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by Ainura on 21.11.2014.
 * Contains major data structures for the entire app
 */
public class AppDST {

    //This is a list of all countries Key: Name, Values: Country
    public static Map<String, Country> countryMap = new HashMap<String, Country>();

    //This is a list of all selected countries, see countryMap for definitions.
    public static Map<String, Country> selectedCountriesMap = new HashMap<String, Country>();

    //This is a list of all climate change indicators Key: Name, Values: Indicator
    public static Map<String, Indicator> indicatorMap = new HashMap<String, Indicator>();

    //This is a list of all the names of indicators, which will be displayed in
    // SelectIndicatorActivity
    public static ArrayList<Indicator> allIndicatorsList;

    //This is a list of all the names of indicators, which will be displayed in
    // SelectCountryActivity
    public static ArrayList<Country> allCountriesList;

    /*Stores the Indicator selected for x-axis */
    public static Indicator xIndicator = new Indicator("no selection");

    /*Stores the Indicator selected for y-axis */
    public static Indicator yIndicator = new Indicator("no selection");

    /* Stores the Indicator selected for z-axis */
    public static Indicator zIndicator = new Indicator("no selection");

    /**
     * Sorts a list of countries alphabetically using a bucket sort
     * Used when outputting the map of countries so that they aren't ordered by the hash value
     *
     * @param input An ordered list
     * @return An ordered list
     */
    public static ArrayList<Country> sortCountries(ArrayList<Country> input) {
        ArrayList<Country> output = new ArrayList<Country>();
        Country[] tmpList = new Country[input.size()];

        for (Country eachCountry : input) {
            tmpList[eachCountry.getOrderingIndex()] = eachCountry;
        }

        for (Country eachCountry : tmpList) {
            output.add(eachCountry);
        }

        return output;
    }
}
