package team2c.com.model;

import android.graphics.Color;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Random;

import lecho.lib.hellocharts.model.BubbleValue;

/**
 * Created by Nand on 20/11/14.
 * This is a model represenation of a country, as according to the World Bank
 */
public class Country implements Serializable {


    private String id = "";
    private String name = "";
    private final int orderingIndex; //this is an index that specifes each country's location in
    // an array when sorted alphabetically
    private Point[] yearData;
    private int color;
    private BubbleValue bubbleValue;
    private HashMap<Indicator, String> dataForIndicator = new HashMap<Indicator, String>();

    private void constantConstructing() {
        //colour
        Random random = new Random();
        int r = random.nextInt(256);
        int g = random.nextInt(256);
        int b = random.nextInt(256);
        color = Color.argb(255, r, g, b);

        //list of points, for each of the 55 years
        yearData = new Point[55];
        for (int i = 0; i < yearData.length; i++) {
            yearData[i] = new Point(0.0f, 0.0f, 0.0f);
        }
        dataForIndicator = new HashMap<Indicator, String>();
    }

    public Country(int index) {

        orderingIndex = index;

        constantConstructing();
    }
    public BubbleValue getBubbleValue() { return bubbleValue; }

    public void setBubbleValue(BubbleValue bubbleValue) {
        this.bubbleValue = bubbleValue;
    }

    public int getColor() {
        return color;
    }

    public String getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setID(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrderingIndex() {
        return orderingIndex;
    }

    public String toString() {
        return name;
    }

    public Country(CountryDownload countryDown) {

        this.name = countryDown.getName();
        this.id = countryDown.getId();
        this.orderingIndex = countryDown.getIndex();

        constantConstructing();

    }

    /**
     * Sets the list of data for the current indicators
     *
     * @param data      The list of values
     * @param indicator Which indicator to update
     */
    public void setYearData(float[] data, int indicator) {
        for (int eachYear = 0; eachYear < data.length; eachYear++) {
            yearData[eachYear].setData(data[eachYear], indicator);
        }
    }

    /**
     * Get the current indicators' data for a particular year
     *
     * @param year The current year, or year of selection
     * @return The data
     */
    public float[] getYearData(int year) {
        //this will now set any unset indicators to vallues to 0
        float[] output = new float[3];
        Point specifiedYear = yearData[year - 1963];

        if (!(AppDST.xIndicator.getName().equals("no selection"))) {
            output[0] = specifiedYear.getX();
        } else {
            output[0] = 0.0f;
        }

        if (!(AppDST.yIndicator.getName().equals("no selection"))) {
            output[1] = specifiedYear.getY();
        } else {
            output[1] = 0.0f;
        }

        if (!(AppDST.zIndicator.getName().equals("no selection"))) {
            output[2] = specifiedYear.getZ();
        } else {
            output[2] = 0.0f;
        }
        return output;
    }


    public void setDataForSpecificIndicator(Indicator indicator, String data) {
        dataForIndicator.put(indicator, data);
    }

//    public void addIndicatorToCountry(Indicator indicator){
//        listOfIndicatorsForCountry.add(indicator);
//    }

    /**
     * get the data for specific indicator for the specific country
     *
     * @return Hashmap<Indicator , float[]> linking the indicator to the data.
     */
    public HashMap<Indicator, String> getDataForIndicator() {
        return dataForIndicator;
    }

    /**
     * gets indicators that were selected before for the country
     * @return ArrayList of indicators
     */
//    public ArrayList<Indicator> getListOfIndicatorsForCountry(){
//        return listOfIndicatorsForCountry;
//    }


}
