package team2c.com.model;

/**
 * Created by iHack1337 on 11/25/2014.
 */
public class Point {

    private float x;
    private float y;
    private float z;

    public Point(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getZ() {
        return z;
    }

    public void setZ(float z) {
        this.z = z;
    }

    public void setData(float data, int indicator) {
        switch (indicator) {
            case (Indicator.X):
                setX(data);
                break;
            case (Indicator.Y):
                setY(data);
                break;
            case (Indicator.Z):
                setZ(data);
                break;
        }
    }
}
