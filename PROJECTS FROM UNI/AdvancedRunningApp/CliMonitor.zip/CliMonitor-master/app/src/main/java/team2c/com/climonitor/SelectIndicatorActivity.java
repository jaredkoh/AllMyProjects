package team2c.com.climonitor;

import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBarActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

import team2c.com.model.AppDST;
import team2c.com.model.Indicator;

public class SelectIndicatorActivity extends ActionBarActivity implements IndicatorDialogFragment
        .OnHeadlineSelectedListener {
    /*reference to the Indicator which has been selected by the user*/
    private Indicator selectedIndicator;
    static HashMap<String, String> selectedIndicators = new HashMap<String, String>();
    ArrayList<Indicator> allIndicatorsList;
    ArrayAdapter<Indicator> adapter;
    String searchTerm = "";
    ArrayList<Indicator> filteredIndicators;
    SelectIndicatorActivity selectIndicatorActivity = this;
    SearchView searchView;

    private static Indicator indicatorX;
    private static Indicator indicatorY;
    private static Indicator indicatorZ;
    private ListView indicatorListView;
    static boolean[] checkedAxes = new boolean[3];
    /*Stores the last selected Indicator for x axis*/
    static public Indicator previousValueIndicatorX = AppDST.xIndicator;
    /*Stores the last selected Indicator for y axis*/
    static public Indicator previousValueIndicatorY = AppDST.yIndicator;

    static public Indicator previousValueIndicatorZ = AppDST.zIndicator;

    FragmentManager fm = getSupportFragmentManager();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        indicatorListView = new ListView(this);
        setContentView(indicatorListView);
        //android.app.ActionBar actionBar = getActionBar();
        // Enabling Back navigation on Action Bar icon
        //actionBar.setDisplayHomeAsUpEnabled(true);

        if (indicatorX == null)
            indicatorX = previousValueIndicatorX;
        if (indicatorY == null)
            indicatorY = previousValueIndicatorY;
        if (indicatorZ == null)
            indicatorZ = previousValueIndicatorZ;

        selectedIndicators.put(Indicator.X + "", indicatorX.getName());
        selectedIndicators.put(Indicator.Y + "", indicatorY.getName());
        selectedIndicators.put(Indicator.Z + "", indicatorZ.getName());
        if (!isConnected()) {
            Toast.makeText(this, "No Internet Connection, data maybe out of date.",
                    Toast.LENGTH_SHORT).show();
        }

        //updates the GUI list model
        updateListModel();

        searchTerm = "";

        setChecked();

        Log.e("SELECTED_INDICATORS_ONCREATE", selectedIndicators.toString());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_select_indicator, menu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        MenuItem searchItem = menu.findItem(R.id.action_search_indicator);
        searchView = (SearchView) MenuItemCompat.getActionView(searchItem);

        SearchableInfo searchableInfo = searchManager.getSearchableInfo((getComponentName()));
        searchView.setSearchableInfo(searchableInfo);

        searchListener();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings || id == R.id.action_search) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onPause() {
        super.onPause();
        if (indicatorX == null)
            indicatorX = previousValueIndicatorX;
        selectedIndicators.put(Indicator.X + "", indicatorX.getName());

        if (indicatorY == null)
            indicatorY = previousValueIndicatorY;
        selectedIndicators.put(Indicator.Y + "", indicatorY.getName());

        if (indicatorZ == null)
            indicatorZ = previousValueIndicatorZ;
        selectedIndicators.put(Indicator.Z + "", indicatorZ.getName());

        AppDST.xIndicator = indicatorX;
        AppDST.yIndicator = indicatorY;
        AppDST.zIndicator = indicatorZ;

        Log.e("SELECTED_INDICATORS_ONPAUSE", selectedIndicators.toString());
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    public void searchListener() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (TextUtils.isEmpty(newText)) {
                    filteredIndicators = allIndicatorsList;
                    searchTerm = "";
                    adapter.getFilter().filter("");
                    setChecked();
                } else {
                    searchTerm = newText;
                    adapter.getFilter().filter(newText);
                    setChecked();
                }
                return true;
            }
        });
    }

    public void setChecked() {
        filterBySearch(searchTerm);
        for (int i = 0; i < adapter.getCount(); i++) {
            String indicatorName = ((Indicator) adapter.getItem(i)).getName();
            if (selectedIndicators.get(Indicator.X + "").equals(indicatorName) ||
                    selectedIndicators.get(Indicator.Y + "").equals(indicatorName) ||
                    selectedIndicators.get(Indicator.Z + "").equals(indicatorName)) {
                indicatorListView.setItemChecked(i, true);
            } else {
                indicatorListView.setItemChecked(i, false);
            }
        }
    }

    public void filterBySearch(final String searchTerm) {
        filteredIndicators = new ArrayList<Indicator>();
        for (Indicator i : allIndicatorsList) {
            String[] splitIndicatorName = i.getName().split(" ");
            for (String s : splitIndicatorName) {
                if (s.toLowerCase().startsWith(searchTerm.toLowerCase())) {
                    filteredIndicators.add(i);
                    break;
                }
            }
        }
    }

    /* Updates the GUI list to the latest list of indicators
    */

    public void updateListModel() {
        allIndicatorsList = AppDST.allIndicatorsList;
        filteredIndicators = allIndicatorsList;

        //sets the list model to the list of indicators
        adapter = (new ArrayAdapter<Indicator>(selectIndicatorActivity,
                android.R.layout.simple_list_item_multiple_choice, android.R.id.text1,
                filteredIndicators) {

            @Override
            public Indicator getItem(int position) {
                return filteredIndicators.get(position);
            }

            @Override
            public int getCount() {
                return filteredIndicators.size();
            }
        });
        indicatorListView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        indicatorListView.setAdapter(adapter);
        indicatorListView.setTextFilterEnabled(true);

        //action listener for when the user clicks on an element of the list
        indicatorListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position,
                                    long l) {
                selectedIndicator = (Indicator) adapter.getItem(position);

                IndicatorDialogFragment alertdFragment = new IndicatorDialogFragment();
                Bundle dialogBundle = new Bundle();
                checkedAxes[0] = indicatorX == selectedIndicator;
                checkedAxes[1] = indicatorY == selectedIndicator;
                checkedAxes[2] = indicatorZ == selectedIndicator;

                dialogBundle.putBooleanArray("checkedAxes", checkedAxes);
                dialogBundle.putInt("position", position);

                alertdFragment.setArguments(dialogBundle);
                // Show Alert DialogFragment
                alertdFragment.onAttach(SelectIndicatorActivity.this);
                Log.e("CHECKED_INDICATORS", selectedIndicators.toString());
                Log.e("CHECKED_AXES_BEFORE_PASSING", checkedAxes[0] + " " + checkedAxes[1] + " "
                        + checkedAxes[2]);
                alertdFragment.show(fm, "Select axis");
            }
        });
    }

    @Override
    public void changeZ(boolean[] checked, int position) {
        if (checked[0] == true || checked[1] == true)
            indicatorListView.setItemChecked(position, true);
        else
            indicatorListView.setItemChecked(position, false);

        if (selectedIndicator != indicatorZ) {
            indicatorZ = selectedIndicator;
            selectedIndicators.put(Indicator.Z + "", indicatorZ.getName());
        } else {
            indicatorZ = previousValueIndicatorZ;
            selectedIndicators.put(Indicator.Z + "", indicatorZ.getName());
        }
        setChecked();
    }

    @Override
    public void changeX(boolean[] checked, int position) {
        if (checked[0] == true || checked[1] == true)
            indicatorListView.setItemChecked(position, true);
        else
            indicatorListView.setItemChecked(position, false);

        if (selectedIndicator != indicatorX) {
            indicatorX = selectedIndicator;
            selectedIndicators.put(Indicator.X + "", indicatorX.getName());
        } else {
            indicatorX = previousValueIndicatorX;
            selectedIndicators.put(Indicator.X + "", indicatorX.getName());
        }
        setChecked();
    }

    @Override
    public void changeY(boolean[] checked, int position) {
        if (checked[0] == true || checked[1] == true)
            indicatorListView.setItemChecked(position, true);
        else
            indicatorListView.setItemChecked(position, false);

        if (selectedIndicator != indicatorY) {
            indicatorY = selectedIndicator;
            selectedIndicators.put(Indicator.Y + "", indicatorY.getName());
        } else {
            indicatorY = previousValueIndicatorY;
            selectedIndicators.put(Indicator.Y + "", indicatorY.getName());
        }

        setChecked();
    }

    @Override
    public void reCheck(boolean[] checked, int position) {
        if (checked[0] == true || checked[1] == true)
            indicatorListView.setItemChecked(position, true);
        else
            indicatorListView.setItemChecked(position, false);
    }

    /**
     * checks current network access
     *
     * @return A true/false state depending upon current network access
     */
    public boolean isConnected() {
        /** Checking if user has internet connection **/
        //Giving the line that notifies the application when network changes
        ConnectivityManager connectionManager = (ConnectivityManager) getSystemService(this
                .CONNECTIVITY_SERVICE);
        //Sends back details that are currently active about the network.
        NetworkInfo networkInformation = connectionManager.getActiveNetworkInfo();
        //If the network information is not null and that it is connected, then notify user.
        if (networkInformation != null && networkInformation.isConnected()) {
            return true;
        } else {
            return false;
        }
    }
}