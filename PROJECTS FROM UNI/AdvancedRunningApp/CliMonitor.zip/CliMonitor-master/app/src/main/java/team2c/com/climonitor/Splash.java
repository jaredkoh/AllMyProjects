package team2c.com.climonitor;


import android.app.Activity;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import team2c.com.model.AppDST;
import team2c.com.model.Country;
import team2c.com.model.Indicator;


/**
 * Splash screen; this downloads/loads from file the countries and indicators
 */
public class Splash extends Activity {

    private FileHandling files = new FileHandling(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        loadData();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_splash, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Calls methods that load data depending upon connection
     */
    public void loadData() {
        if (isConnected()) {
            new JSONparse().execute();
            Log.d("Splash", "online");
        } else {
            files.readingIndicators();
            files.readingCountries();
            files.readingData();
            Log.d("Splash", "offline");

            AppDST.allIndicatorsList = new ArrayList<Indicator>(AppDST.indicatorMap.values());
            //AppDST.allCountriesList = new ArrayList<Country>(AppDST.countryMap.values());
            Collections.sort(AppDST.allIndicatorsList);
            Map<String, Country> tmpCountries = new TreeMap<String, Country>(AppDST.countryMap);
            AppDST.allCountriesList = new ArrayList<Country>(tmpCountries.values());
            //AppDST.allCountriesList = AppDST.sortCountries(AppDST.allCountriesList);

            createGraphActivity();
        }
    }

    /**
     * checks current network access
     *
     * @return A true/false state depending upon current network access
     */
    public boolean isConnected() {
        /** Checking if user has internet connection **/

        //Giving the line that notifies the application when network changes
        ConnectivityManager connectionManager = (ConnectivityManager) this.getSystemService(this
                .CONNECTIVITY_SERVICE);

        //Sends back details that are currently active about the network.
        NetworkInfo networkInformation = connectionManager.getActiveNetworkInfo();

        //If the network information is not null and that it is connected, then notify user.
        if (networkInformation != null && networkInformation.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    private void createGraphActivity() {
        Intent intentGraphActivity = new Intent(getApplicationContext(), GraphActivity.class);
        startActivity(intentGraphActivity); //starting new activity
        finish(); //closes splash once finished
    }

    /**
     * This threads handles the getting of the list of countries from the World Bank
     * and parsing the returned JSON file
     */
    private class JSONparse extends AsyncTask<String, Void, Boolean> {
        String JSONstring = "";
        Map<String, Country> foundCountries = new HashMap<String, Country>();
        Map<String, Indicator> foundIndicators = new HashMap<String, Indicator>();

        @Override
        protected Boolean doInBackground(String... strings) {
            downloadCountries();
            downloadIndicators();
            return null;
        }

        private void downloadCountries() {
            try {
                String url = "http://api.worldbank.org/country?per_page=300&format=json";
                JSONstring = JsonHandling.request(url);
            } catch (IOException e) {
                Log.e("IOException", "", e);
            }
            foundCountries = JsonHandling.requestJSONforCountries(JSONstring);
        }

        private void downloadIndicators() {
            try {
                String url = "http://api.worldbank.org/topic/19/indicator?per_page=76&format=json";
                JSONstring = JsonHandling.request(url);
            } catch (IOException e) {
                Log.e("IOException", "", e);
            }
            foundIndicators = JsonHandling.requestJSONforIndicators(JSONstring);
        }

        @Override
        protected void onPostExecute(Boolean aBoolean) {
            Log.d("Splash", "onPostExecute");

            //updates apps main data structures for all countries to newly found list
            AppDST.countryMap = foundCountries;
            AppDST.indicatorMap = foundIndicators;

            //stores indicators in the data structures in ArrayList of String for front end use
            AppDST.allIndicatorsList = new ArrayList<Indicator>(AppDST.indicatorMap.values());
           // AppDST.allCountriesList = new ArrayList<Country>(AppDST.countryMap.values());

            Map<String, Country> tmpCountries = new TreeMap<String, Country>(foundCountries);
            AppDST.allCountriesList = new ArrayList<Country>(tmpCountries.values());
            //AppDST.allCountriesList = AppDST.sortCountries(AppDST.allCountriesList);
            //Sorts arraylist of names of indicators, whereas hashmap stays unsorted!
            Collections.sort(AppDST.allIndicatorsList);

            files.storeCountries();
            files.storeIndicators();
            //this will be for storing the indicators

//            files.readingData();

            createGraphActivity();
        }
    }

}




