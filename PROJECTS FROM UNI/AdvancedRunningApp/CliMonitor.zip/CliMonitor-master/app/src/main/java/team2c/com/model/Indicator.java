package team2c.com.model;

import java.io.Serializable;

/**
 * Created by jaredkoh on 21/11/14.
 * This is model representation of a World Bank indicator
 */
public class Indicator implements Serializable, Comparable {

    public static final int X = 0;
    public static final int Y = 1;
    public static final int Z = 2;

    private String id = "";
    private String name = "";
    private int orderingIndex; //this is an index that specifes each indicators's location in an
    // array when sorted alphabetically

    public Indicator() {
    }

    public Indicator(int index) {
        orderingIndex = index;
    }

    public Indicator(String name) {
        this.name = name;
    }

    public int getOrderingIndex() {
        return orderingIndex;
    }

    public void setOrderingIndex(int index) {
        this.orderingIndex = index;
    }

    public String getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String toString() {
        return name;
    }

    @Override
    public int compareTo(Object another) {
        return this.toString().compareTo(another.toString());
    }

}
