package team2c.com.climonitor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.util.Log;

/**
 * Created by Ainura on 29.11.2014.
 */
public class IndicatorDialogFragment extends DialogFragment {
    OnHeadlineSelectedListener mCallback;
    boolean[] checkedAxes;
    int position;
    boolean[] checkedAxesAux = new boolean[3];

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Bundle dialogBundle = getArguments();
        position = dialogBundle.getInt("position");
        checkedAxes = dialogBundle.getBooleanArray("checkedAxes");
        checkedAxesAux[0] = checkedAxes[0];
        checkedAxesAux[1] = checkedAxes[1];
        checkedAxesAux[2] = checkedAxes[2];
        Log.e("CHECKED_AXES", checkedAxes[0] + " " + checkedAxes[1] + " " + checkedAxes[2]);
        final boolean[] isChanged = {false, false, false};
        final String[] axesName = {"X-axis", "Y-axis", "Z-axis (bubble size)"};
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity())
                .setTitle("Select axis")
                        // Set Dialog Message
                .setMultiChoiceItems(axesName, checkedAxesAux,
                        new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int which, boolean isChecked) {
                                if (isChanged[which] == false) {
                                    isChanged[which] = true;
                                } else {
                                    isChanged[which] = false;
                                }
                            }
                        })
                        // SET button
                .setPositiveButton("SET",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog,
                                                int id) {
                                checkedAxes = checkedAxesAux;
                                if (isChanged[0]) {
                                    mCallback.changeX(checkedAxes, position);
                                }
                                if (isChanged[1]) {
                                    mCallback.changeY(checkedAxes, position);
                                }
                                if (isChanged[2]) {
                                    mCallback.changeZ(checkedAxes, position);
                                }
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        return alertDialog;
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        mCallback.reCheck(checkedAxes, position);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception
        try {
            mCallback = (OnHeadlineSelectedListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement OnHeadlineSelectedListener");
        }
    }

    // Container Activity must implement this interface
    public interface OnHeadlineSelectedListener {
        public void changeX(boolean[] checked, int position);

        public void changeY(boolean[] checked, int position);

        public void changeZ(boolean[] checked, int position);

        public void reCheck(boolean[] checked, int position);

    }
}
