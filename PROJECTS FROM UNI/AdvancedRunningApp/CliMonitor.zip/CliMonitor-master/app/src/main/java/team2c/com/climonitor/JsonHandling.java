package team2c.com.climonitor;

import android.util.Log;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import team2c.com.model.Country;
import team2c.com.model.Indicator;

/**
 * Created by jaredkoh on 17/11/14.
 * This class handles parsing of JSON files and performing requests on the World Bank data set
 */
public class JsonHandling {
//    public static String result = ""; //return variable

    /**
     * Make a network call to the uri, and return the results
     *
     * @return the data from the URI
     * @throws org.apache.http.client.ClientProtocolException if we have any trouble making the
     *                                                        network call
     * @throws java.io.IOException                            if we have any trouble making the
     *                                                        network call
     */
    public static String requestData(String countryId, String indicatorId) throws
            ClientProtocolException, IOException {

        //build uri from params
        String uri = "http://api.worldbank.org/country/" + countryId + "/indicator/" +
                indicatorId + "?format=json&per_page=100";

        HttpGet httpGet = new HttpGet(uri); // make a get call to http
        ResponseHandler<String> responseHandler = new BasicResponseHandler(); // handle the
        // response  that we get in return
        HttpClient httpClient = new DefaultHttpClient(); //create an httpclient ,
        // which will coordinate the get and response
        String result = httpClient.execute(httpGet, responseHandler); //send the uri to the get
        // method , have a response handler parse it and return a result to us
        return result;
    }

    public static String request(String uri) throws ClientProtocolException, IOException {

        //build uri from params
        HttpGet httpGet = new HttpGet(uri); // make a get call to http
        ResponseHandler<String> responseHandler = new BasicResponseHandler(); // handle the
        // response  that we get in return
        HttpClient httpClient = new DefaultHttpClient(); //create an httpclient ,
        // which will coordinate the get and response
        String result = httpClient.execute(httpGet, responseHandler); //send the uri to the get
        // method , have a response handler parse it and return a result to us
        return result;
    }

    public static float[] requestJSONforData(String jsonString) {
        float[] data = new float[55];
        Log.d("JsonHandling","Parsing JSON String" + jsonString);

        //this is if the user selects an indicator that hasn't been previously downloaded, when offline
        if(jsonString == null) {
            for(int i = 0;i<55;i++) {
                data[i] = 0.0f;
            }
            return data;
        }

        try {
            JSONArray jsonArray = new JSONArray(jsonString);
            JSONArray dataArray = jsonArray.getJSONArray(1);

            for (int i = 0; i < dataArray.length(); i++) {
                JSONObject dataEntry = dataArray.getJSONObject(i);
                String s = dataEntry.getString("value");
                if (!s.equals("null")) {
                    float entryValue = Float.parseFloat(s);
//                    Log.v("checking", entryValue + "");
                    data[i] = entryValue;

                } else {
                    data[i] = (float) 0.00;
//                    Log.v("checking", "null data");
                }

                //adds data entry to temporary arraylist

            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return data;
    }

    /**
     * Gets all of the countries within the JSON, excluding those that are groups of countries
     *
     * @param JSONstring The JSON String containing all countries
     * @return Map of all found countries within the given JSON String
     */
    public static Map<String, Country> requestJSONforCountries(String JSONstring) {
        Map<String, Country> foundCountries = new HashMap<String, Country>();
        int numOfCountriesCounter = 0;

        try {
            JSONArray jsonArray = new JSONArray(JSONstring);
            JSONArray countriesArray = jsonArray.getJSONArray(1);
            for (int i = 0; i < countriesArray.length(); i++) {
                JSONObject eachCountry = countriesArray.getJSONObject(i);
                if (!eachCountry.getString("longitude").equals("")) { //if it is actually a
                    // country and not a group
                    Country newCountry = new Country(numOfCountriesCounter++);
                    newCountry.setName(eachCountry.getString("name"));
                    newCountry.setID(eachCountry.getString("id"));
                    foundCountries.put(newCountry.getName(), newCountry);
                    //adds countries to temporary map
                }

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return foundCountries;
    }

    /**
     * Gets all of the indicators within the JSON, only inlcuding those that having "Climate
     * Change" as one of their topics
     *
     * @param JSONstring The JSON String containing all indicators
     * @return Map of all found indicators within the given JSON String
     */
    public static Map<String, Indicator> requestJSONforIndicators(String JSONstring) {
        Map<String, Indicator> foundIndicators = new HashMap<String, Indicator>();
        int numOfIndicators = 0;

        try {
            JSONArray tmpArray = new JSONArray(JSONstring);
            JSONArray indicatorsArray = tmpArray.getJSONArray(1);
            for (int i = 0; i < indicatorsArray.length(); i++) {
                //for each indicator

                JSONObject eachIndicator = indicatorsArray.getJSONObject(i);
                JSONArray topicArray = eachIndicator.getJSONArray("topics"); //get
                // eachIndicator's list of topics
                for (int j = 0; j < topicArray.length(); j++) {
                    JSONObject topic = topicArray.getJSONObject(j);
                    Indicator newIndicator = new Indicator(numOfIndicators++);
                    newIndicator.setName(eachIndicator.getString("name"));
                    newIndicator.setId(eachIndicator.getString("id"));
                    foundIndicators.put(newIndicator.getName(), newIndicator);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return foundIndicators;
    }
}
