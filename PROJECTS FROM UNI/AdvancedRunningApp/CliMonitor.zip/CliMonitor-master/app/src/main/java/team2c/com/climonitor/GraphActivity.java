package team2c.com.climonitor;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.BubbleChartData;
import lecho.lib.hellocharts.model.BubbleValue;
import lecho.lib.hellocharts.util.Utils;
import lecho.lib.hellocharts.view.BubbleChartView;
import team2c.com.model.AppDST;
import team2c.com.model.Country;
import team2c.com.model.Indicator;

public class GraphActivity extends Activity {

    Activity thisActivity = this;

    int currentYear = 2013;
    //list of all years that we have data for (1963-2013)
    ArrayList<String> yearArray;
    static int ok = 0;
    TextView X_Value;
    TextView Y_Value;
    TextView Z_Value;
    SeekBar seekBar;
    Spinner spinner;
    ArrayAdapter<String> dataAdapter;

    BubbleChartView chart;
    BubbleChartData dataModel;
    List<BubbleValue> bubbleList;
    TextView currentCountry;
    private boolean isPlaying = false;
    private PlayTime time;
    private Timer timer;
    boolean landscape = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphing);
        ActionBar graphBar = getActionBar();
        graphBar.hide();

        X_Value = (TextView) findViewById(R.id.X_Value);
        Y_Value = (TextView) findViewById(R.id.Y_Value);
        Z_Value = (TextView) findViewById(R.id.Z_Value);

        currentCountry = (TextView) findViewById(R.id.currentCountry);
        currentCountry.setTextColor(Color.WHITE);
        currentCountry.setTextSize(35);
        currentCountry.setText("Tap A Bubble");
        Typeface font = Typeface.createFromAsset(getAssets(), "Purista Semibold.ttf");
        currentCountry.setTypeface(font);

        chart = (BubbleChartView) findViewById(R.id.chart);
        dataModel = new BubbleChartData();

        yearArray = new ArrayList<String>();
        for (int i = 2013; i > 1963; i--) {
            yearArray.add(String.valueOf(i));
        }
        spinner = (Spinner) findViewById(R.id.year_spinner);
        seekBar = (SeekBar) findViewById(R.id.seekBar);

        dataAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, yearArray);
        chart = (BubbleChartView) findViewById(R.id.chart);
        spinerGraphUpdate();
        seekBarGraphUpdate();
        updateGraph();

        Spinner spinner = (Spinner) findViewById(R.id.year_spinner);
        final ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>
                (this, android.R.layout.simple_spinner_item, yearArray);

        dataAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setPrompt("Choose a year");
        spinner.setAdapter(dataAdapter);
        chart = (BubbleChartView) findViewById(R.id.chart);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (getResources().getConfiguration().orientation == Configuration
                        .ORIENTATION_LANDSCAPE) {
                    landscape = true;
                    seekBar.setProgress(49 - position);
                }
                currentYear = 2014 - position;
                Iterator allSelectedCountries = AppDST.selectedCountriesMap.entrySet().iterator();
                while (allSelectedCountries.hasNext()) {
                    Map.Entry eachElement = (Map.Entry) allSelectedCountries.next();
                    Country eachCountry = (Country) eachElement.getValue();
                    Log.v("check for countries", eachCountry.getName());
                    float[] yearData = eachCountry.getYearData(currentYear);
                    if (yearData != null) {
                        //add the country to the list of bubbles
                        BubbleValue bubbleValue = eachCountry.getBubbleValue();
                        if (bubbleValue != null)
                            bubbleValue.setTarget(yearData[0], yearData[1],
                                    yearData[2]);
                    }
                }
                chart.startDataAnimation();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_graph, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates a new SelectCountryActivity
     */

    public void selectCountryClick(View view) {
        startActivity(new Intent(this, SelectCountryActivity.class));
    }

    /**
     * Creates a new SelectIndicatorActivity
     */
    public void selectIndicatorClick(View view) {
        startActivity(new Intent(this, SelectIndicatorActivity.class));
    }

    //************************************************
    //GRAPH HANDLING

    /**
     * Updates the model for the graph
     */
    public void updateGraph() {
        bubbleList = new ArrayList<BubbleValue>();

        //for each selected country
        Iterator allSelectedCountries = AppDST.selectedCountriesMap.entrySet().iterator();
        while (allSelectedCountries.hasNext()) {
            Map.Entry eachElement = (Map.Entry) allSelectedCountries.next();
            Country eachCountry = (Country) eachElement.getValue();
            Log.v("check for countries", eachCountry.getName());
            float[] yearData = eachCountry.getYearData(currentYear);
            if (yearData != null) {
                //add the country to the list of bubbles
                BubbleValue eachCountryBubble = new BubbleValue(yearData[0], yearData[1],
                        yearData[2], Utils.COLOR_BLUE);
                eachCountryBubble.setColor(eachCountry.getColor());
                eachCountry.setBubbleValue(eachCountryBubble);
                Log.v("Adding countries to graph ", eachCountry.getName() + ": " + yearData[0] +
                        " " + yearData[1] + " " + yearData[2]);

                bubbleList.add(eachCountryBubble);
                // prepareDataForAnimation(yearData);


            }


        }
        dataModel.setValues(bubbleList);

        BubbleChartData dataModel = new BubbleChartData(bubbleList);
        //set x axis
        Axis xAxis = new Axis();
        xAxis.setTextSize(10);
        xAxis.setAutoGenerated(true);
        xAxis.setName(AppDST.xIndicator.getName());
        xAxis.setTextColor(Color.parseColor("#27ae60"));
        dataModel.setAxisXBottom(xAxis);

        //set y axis
        Axis yAxis = new Axis();
        yAxis.setTextSize(10);
        yAxis.setAutoGenerated(true);
        yAxis.setHasLines(true);
        yAxis.setName(AppDST.yIndicator.getName());
        yAxis.setInside(true);
        yAxis.setTextColor(Color.parseColor("#F0A804"));
        dataModel.setAxisYLeft(yAxis);

        chart.setBubbleChartData(dataModel);
        chart.setOnValueTouchListener(new BubbleChartView.BubbleChartOnValueTouchListener() {

            @Override
            public void onValueTouched(int selectedBubble, BubbleValue value) {
                X_Value.setText("" + value.getX());
                Y_Value.setText("" + value.getY());
                Z_Value.setText("" + value.getZ());

                // TextView currentCountry = (TextView) vp.findViewWithTag("CURRENT_COUNTRY");
                currentCountry.setTextColor(value.getColor());
                Iterator countries = AppDST.selectedCountriesMap.values().iterator();
                while (countries.hasNext()) {
                    Country eachCountry = (Country) countries.next();
                    if (eachCountry.getColor() == value.getColor()) {
                        if (eachCountry.getName().length() > 21) {
                            if (landscape)
                                currentCountry.setTextSize(17);
                            else
                                currentCountry.setTextSize(23);
                            currentCountry.setText("- " + eachCountry.getName() + " -");
                        } else if (eachCountry.getName().length() > 17) {
                            if (landscape)
                                currentCountry.setTextSize(23);
                            else
                                currentCountry.setTextSize(30);
                            currentCountry.setText("- " + eachCountry.getName() + " -");
                        } else {
                            if (landscape)
                                currentCountry.setTextSize(30);
                            else
                                currentCountry.setTextSize(35);
                            currentCountry.setText("- " + eachCountry.getName() + " -");
                        }
                    }
                }
                // vp.getAdapter().notifyDataSetChanged();
            }

            @Override
            public void onNothingTouched() {

            }
        });
    }


    /**
     * Runs the bacjground tasks of downloading data and updates graph accordingly when finished
     */
    private class updateDataModel extends AsyncTask<String, Void, Boolean> {

        @Override
        protected Boolean doInBackground(String... params) {
            //for all selected countries
            Iterator allSelectedCountries = AppDST.selectedCountriesMap.entrySet().iterator();
            while (allSelectedCountries.hasNext()) {
                Map.Entry eachElement = (Map.Entry) allSelectedCountries.next();
                Country eachCountry = (Country) eachElement.getValue();

                //get the latest data
                try {
                    float[] xData = checkIfDataIsAvailable(eachCountry, AppDST.xIndicator);
                    float[] yData = checkIfDataIsAvailable(eachCountry, AppDST.yIndicator);
                    float[] zData = checkIfDataIsAvailable(eachCountry, AppDST.zIndicator);

                    Log.d("updateDataModel", "xData = " + xData[xData.length - 1] + " " +
                            xData[1] + "...");
                    Log.d("updateDataModel", "yData = " + yData[yData.length - 1] + " " +
                            yData[1] + "...");
                    Log.d("updateDataModel", "zData = " + zData[zData.length - 1] + " " +
                            zData[1] + "...");

                    eachCountry.setYearData(xData, Indicator.X);
                    eachCountry.setYearData(yData, Indicator.Y);
                    eachCountry.setYearData(zData, Indicator.Z);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }

            //update file with any new data
            FileHandling files = new FileHandling(thisActivity);
            files.storeData();

            return true;
        }

        /**
         * This method checks if the data for the specific country is already there , so we dont
         * have to recall to the server to get the data each time we change or dont change something
         *
         * @param eachCountry A selected country
         * @param indicator   A selected indicator
         * @return Data for a particular country, for a particular indicator
         * @throws IOException
         */
        private float[] checkIfDataIsAvailable(Country eachCountry, Indicator indicator) throws
                IOException {
            String JSONdata;

            //if data set is not previous downladeded, download it
            if (!eachCountry.getDataForIndicator().containsKey(indicator)) {
                if (isConnected()) {

                    JSONdata = JsonHandling.requestData(eachCountry.getID(),
                            indicator.getID()); //get JSON string
                    eachCountry.setDataForSpecificIndicator(indicator, JSONdata);
                } else { //if data isn't downloaded and we don't have a connection
                    JSONdata = null;
                }
            } else { //else just retreive the data
                JSONdata = eachCountry.getDataForIndicator().get(indicator);
            }

            Log.d("Handling stored data", "JSONdata = " + JSONdata);
            return JsonHandling.requestJSONforData(JSONdata); //return parsed JSON data string
        }

        protected void onPostExecute(Boolean aBoolean) {
            updateGraph();
        }
    }

    @Override
    public void onStart() {
        super.onStart();

        if (ok == 0) {
            AppDST.xIndicator = AppDST.indicatorMap.get("CO2 emissions (kt)");
            AppDST.yIndicator = AppDST.indicatorMap.get("Electric power consumption (kWh per " +
                    "capita)");
            AppDST.zIndicator = AppDST.indicatorMap.get("Population growth (annual %)");

            AppDST.selectedCountriesMap.put("Japan", AppDST.countryMap.get("Japan"));
            AppDST.selectedCountriesMap.put("United Kingdom", AppDST.countryMap.get("United " +
                    "Kingdom"));
            AppDST.selectedCountriesMap.put("India", AppDST.countryMap.get("India"));
            ok = 1;
        }
        new updateDataModel().execute();


        Log.e("SELECTED_INDICATORS_ON_GRAPH_START", AppDST.xIndicator.toString() + " " + AppDST
                .yIndicator.toString() + " " + AppDST.zIndicator.toString());
    }

    /**
     * checks current network access
     *
     * @return A true/false state depending upon current network access
     */
    public boolean isConnected() {
        /** Checking if user has internet connection **/
        //Giving the line that notifies the application when network changes
        ConnectivityManager connectionManager = (ConnectivityManager) getSystemService(this
                .CONNECTIVITY_SERVICE);
        //Sends back details that are currently active about the network.
        NetworkInfo networkInformation = connectionManager.getActiveNetworkInfo();
        //If the network information is not null and that it is connected, then notify user.
        if (networkInformation != null && networkInformation.isConnected()) {
            return true;
        } else {
            return false;
        }
    }

    private void spinerGraphUpdate() {
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                currentYear = 2014 - position;
                if (seekBar != null) {
                    seekBar.setProgress(49 - position);
                }
                Iterator allSelectedCountries = AppDST.selectedCountriesMap.entrySet().iterator();
                while (allSelectedCountries.hasNext()) {
                    Map.Entry eachElement = (Map.Entry) allSelectedCountries.next();
                    Country eachCountry = (Country) eachElement.getValue();
                    Log.v("check for countries", eachCountry.getName());
                    float[] yearData = eachCountry.getYearData(currentYear);
                    if (yearData != null) {
                        //add the country to the list of bubbles
                        BubbleValue bubbleValue = eachCountry.getBubbleValue();
                        if (bubbleValue != null)
                            bubbleValue.setTarget(yearData[0], yearData[1],
                                    yearData[2]);
                    }
                }
                chart.startDataAnimation();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        dataAdapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setPrompt("Choose a year");
        spinner.setAdapter(dataAdapter);
    }

    private void seekBarGraphUpdate() {

        if (seekBar != null) {
            int seekBarMax = 49;
            seekBar.setMax(seekBarMax);
            seekBar.setProgress(seekBarMax);
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    currentYear = 1964 + (progress);
                    spinner.setSelection(49 - seekBar.getProgress());
                    TextView yearTextView = (TextView) findViewById(R.id.yearsTextView);
                    yearTextView.setText("Year: " + currentYear);
                    updateGraph();
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
        }
    }

    public void playButtonGraphUpdate(View view) {
        Button button = (Button) view;
        if (isPlaying) {
            timer.cancel();
            button.setText(R.string.playString);
        } else {
            if (seekBar.getProgress() == seekBar.getMax()) {
                seekBar.setProgress(0);
                currentYear = 1963;
            }
            time = new PlayTime();
            timer = new Timer();
            timer.schedule(time, new Date(), 500);
            button.setText(R.string.pauseString);
        }
        isPlaying = !isPlaying;
    }

    private class PlayTime extends TimerTask {
        @Override
        public void run() {
            seekBar.setProgress(seekBar.getProgress() + 1);
            currentYear++;
        }
    }
}
