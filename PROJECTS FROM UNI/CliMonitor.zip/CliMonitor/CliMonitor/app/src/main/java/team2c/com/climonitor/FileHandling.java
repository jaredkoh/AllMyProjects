package team2c.com.climonitor;

import android.app.Activity;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;

import team2c.com.model.AppDST;
import team2c.com.model.Country;
import team2c.com.model.CountryDownload;
import team2c.com.model.Indicator;

/**
 * Created by Robert on 29/11/14.
 */
public class FileHandling {

    private Activity currentActivity;

    private static final String indicatorFile = "indicatorDownload.txt";
    private static final String countryFile = "countryDownload.txt";
    private static final String dataFile = "dataDownload.txt";

    public FileHandling(Activity currentActivity) {
        this.currentActivity = currentActivity;
    }

    /**
     * Reads county list from file and into hashmap
     */
    public void readingCountries() {
        try {
            String read;
            BufferedReader bufferedReader = new BufferedReader(new FileReader(new
                    File(currentActivity.getFilesDir() + File.separator + countryFile)));

            int countryCounter = 0;
            CountryDownload countryDL = null;
            while ((read = bufferedReader.readLine()) != null) {
                switch (countryCounter) {
                    case 0:
                        countryDL = new CountryDownload();
                        countryDL.setName(read);
                        Log.d("READING", countryDL.getName());
                        break;
                    case 1:
                        countryDL.setId(read);
                        Log.d("READING", countryDL.getId());
                        break;
                    case 2:
                        countryDL.setIndex(Integer.parseInt(read));
                        Log.d("READING", countryDL.getIndex() + "");
                        AppDST.countryMap.put(countryDL.getName(), new Country(countryDL));
                        break;
                }
                countryCounter++;
                if (countryCounter > 2) {
                    countryCounter = 0;
                }
            }
            bufferedReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Stores county map to file
     */
    public void storeCountries() {
        try {
            Iterator allCountries = AppDST.countryMap.entrySet().iterator(); //get iterator of map

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new
                    File(currentActivity.getFilesDir() + File.separator + countryFile)));

            while (allCountries.hasNext()) { //iterate over map
                Map.Entry eachElement = (Map.Entry) allCountries.next();
                Country eachCountry = (Country) eachElement.getValue();
                CountryDownload countryDL = new CountryDownload(eachCountry.getName(),
                        eachCountry.getID(), eachCountry.getOrderingIndex());
                bufferedWriter.write(countryDL.getName() + "\n");
                bufferedWriter.write(countryDL.getId() + "\n");
                bufferedWriter.write((countryDL.getIndex() + "\n"));
//                bufferedWriter.write(countryDL.getName(), 0, countryDL.getName().length() - 1);
//                bufferedWriter.write(countryDL.getId(), 0, countryDL.getId().length() - 1);
                // bufferedWriter.write((countryDL.getIndex());
                Log.d("Writing country to file: ", countryDL.getName() + " " + countryDL.getId()
                        + " " + countryDL.getIndex());
            }
            bufferedWriter.close();
            Log.d("Writing finished: ", "after COUNTRIES");

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Stores indicator map to file
     */
    public void storeIndicators() {
        try {
            Iterator allIndicators = AppDST.indicatorMap.entrySet().iterator(); //get iterator of
            // map

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new
                    File(currentActivity.getFilesDir() + File.separator + indicatorFile)));

            while (allIndicators.hasNext()) { //iterate over map
                Map.Entry eachElement = (Map.Entry) allIndicators.next();
                Indicator eachIndicator = (Indicator) eachElement.getValue();
                bufferedWriter.write(eachIndicator.getName() + "\n");
                bufferedWriter.write(eachIndicator.getId() + "\n");
                bufferedWriter.write((eachIndicator.getOrderingIndex() + "\n"));
                Log.d("Writing indicator to file: ", eachIndicator.getName() + " " +
                        eachIndicator.getId() + " " + eachIndicator.getOrderingIndex());
            }
            bufferedWriter.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    /**
     * Reads county list from file and into hashmap
     */

    public void readingIndicators() {
        try {
            String read;
            BufferedReader bufferedReader = new BufferedReader(new FileReader(new
                    File(currentActivity.getFilesDir() + File.separator + indicatorFile)));

            int indicatorCounter = 0;
            Indicator indicator = null;
            while ((read = bufferedReader.readLine()) != null) {
                switch (indicatorCounter) {
                    case 0:
                        indicator = new Indicator();
                        indicator.setName(read);
                        Log.d("READING", indicator.getName());
                        break;
                    case 1:
                        indicator.setId(read);
                        Log.d("READING", indicator.getId());
                        break;
                    case 2:
                        indicator.setOrderingIndex(Integer.parseInt(read));
                        Log.d("READING", indicator.getOrderingIndex() + "");
                        AppDST.indicatorMap.put(indicator.getName(), indicator);
                        break;
                }
                indicatorCounter++;
                if (indicatorCounter > 2) {
                    indicatorCounter = 0;
                }
            }
            bufferedReader.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Stores the data whenever new data is retrieved from the server
     */
    public void storeData() {
        Log.d("FileHandling","Storing newest data");
        try {
            Iterator allCountries = AppDST.countryMap.entrySet().iterator(); //get iterator of map

            BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new
                    File(currentActivity.getFilesDir() + File.separator + dataFile)));

            while (allCountries.hasNext()) { //iterate over map
                Map.Entry eachElement = (Map.Entry) allCountries.next();
                Country eachCountry = (Country) eachElement.getValue();

                Iterator allIndicators = eachCountry.getDataForIndicator().entrySet().iterator();
                while(allIndicators.hasNext()) {
                    Map.Entry eachElement2 = (Map.Entry) allIndicators.next();
                    Indicator eachIndicator = (Indicator) eachElement2.getKey();
                    String eachData = (String) eachElement2.getValue();

                    bufferedWriter.write(eachCountry.getName() + "\n");
                    bufferedWriter.write(eachIndicator.getName() + "\n");
                    bufferedWriter.write(eachData + "\n");
                    Log.d("Writing some data: ",eachCountry.getName() + "  " + eachIndicator.getName());
                }
            }
            bufferedWriter.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Reads in the offline data files
     */
    public void readingData() {
        Log.d("FileHanding","Reading in data");
        try {
            String read;
            BufferedReader bufferedReader = new BufferedReader(new FileReader(new
                    File(currentActivity.getFilesDir() + File.separator + dataFile)));

            int counter = 0;
            String countryName = "";
            String indicatorName = "";
            String JSONdata;
            while ((read = bufferedReader.readLine()) != null) {
                switch(counter) {
                    case 0:
                        countryName = read;
                        Log.d("Data File Reading",countryName);
                        break;
                    case 1:
                        indicatorName = read;
                        Log.d("Data File Reading",indicatorName);
                        break;
                    case 2:
                        JSONdata = read;
                        Log.d("Data File Reading",JSONdata);

                        Country country = AppDST.countryMap.get(countryName);
                        Indicator indicator = AppDST.indicatorMap.get(indicatorName);
                        country.setDataForSpecificIndicator(indicator, JSONdata);
                        break;
                }

                counter++;
                if(counter > 2) {
                    counter = 0;
                }
            }
            bufferedReader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
