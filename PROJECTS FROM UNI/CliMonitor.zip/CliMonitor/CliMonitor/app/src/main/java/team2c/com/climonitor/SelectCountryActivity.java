package team2c.com.climonitor;


import android.app.SearchManager;
import android.app.SearchableInfo;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.ActionBarActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckedTextView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import team2c.com.model.AppDST;
import team2c.com.model.Country;

/**
 * This is an activity that presents the user with a list of countries for selected
 * This will be replaced with a left-draw (i.e. hamburger menu) in the final app
 */
public class SelectCountryActivity extends ActionBarActivity {

    //this is a reference to itself for when assigning a context inside of event handling
    SelectCountryActivity selectCountryActivity = this;
    static HashMap<String, String> selectedCountries = new HashMap<String, String>();
    ArrayAdapter<Country> adapter;
    ArrayList<Country> allCountriesList;
    SearchView searchView;
    String searchTerm = "";
    static int ok = 0;
    ArrayList<Country> filteredCountries = new ArrayList<Country>();
    ListView countryList;
    CheckedTextView checkedTextViewHere;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        countryList = new ListView(this);
        setContentView(countryList);

        if (ok == 0) {
            selectedCountries.put("Japan", "Japan");
            selectedCountries.put("United Kingdom", "United Kingdom");
            selectedCountries.put("India", "India");
            ok = 1;
        }

        //ActionBar actionBar = getActionBar();
        // Enabling Back navigation on Action Bar icon
        // actionBar.setDisplayHomeAsUpEnabled(true);

        //if not connected, tell user that data may be out of date
        if (!isConnected()) {
            Toast.makeText(this, "No Internet Connection, data maybe out of date.",
                    Toast.LENGTH_SHORT).show();
        }

        //puts list of countries into GUI list
        loadListDataModel();
        searchTerm = "";
        setChecked();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_select_country, menu);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

        MenuItem searchItem = menu.findItem(R.id.action_search);
        searchView = (SearchView) MenuItemCompat.getActionView(searchItem);

        SearchableInfo searchableInfo = searchManager.getSearchableInfo((getComponentName()));
        searchView.setSearchableInfo(searchableInfo);

        searchListener();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings || id == R.id.action_search) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void searchListener() {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            public boolean onQueryTextSubmit(String query) {
                searchView.clearFocus();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (TextUtils.isEmpty(newText)) {
                    filteredCountries = allCountriesList;
                    searchTerm = "";
                    adapter.getFilter().filter("");
                    setChecked();
                } else {
                    searchTerm = newText;
                    adapter.getFilter().filter(newText);
                    setChecked();
                }
                return true;
            }
        });
    }

    public void setChecked() {
        filterBySearch(searchTerm);
        for (int i = 0; i < adapter.getCount(); i++) {
            String countryName = ((Country) adapter.getItem(i)).getName();
            if (selectedCountries.get(countryName) != null) {
                countryList.setItemChecked(i, true);
            } else {
                countryList.setItemChecked(i, false);
            }
        }
    }

    public void filterBySearch(final String searchTerm) {
        filteredCountries = new ArrayList<Country>();
        for (Country c : allCountriesList) {
            String[] splitCountryName = c.getName().split(" ");
            for (String s : splitCountryName) {
                if (s.toLowerCase().startsWith(searchTerm.toLowerCase())) {
                    filteredCountries.add(c);
                    break;
                }
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        AppDST.selectedCountriesMap = new HashMap<String, Country>();
        Iterator selectedCountriesIterator = selectedCountries.entrySet().iterator();
        while (selectedCountriesIterator.hasNext()) { //iterate over map
            Map.Entry eachElement = (Map.Entry) selectedCountriesIterator.next();
            Country eachCountry = (Country) AppDST.countryMap.get(eachElement.getValue());
            AppDST.selectedCountriesMap.put(eachCountry.getName(), eachCountry); //adding the
            // countries to the list
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    public void loadListDataModel() {
        allCountriesList = AppDST.allCountriesList;
        filteredCountries = allCountriesList;

        //adds the list of all countries to the GUI list's model
        adapter = (new ArrayAdapter<Country>(selectCountryActivity,
                R.layout.check_text_view, R.id.checkbox,
                filteredCountries) {
            @Override
            public Country getItem(int position) {
                return filteredCountries.get(position);
            }

            @Override
            public int getCount() {
                return filteredCountries.size();
            }
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                checkedTextViewHere = (CheckedTextView) findViewById(android.R.id.text1);

                LayoutInflater layoutInflater = selectCountryActivity.getLayoutInflater();
                convertView = layoutInflater.inflate(R.layout.check_text_view,null);
                checkedTextViewHere = (CheckedTextView) convertView.findViewById(R.id.check_box);
                int i = selectCountryActivity.getResources().getIdentifier("drawable/" + filteredCountries.get(position).getID().toLowerCase(),null, selectCountryActivity.getPackageName());

                checkedTextViewHere.setCompoundDrawablesWithIntrinsicBounds(i, 0, 0, 0);
                checkedTextViewHere.setText(filteredCountries.get(position).getName());
                return checkedTextViewHere;
            }
        });
        countryList.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
        countryList.setAdapter(adapter);
        countryList.setTextFilterEnabled(true);

        //action listener for when the user clicks on an element of the list
        countryList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String countryName = ((Country) adapter.getItem(position)).getName();
                if (selectedCountries.containsKey(countryName))
                    selectedCountries.remove(countryName);
                else
                    selectedCountries.put(countryName, countryName);
            }
        });
    }

    /**
     * checks current network access
     *
     * @return A true/false state depending upon current network access
     */
    public boolean isConnected() {
        /** Checking if user has internet connection **/
        //Giving the line that notifies the application when network changes
        ConnectivityManager connectionManager = (ConnectivityManager) getSystemService(this
                .CONNECTIVITY_SERVICE);
        //Sends back details that are currently active about the network.
        NetworkInfo networkInformation = connectionManager.getActiveNetworkInfo();
        //If the network information is not null and that it is connected, then notify user.
        if (networkInformation != null && networkInformation.isConnected()) {
            return true;
        } else {
            return false;
        }
    }
}