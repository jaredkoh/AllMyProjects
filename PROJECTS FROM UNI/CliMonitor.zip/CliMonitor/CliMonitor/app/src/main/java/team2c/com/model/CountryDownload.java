package team2c.com.model;

/**
 * Created by Nand on 27/11/14.
 */
public class CountryDownload {
    private String name;
    private String id;
    private int index;

    public String getName() {
        return name;
    }

    public String getId() {
        return id;
    }

    public int getIndex() {
        return index;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public CountryDownload(String name, String id, int index) {
        this.name = name;
        this.id = id;
        this.index = index;
    }

    public CountryDownload() {
        this.name = null;
        this.id = null;
        this.index = 0;
    }

}
