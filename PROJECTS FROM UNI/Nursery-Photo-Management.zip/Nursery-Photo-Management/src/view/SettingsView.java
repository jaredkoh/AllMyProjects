package view;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.CheckBoxTableCell;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.*;
import model.database.NPMDBChild;
import model.database.NPMDBDataManager;
import model.database.NPMDBRoom;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

/**
 * The settings panel
 *
 * @author Team 3-B
 * @version 1.0
 */
@SuppressWarnings("unchecked")
public class SettingsView extends Stage {
	private static SettingsView instance;
	private final Stage stage = this;

	NPMDBDataManager dm = NPMDBDataManager.getInstance();

	final ObservableList<NPMDBChild> childrenData = FXCollections.observableArrayList(dm.query("SELECT * FROM Child", "Child"));

	// MainView's scene
	private static Scene parent;
	// SettingsView's scene
	private final Scene scene;

	private BorderPane borderPane;

	private String mainURL;
	private String settingsURL;

	private int currentTab = 0;

	public static SettingsView getInstance(Scene scene) {
		if (instance == null) {
			parent = scene;
			instance = new SettingsView();
			instance.show();
		} else {
			instance.toFront();
		}
		return instance;
	}

    public SettingsView() {
		this.initStyle(StageStyle.UNIFIED);
		this.setTitle("Settings");
		this.setResizable(false);

        this.borderPane = new BorderPane();
		this.borderPane.setCenter(createTabPane());
		this.borderPane.setBottom(createButtons());

		this.setOnCloseRequest(new EventHandler<WindowEvent>() {
			@Override
			public void handle(WindowEvent event) {
				instance = null;
			}
		});

		scene = new Scene(borderPane, 550, 600);
		scene.getStylesheets().add(this.getClass().getResource("css/theme" + MainView.THEME_ID + "-settings.css").toExternalForm());

		this.setScene(scene);
    }

    private TabPane createTabPane() {
        TabPane tabPane = new TabPane();

		Tab tab1 = new Tab("Children");
		tab1.setContent(createAddEditChildrenPage());
		tab1.setClosable(false);

        Tab tab2 = new Tab("Room");
        tab2.setContent(createAddRoomPage());
        tab2.setClosable(false);

		Tab tab3 = new Tab("Photo Library");
		tab3.setContent(createImportExportPage());
		tab3.setClosable(false);

		Tab tab4 = new Tab("Preferences");
		tab4.setContent(createChooseThemePage());
		tab4.setClosable(false);

		tabPane.getTabs().addAll(tab1, tab2, tab3, tab4);

		tabPane.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				currentTab = newValue.intValue();
			}
		});

        return tabPane;
    }

	private VBox createContainer(String text, String tooltip, Node... nodes) {
		VBox container = new VBox();

		Label title = new Label(text);
		title.setFont(new Font("Arial", 20));
		title.setTooltip(new Tooltip(tooltip));

		container.setSpacing(16);
		container.setPadding(new Insets(10));
		container.getChildren().add(title);
		container.getChildren().addAll(nodes);
		container.getStyleClass().add("center-container");

		return container;
	}

	private HBox createButtons() {
		HBox bottom = new HBox();
        bottom.getStyleClass().add("bottom-container");

		Button btnSave = new Button("Done");
        btnSave.setStyle("-fx-font-weight: bold");
		btnSave.setDefaultButton(true);
		btnSave.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				((Stage) ((Button) event.getSource()).getScene().getWindow()).close();
				instance = null;
			}
		});

		Button btnCancel = new Button("Close");
        btnCancel.getStyleClass().add("button-default-regular");
		btnCancel.setCancelButton(true);
		btnCancel.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				((Stage) ((Button) event.getSource()).getScene().getWindow()).close();
				instance = null;
			}
		});

		bottom.getChildren().addAll(btnSave, btnCancel);
		bottom.setSpacing(10);
		bottom.setPadding(new Insets(10));
		bottom.setAlignment(Pos.CENTER);

		return bottom;
	}

	private VBox createAddEditChildrenPage() {
		final TableView tableView = new TableView();

		TableColumn colFirstName = new TableColumn("First Name");
		colFirstName.setMinWidth(120);
		colFirstName.setCellValueFactory(new PropertyValueFactory<NPMDBChild, String>("firstName"));
		colFirstName.setCellFactory(TextFieldTableCell.forTableColumn());
		colFirstName.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<NPMDBChild, String>>() {
			@Override
			public void handle(TableColumn.CellEditEvent<NPMDBChild, String> event) {
				NPMDBChild child = event.getTableView().getItems().get(event.getTablePosition().getRow());
				child.setFirstName(event.getNewValue());
			}
		});

		TableColumn colLastName = new TableColumn("Last Name");
		colLastName.setMinWidth(120);
		colLastName.setCellValueFactory(new PropertyValueFactory<NPMDBChild, String>("lastName"));
		colLastName.setCellFactory(TextFieldTableCell.forTableColumn());
		colLastName.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<NPMDBChild, String>>() {
			@Override
			public void handle(TableColumn.CellEditEvent<NPMDBChild, String> event) {
				NPMDBChild child = event.getTableView().getItems().get(event.getTablePosition().getRow());
				child.setLastName(event.getNewValue());
			}
		});

		TableColumn colKeyWorker = new TableColumn("Key Worker");
		colKeyWorker.setMinWidth(120);
		colKeyWorker.setCellValueFactory(new PropertyValueFactory<NPMDBChild, String>("keyWorker"));
		colKeyWorker.setCellFactory(TextFieldTableCell.forTableColumn());
		colKeyWorker.setOnEditCommit(new EventHandler<TableColumn.CellEditEvent<NPMDBChild, String>>() {
			@Override
			public void handle(TableColumn.CellEditEvent<NPMDBChild, String> event) {
				NPMDBChild child = event.getTableView().getItems().get(event.getTablePosition().getRow());
				child.setKeyWorker(event.getNewValue());
			}
		});

		TableColumn colActive = new TableColumn("Active");
		colActive.setCellValueFactory(new PropertyValueFactory<NPMDBChild, Boolean>("active"));
		colActive.setCellFactory(CheckBoxTableCell.forTableColumn(colActive));

		colActive.setEditable(true);
		tableView.setEditable(true);

		tableView.setItems(childrenData);
		tableView.getColumns().addAll(colFirstName, colLastName, colKeyWorker, colActive);

		VBox vBox = new VBox();
		HBox hBox = new HBox();

		final TextField firstName = new TextField();
		firstName.setPromptText("First Name");

		final TextField lastName = new TextField();
		lastName.setPromptText("Last Name");

		final TextField keyWorker = new TextField();
		keyWorker.setPromptText("Key Worker");

		final ChoiceBox<String> active = new ChoiceBox<>();
		active.getItems().addAll("Active", "Inactive");
		active.getSelectionModel().select(0);

		Button btnAdd = new Button("Add Child");
        btnAdd.setStyle("-fx-font-weight: bold");
		btnAdd.setPrefWidth(Double.MAX_VALUE);
		btnAdd.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (!firstName.getText().equals("") && !lastName.getText().equals("") && !keyWorker.getText().equals("")) {
					childrenData.add(new NPMDBChild(firstName.getText(), lastName.getText(), keyWorker.getText(), (active.getValue().equals("Active"))));
					firstName.clear();
					lastName.clear();
					keyWorker.clear();
					active.setValue("Active");
				} else {
					System.err.println("Fill out all fields!");
				}
			}
		});

        Button btnRemove = new Button("Remove Selected Child");
        btnRemove.setStyle("-fx-font-weight: bold");
        btnRemove.setPrefWidth(Double.MAX_VALUE);
        btnRemove.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                NPMDBChild child = (NPMDBChild) tableView.getSelectionModel().getSelectedItem();
				childrenData.remove(child);
				dm.update("DELETE FROM Child WHERE child_id = " + child.getId());
				dm.update("DELETE FROM Child_Tag_Picture WHERE child_id = " + child.getId());
            }
        });

        hBox.getChildren().addAll(firstName, lastName, keyWorker, active);
		hBox.setSpacing(5);
		vBox.getChildren().addAll(hBox, btnAdd , btnRemove);
		vBox.setSpacing(5);

		return createContainer("Add & Edit Children", "Edit basic information of children", tableView, vBox);
	}

    private VBox createAddRoomPage() {
        final TextField roomName = new TextField();
		roomName.setPromptText("Enter Room Name");

        Button btnAddRoom = new Button("Add Room");
		btnAddRoom.getStyleClass().add("button-default");
        btnAddRoom.setPrefWidth(Double.MAX_VALUE);
		btnAddRoom.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				if (!roomName.getText().equals("")) {
					new NPMDBRoom(roomName.getText());
					roomName.clear();
				}
			}
		});

        return createContainer("Add a Room", "Enter name of a new room", roomName, btnAddRoom);
    }

    private VBox createImportExportPage() {
        Button btnImportCSV = new Button("Import From CSV File");
		btnImportCSV.getStyleClass().add("button-default");
		btnImportCSV.setPrefWidth(Double.MAX_VALUE);
        btnImportCSV.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				DirectoryChooser directoryChooser = new DirectoryChooser();
				File folder = directoryChooser.showDialog(stage);
				try {
					dm.importData(folder);
				} catch (SQLException | IOException e) {
					e.printStackTrace();
				}
			}
		});

        Button btnExportCSV = new Button("Export To CSV Files");
		btnExportCSV.getStyleClass().add("button-default");
		btnExportCSV.setPrefWidth(Double.MAX_VALUE);
        btnExportCSV.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				DirectoryChooser directoryChooser = new DirectoryChooser();
				File folder = directoryChooser.showDialog(stage);
				dm.exportData(folder, false);
			}
		});

		Button btnExportZIP = new Button("Export To Compressed File");
		btnExportZIP.getStyleClass().add("button-default");
		btnExportZIP.setPrefWidth(Double.MAX_VALUE);
		btnExportZIP.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				DirectoryChooser directoryChooser = new DirectoryChooser();
				File folder = directoryChooser.showDialog(stage);
				dm.exportData(folder, true);
			}
		});

        return createContainer("Import / Export Library to CSV Files", "CSV: Comma Separated Value", btnImportCSV, btnExportCSV, btnExportZIP);
    }

	private VBox createChooseThemePage() {
		ChoiceBox<String> choiceBox = new ChoiceBox<>();

		final ObservableList<String> themes = FXCollections.observableArrayList();

		themes.add("Blue");
		themes.add("Dark");
		themes.add("Default");
		themes.add("Happy");

		choiceBox.setItems(themes);
		choiceBox.getSelectionModel().select(MainView.THEME_ID);

		choiceBox.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				int themeID = newValue.intValue();

				mainURL = getClass().getResource("css/theme" + themeID + "-main.css").toExternalForm();
				settingsURL = getClass().getResource("css/theme" + themeID + "-settings.css").toExternalForm();

				parent.getStylesheets().remove(0);
				parent.getStylesheets().add(mainURL);

				scene.getStylesheets().remove(0);
				scene.getStylesheets().add(settingsURL);

				dm.update("UPDATE Settings SET theme_id=" +themeID);
				MainView.THEME_ID = themeID;
			}
		});

		return createContainer("Choose a Theme", "Choose a different color theme", choiceBox);
	}
}
