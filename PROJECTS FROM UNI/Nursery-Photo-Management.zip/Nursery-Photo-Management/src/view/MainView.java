package view;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Paint;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;
import model.database.NPMDBDataManager;
import model.database.NPMDBLabel;
import model.database.NPMDBPicture;
import model.database.NPMDBTag;
import model.search.NPMComboBoxListener;
import model.search.NPMSearchListener;
import model.search.NPMSearchManager;
import model.search.NPMSearchResult;
import model.tag.NPMTagManager;
import view.custom.NPMHelpTutorial;
import view.custom.NPMImageCell;
import view.custom.NPMRightSideBar;

import javax.swing.*;
import java.io.File;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Main window of the application
 *
 * @author Team 3-B
 * @version 1.0
 */
@SuppressWarnings("unchecked")
public class MainView extends Application implements NPMSearchListener {
	private static final int INITIAL_LOAD_AMOUNT = 50;
	private static final int ON_SCROLL_LOAD_AMOUNT = 25;
	/**
	 * Width of left and right side bars
	 */
	public static final int SIDE_BAR_WIDTH = 200;
	/**
	 * Number of images to store in memory
	 */
	public static final int PRELOADED_IMAGE_COUNT = 250;

	// The main window
	private Stage stage;

	private static NPMDBDataManager dm = NPMDBDataManager.getInstance();
	private static NPMSearchManager sm = NPMSearchManager.getInstance();
	NPMHelpTutorial tutorial = NPMHelpTutorial.getInstance();

	/**
	 * The ID of the currently active theme
	 */
	public static int THEME_ID = dm.queryInteger("SELECT * FROM Settings", "theme_id");

	// Data objects
	private static TreeMap<String, Image> preloadedImages;
	private static ObservableList<NPMDBPicture> selectedImages = FXCollections.observableArrayList();
	private static ObservableList<NPMDBPicture> untaggedImages = FXCollections.observableArrayList();
	private static ObservableList<NPMImageCell> thumbnails = FXCollections.observableArrayList();
	private HashMap<String, NPMSearchResult> possibleSearchResults;

	// Nodes
	private TilePane imageThumbnailsPane;
	private BorderPane mainBorderPane;
	private StackPane centerPane;
	private BorderPane leftSideBar;
	private NPMRightSideBar rightSideBar;
	private Button btnDeselectAll;

	// TreeView related objects
	private TreeView<String> dateTree;
	private TreeView<String> labelTree;
	private ArrayList<Date> dateTreeList = new ArrayList<>();
	private ArrayList<String> labelTreeList = new ArrayList<>();
	private ChangeListener dateTreeListener;
	private ChangeListener labelTreeListener;

    private final ComboBox<String> searchBar = new ComboBox<>();

	// Buttons
    private final Button btnUntagged = new Button("Show Untagged");
    private final Button btnSelected = new Button("Show Selected");
    private final Button btnAll = new Button("Show All");
	private final Button btnImport = new Button("Import Photos");
	private final Button btnSettings = new Button("Settings");

	/**
	 * If false, all images are loaded, if true, only a couple of images are loaded
	 * and the rest only when the scrollbar reaches the bottom
	 */
	private boolean loadMoreOnScroll = true;

	@Override
	public void start(Stage stage) throws Exception {
		this.stage = stage;
		this.stage.setTitle("Nelly's Nursery Photo Management Application");
        this.stage.getIcons().add(new Image(getClass().getResourceAsStream("/view/images/icon-mac-app.png")));

		preloadImages();

		mainBorderPane = new BorderPane();
		centerPane = createCenterPane();

		mainBorderPane.setCenter(centerPane);

		// Load images after center and before side panes
		loadImages(0, INITIAL_LOAD_AMOUNT);

        // Load fonts
        Font.loadFont(getClass().getResource("/view/fonts/Roboto-Regular.ttf").toExternalForm(), 10);
        Font.loadFont(getClass().getResource("/view/fonts/Roboto-Light.ttf").toExternalForm(), 10);
        Font.loadFont(getClass().getResource("/view/fonts/Roboto-Bold.ttf").toExternalForm(), 10);
        Font.loadFont(getClass().getResource("/view/fonts/Roboto-Medium.ttf").toExternalForm(), 10);
        Font.loadFont(getClass().getResource("/view/fonts/Roboto-Thin.ttf").toExternalForm(), 10);

		// Set up left and right panes
		this.leftSideBar = createLeftSideBar();
		this.rightSideBar = new NPMRightSideBar(this);
		mainBorderPane.setLeft(leftSideBar);
		mainBorderPane.setRight(rightSideBar);

		selectedImages.addListener(new ListChangeListener<NPMDBPicture>() {
			@Override
			public void onChanged(Change<? extends NPMDBPicture> c) {
				int selectedCount = c.getList().size();

				HashMap<String, Boolean> data;

				if (selectedCount > 1) {
					data = NPMTagManager.getInstance().isMultipleData(selectedImages);

					rightSideBar.setFileName("Multiple Photos");

					boolean isMultipleRoom = data.get("room");
					boolean isMultipleDate = data.get("date");
					boolean isMultipleDescription = data.get("description");

					rightSideBar.setRoomName(isMultipleRoom ? null : selectedImages.get(0).room, !isMultipleRoom);
					rightSideBar.setDate(isMultipleDate ? null : selectedImages.get(0).date, !isMultipleDate);
					rightSideBar.setDescription(isMultipleDescription ? null : selectedImages.get(0).comment, !isMultipleDescription);

				} else if (selectedCount == 1) {
					NPMDBPicture selected = c.getList().get(c.getList().size() - 1);
					rightSideBar.setFileName(selected.getFileName());
					rightSideBar.setDate(selected.date, true);
					rightSideBar.setDescription(selected.comment, true);
					rightSideBar.setRoomName(selected.room, true);
					rightSideBar.showTaggingOptions(true, false);
				} else if (selectedCount == 0) {
					rightSideBar.showTaggingOptions(false, false);
				}

				// load or remove data from the ui
				if (c.next()) {
					if (c.getRemoved().size() > 0) rightSideBar.removeExistingDataForPicture(c.getRemoved().get(0));
					else rightSideBar.loadExistingDataForPicture(c.getAddedSubList().get(0));
				}

			}
		});

		Scene scene = new Scene(mainBorderPane, 1280, 720);
		stage.setMinWidth(960);
		stage.setMinHeight(540);

		scene.getStylesheets().add(this.getClass().getResource("css/theme" + THEME_ID + "-main.css").toExternalForm());
		stage.setScene(scene);
		stage.show();

		tutorial.addAll(btnImport);
		tutorial.addAll(this.rightSideBar.getElements().toArray());
		tutorial.addAll(btnSettings);
		tutorial.start();
	}

	private BorderPane createLeftSideBar() {
		BorderPane leftSideBar = new BorderPane();
		leftSideBar.setPrefWidth(SIDE_BAR_WIDTH);
        leftSideBar.getStyleClass().add("left-side-bar");

		final DirectoryChooser directoryChooser = new DirectoryChooser();

        btnImport.setStyle("-fx-font-weight: bold;");
		btnImport.getStyleClass().add("button-default");
		btnImport.setPrefWidth(SIDE_BAR_WIDTH * 0.9);
        btnImport.setPrefHeight(30);
		btnImport.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent actionEvent) {
				File f = directoryChooser.showDialog(stage);
				if (f != null) {
					dm.importImages(f);
					loadImages(0, INITIAL_LOAD_AMOUNT);
					updateTreeViews();
				}
			}
		});
        Image imageButtonImport = new Image(getClass().getResourceAsStream("/view/images/icon-import.png"), 16, 16, false, true);
        ImageView imageViewButtonImport = new ImageView(imageButtonImport);
        btnImport.setAlignment(Pos.CENTER_LEFT);
        btnImport.setGraphicTextGap(32);
        btnImport.setGraphic(imageViewButtonImport);

		VBox buttonBox = new VBox();

		btnAll.getStyleClass().add("button-selected");
		btnAll.setPrefWidth(SIDE_BAR_WIDTH * 0.9);
		btnAll.setPrefHeight(30);
		btnAll.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				loadMoreOnScroll = true;
				loadImages(0, INITIAL_LOAD_AMOUNT);
				highlightBtnAllPhotos();
			}
		});

		btnUntagged.getStyleClass().add("button-default-regular");
		btnUntagged.setPrefWidth(SIDE_BAR_WIDTH * 0.9);
		btnUntagged.setPrefHeight(30);
		btnUntagged.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				loadAllUntagged();
				highlightBtnUntagged();
			}
		});

		btnSelected.getStyleClass().add("button-default-regular");
		btnSelected.setPrefWidth(SIDE_BAR_WIDTH * 0.9);
		btnSelected.setPrefHeight(30);
		btnSelected.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				loadAllSelected();
				highlightBtnSelected();
			}
		});

        btnSettings.setStyle("-fx-font-weight: bold;");
		btnSettings.getStyleClass().add("button-default");
		btnSettings.setPrefWidth(SIDE_BAR_WIDTH * 0.9);
        btnSettings.setPrefHeight(30);
		btnSettings.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
				SettingsView.getInstance(stage.getScene());
            }
        });

        Image imageButtonSettings = new Image(getClass().getResourceAsStream("/view/images/icon-settings.png"), 20, 20, false, true);
        ImageView imageViewButtonSettings = new ImageView(imageButtonSettings);
        btnSettings.setAlignment(Pos.CENTER_LEFT);
        btnSettings.setGraphicTextGap(36);
        btnSettings.setGraphic(imageViewButtonSettings);

		buttonBox.getChildren().addAll(
                createLeftSidebarButton(btnAll, false),
                createLeftSidebarButton(btnUntagged, false),
                createLeftSidebarButton(btnSelected, false),
                createLeftSidebarButton(btnSettings, false));
        buttonBox.getStyleClass().add("left-side-bar-bottom");

		leftSideBar.setTop(createLeftSidebarButton(btnImport, true));
		leftSideBar.setCenter(setUpTreeViews());
		leftSideBar.setBottom(buttonBox);

		return leftSideBar;
	}

    private FlowPane createLeftSidebarButton(Button button, Boolean top) {
        FlowPane buttonPane = new FlowPane();

        if(top) {
            buttonPane.getStyleClass().add("left-side-bar-top");
        } else {
            buttonPane.getStyleClass().add("left-side-bar-bottom");
        }

        buttonPane.getChildren().add(0, button);
        buttonPane.setAlignment(Pos.CENTER);

        FlowPane.setMargin(button, new Insets(5, 0, 5, 0));

        return buttonPane;
    }

	private StackPane createCenterPane() {
		BorderPane centerImagePane = new BorderPane();

		// Top
		searchBar.setEditable(true);
		searchBar.setPrefWidth(Double.MAX_VALUE);
        searchBar.setMinHeight(40);
		searchBar.setPromptText("Search...");
		searchBar.setTooltip(new Tooltip("Search for children and events"));

		// Searchbar listener
		NPMComboBoxListener listener = new NPMComboBoxListener(searchBar, NPMSearchManager.SearchType.ALL);
		searchBar.addEventHandler(javafx.scene.input.KeyEvent.ANY, listener);
		listener.searchDelegate = this;

		// Listener for selected item
		searchBar.valueProperty().addListener(new ChangeListener() {
			@Override
			public void changed(ObservableValue observable, Object oldValue, Object newValue) {
				if (newValue != null) {
					NPMSearchResult resultQuery = possibleSearchResults.get(newValue);

					if (possibleSearchResults.size() != 0 && resultQuery != null) {
						ArrayList<NPMDBPicture> pictures = NPMSearchManager.getInstance().getSearchResult(resultQuery);

						if (possibleSearchResults.get(newValue).getSearchType() == NPMSearchManager.SearchType.PICTURE_DATE) {
//							dateTree.getSelectionModel().selectIndices((dateTreeList.indexOf(pictures.get(0).date) + 1));
//							return;
							changeDateWithoutReload((dateTreeList.indexOf(pictures.get(0).date) + 1));
						}

						if (possibleSearchResults.get(newValue).getSearchType() == NPMSearchManager.SearchType.LABEL_EVENT) {
//							labelTree.getSelectionModel().selectIndices(labelTreeList.indexOf(possibleSearchResults.get(newValue).getQueryKeyword()) + 1);
//							return;
							changeLabelWithoutReload((labelTreeList.indexOf(possibleSearchResults.get(newValue).getQueryKeyword()) + 1));
						}

						final ObservableList<NPMImageCell> localSearchThumbnails = FXCollections.observableArrayList();
						loadMoreOnScroll = false;
						imageThumbnailsPane.getChildren().clear();

						for (NPMDBPicture picture : pictures) {
							NPMImageCell imageCell = new NPMImageCell(picture);
							localSearchThumbnails.add(imageCell);
						}

						Platform.runLater(new Runnable() {
							@Override
							public void run() {
								imageThumbnailsPane.getChildren().addAll(localSearchThumbnails);
							}
						});
					} else {
						imageThumbnailsPane.getChildren().clear();
					}

				} else {
					imageThumbnailsPane.getChildren().clear();
					imageThumbnailsPane.getChildren().addAll(thumbnails);
				}
			}
		});

		searchBar.getEditor().addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (event.getCode() == KeyCode.BACK_SPACE || event.getCode() == KeyCode.DELETE) {
					searchBar.getEditor().clear();
					event.consume();
					imageThumbnailsPane.getChildren().clear();
					imageThumbnailsPane.getChildren().addAll(thumbnails);
				}
			}
		});

		btnDeselectAll = new Button("Deselect All");
		btnDeselectAll.getStyleClass().add("button-default");
		btnDeselectAll.setPrefHeight(30);
		btnDeselectAll.setPrefWidth(100);
		btnDeselectAll.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				clearSelection();
			}
		});
        FlowPane centerTopRightPane = new FlowPane(btnDeselectAll);
        centerTopRightPane.setPrefWidth(100);
        centerTopRightPane.setAlignment(Pos.CENTER);
		centerTopRightPane.setPadding(new Insets(5));
        centerTopRightPane.getStyleClass().add("center-top-right-pane");

		BorderPane topContainer = new BorderPane();
		topContainer.setCenter(searchBar);
		topContainer.setRight(centerTopRightPane);

		// Center
		imageThumbnailsPane = new TilePane();
		imageThumbnailsPane.setHgap(10);
		imageThumbnailsPane.setVgap(10);
		imageThumbnailsPane.setPadding(new Insets(5));

		centerImagePane.setTop(topContainer);
		centerImagePane.setCenter(setUpScrollPane(imageThumbnailsPane));

		return new StackPane(centerImagePane);
	}

	private ScrollPane setUpScrollPane(Node n) {
		ScrollPane scrollPane = new ScrollPane();

		scrollPane.setContent(n);
		scrollPane.setFitToHeight(true);
		scrollPane.setFitToWidth(true);
		scrollPane.setStyle("-fx-background-color:transparent;");
		scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
		scrollPane.vvalueProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				if (loadMoreOnScroll && newValue.doubleValue() == 1.0) {
					loadImages(thumbnails.size(), ON_SCROLL_LOAD_AMOUNT);
				}
			}
		});

		return scrollPane;
	}

	private VBox setUpTreeViews() {
		VBox treeViewContainer = new VBox();
        treeViewContainer.getStyleClass().add("left-side-bar-center");

		if (thumbnails.size() == 0) {
			Label importPictures = new Label("Click on the \"Import Images\" button above and navigate to a folder, to import all the photos in it.\n\n" +
					"After the importing is done, this side bar will be replaced with the dates and tags of the pictures.");
			importPictures.setWrapText(true);
			importPictures.setTextFill(Paint.valueOf("#FFFFFF"));
			treeViewContainer.getChildren().add(importPictures);
			treeViewContainer.setPadding(new Insets(10));
			treeViewContainer.setAlignment(Pos.CENTER);
			return treeViewContainer;
		}

		dateTree = new TreeView<>();
		labelTree = new TreeView<>();
		TreeItem<String> dateTreeRoot = new TreeItem<>("All Photos");
		TreeItem<String> labelTreeRoot = new TreeItem<>("All Labels");

		// Date TreeView
		ArrayList<NPMDBPicture> pictures = dm.query("SELECT * FROM Picture ORDER BY date DESC", "Picture");

		for (NPMDBPicture picture : pictures) {
			if (!dateTreeList.contains(picture.date)) {
				dateTreeList.add(picture.date);
			}
		}
		for (Date date : dateTreeList) {
			String s = new SimpleDateFormat("dd MMM YYYY").format(date);
			dateTreeRoot.getChildren().add(new TreeItem<>(s));
		}

		// Labels TreeView
		ArrayList<NPMDBLabel> labels = dm.query("SELECT * FROM Picture_Label ORDER BY label_name ASC", "Label");

		for (NPMDBLabel label : labels) {
			if (!labelTreeList.contains(label.getReadableName())) {
				labelTreeList.add(label.getReadableName());
			}
		}
		for (String string : labelTreeList) {
			labelTreeRoot.getChildren().add(new TreeItem<>(string));
		}

		dateTreeRoot.setExpanded(true);
		dateTree.setRoot(dateTreeRoot);

		labelTreeRoot.setExpanded(true);
		labelTree.setRoot(labelTreeRoot);

		// Create listeners
		dateTreeListener = new ChangeListener<TreeItem<String>>() {
			@Override
			public void changed(ObservableValue<? extends TreeItem<String>> observable, TreeItem<String> oldValue, TreeItem<String> newValue) {
				TreeItem selected = ((TreeItem) newValue);

				if (selected == null)
					return;

				loadMoreOnScroll = false;
				clearAllHighligh();

				labelTree.getSelectionModel().clearSelection();

				if (dateTree.getRoot().equals(selected)) {
					highlightBtnAllPhotos();
					loadImages(0, INITIAL_LOAD_AMOUNT);
					loadMoreOnScroll = true;
					return;
				}

				SimpleDateFormat input = new SimpleDateFormat("dd MMMM yyyy");
				SimpleDateFormat output = new SimpleDateFormat("yyyyMMdd");
				int dbDate = 0;

				try {
					Date date = input.parse((String) selected.getValue());
					dbDate = Integer.parseInt(output.format(date));
				} catch (ParseException e) {
					e.printStackTrace();
				}

				showSelected(dbDate);
			}
		};
		labelTreeListener = new ChangeListener<TreeItem<String>>() {
			@Override
			public void changed(ObservableValue<? extends TreeItem<String>> observable, TreeItem<String> oldValue, TreeItem<String> newValue) {
				TreeItem selected = ((TreeItem) newValue);

				if (selected == null)
					return;

				loadMoreOnScroll = false;
				clearAllHighligh();

				dateTree.getSelectionModel().clearSelection();

				if (labelTree.getRoot().equals(selected)) {
					highlightBtnAllPhotos();
					loadImages(0, INITIAL_LOAD_AMOUNT);
					loadMoreOnScroll = true;
					return;
				}

				showSelected(newValue.getValue());
			}
		};

		// Attach listeners
		dateTree.getSelectionModel().selectedItemProperty().addListener(dateTreeListener);
		labelTree.getSelectionModel().selectedItemProperty().addListener(labelTreeListener);

		treeViewContainer.getChildren().addAll(dateTree, labelTree);

		return treeViewContainer;
	}

	public void updateTreeViews() {
		if (dateTree == null || labelTree == null) {
			((BorderPane) mainBorderPane.getLeft()).setCenter(setUpTreeViews());
			return;
		}

		int datePrevIndex = dateTree.getSelectionModel().getSelectedIndex();
		int labelPrevIndex = labelTree.getSelectionModel().getSelectedIndex();

		// Clear date TreeView without listening to the change (root gets selected)
		dateTree.getSelectionModel().selectedItemProperty().removeListener(dateTreeListener);
		dateTree.getRoot().getChildren().clear();
		dateTree.getSelectionModel().selectedItemProperty().addListener(dateTreeListener);

		// Clear date TreeView without listening to the change (root gets selected)
		labelTree.getSelectionModel().selectedItemProperty().removeListener(labelTreeListener);
		labelTree.getRoot().getChildren().clear();
		labelTree.getSelectionModel().selectedItemProperty().addListener(labelTreeListener);

		TreeItem dateTreeRoot = dateTree.getRoot();
		TreeItem labelTreeRoot = labelTree.getRoot();

		// Update Date TreeView
		dateTreeList.clear();
		ArrayList<NPMDBPicture> pictures = dm.query("SELECT * FROM Picture ORDER BY date DESC", "Picture");

		for (NPMDBPicture picture : pictures) {
			if (!dateTreeList.contains(picture.date)) {
				dateTreeList.add(picture.date);
				String s = new SimpleDateFormat("dd MMM YYYY").format(picture.date);
				dateTreeRoot.getChildren().add(new TreeItem<>(s));
			}
		}

		// Update Labels TreeView
		labelTreeList.clear();
		ArrayList<NPMDBLabel> labels = dm.query("SELECT * FROM Picture_Label ORDER BY label_name ASC", "Label");

		for (NPMDBLabel label : labels) {
			if (!labelTreeList.contains(label.getReadableName())) {
				labelTreeList.add(label.getReadableName());
				labelTreeRoot.getChildren().add(new TreeItem<>(label.getReadableName()));
			}
		}

		if (datePrevIndex != -1) {
			changeDateWithoutReload(datePrevIndex);
			return;
		}

		if (labelPrevIndex != -1) {
			changeLabelWithoutReload(labelPrevIndex);
		}
	}

	private void changeDateWithoutReload(int index) {
		dateTree.getSelectionModel().selectedItemProperty().removeListener(dateTreeListener);
		dateTree.getSelectionModel().selectIndices(index);
		dateTree.getSelectionModel().selectedItemProperty().addListener(dateTreeListener);

		labelTree.getSelectionModel().clearSelection();
	}

	private void changeLabelWithoutReload(int index) {
		labelTree.getSelectionModel().selectedItemProperty().removeListener(labelTreeListener);
        labelTree.getSelectionModel().selectIndices(index);
		labelTree.getSelectionModel().selectedItemProperty().addListener(labelTreeListener);

        dateTree.getSelectionModel().clearSelection();
	}

	/**
	 * Show images for a selected date
	 *
	 * @param date The date of the images
	 */
	private void showSelected(int date) {
		exitFullscreen();

		// Clear array and display
		thumbnails.clear();
		imageThumbnailsPane.getChildren().clear();

		ArrayList<NPMDBPicture> pictures = dm.query("SELECT * FROM Picture WHERE date=" + date, "Picture");

		NPMImageCell cell;

		for (NPMDBPicture picture : pictures) {
			cell = new NPMImageCell(picture);

			if (selectedImages.contains(picture)) {
				Image checkedImage = new Image(getClass().getResourceAsStream("/view/images/icon-tick-theme-" + THEME_ID + ".png"), 25, 25, true, true);
				ImageView checkedImageView = new ImageView(checkedImage);
                cell.getStyleClass().removeAll("selected-image-cell-transparent");
				cell.getStyleClass().add("selected-image-cell");
				cell.getChildren().add(checkedImageView);
				NPMImageCell.setAlignment(checkedImageView, Pos.BOTTOM_RIGHT);
			}

			thumbnails.add(cell);
		}

		// Fill display from array
		Platform.runLater(new Runnable() {
            @Override
            public void run() {
                imageThumbnailsPane.getChildren().addAll(thumbnails);
            }
        });
	}

	/**
	 * Show images for a selected label
	 *
	 * @param labelName The label of the images
	 */
	private void showSelected(String labelName) {
		exitFullscreen();

		// Clear array and display
		thumbnails.clear();
		imageThumbnailsPane.getChildren().clear();

		labelName = labelName.replace("'", "''");

		ArrayList<NPMDBLabel> labels = dm.query("SELECT * FROM Picture_Label WHERE label_name='" + labelName + "'", "Label");

		// Fill array
		NPMImageCell cell;

		for (NPMDBLabel label : labels) {
			cell = new NPMImageCell(label.picture);

			if (selectedImages.contains(label.picture)) {
				Image checkedImage = new Image(getClass().getResourceAsStream("/view/images/icon-tick-theme-" + THEME_ID + ".png"), 25, 25, true, true);
				ImageView checkedImageView = new ImageView(checkedImage);
                cell.getStyleClass().removeAll("selected-image-cell-transparent");
				cell.getStyleClass().add("selected-image-cell");
				cell.getChildren().add(checkedImageView);
				NPMImageCell.setAlignment(checkedImageView, Pos.BOTTOM_RIGHT);
			}

			thumbnails.add(cell);
		}

		// Fill display from array
		Platform.runLater(new Runnable() {
            @Override
            public void run() {
                imageThumbnailsPane.getChildren().addAll(thumbnails);
            }
        });
	}

	private void preloadImages() {
		preloadedImages = new TreeMap<>();

		ArrayList<NPMDBPicture> pictures = dm.query("SELECT * FROM Picture", "Picture");

		int preloadAmount = (pictures.size() < PRELOADED_IMAGE_COUNT) ? pictures.size() : PRELOADED_IMAGE_COUNT;

		for (int i = 0; i < preloadAmount; ++i) {
			preloadedImages.put(pictures.get(i).getPath().getKey(), new Image("file:" + pictures.get(i).getPath().getKey(), NPMImageCell.THUMBNAIL_WIDTH, NPMImageCell.THUMBNAIL_HEIGHT, true, false, true));
		}
	}

	/**
	 * Load images from disk and display them
	 * @param from The index of the first image to load
	 * @param limit The number of images to load
	 */
	private void loadImages(final int from, final int limit) {
		exitFullscreen();

		// Reload all images
		if (from == 0) {
			thumbnails.clear();
			imageThumbnailsPane.getChildren().clear();
		}

		final ArrayList<NPMDBPicture> pictures = dm.query("SELECT * FROM Picture WHERE picture_id >" + from + " LIMIT " + limit, "Picture");

		loadMoreOnScroll = true;

		NPMImageCell cell;

		for (NPMDBPicture picture : pictures) {
			cell = new NPMImageCell(picture);

			if (selectedImages.contains(picture)) {
				Image checkedImage = new Image(getClass().getResourceAsStream("/view/images/icon-tick-theme-" + THEME_ID + ".png"), 25, 25, true, true);
				ImageView checkedImageView = new ImageView(checkedImage);
                cell.getStyleClass().removeAll("selected-image-cell-transparent");
				cell.getStyleClass().add("selected-image-cell");
				cell.getChildren().add(checkedImageView);
				NPMImageCell.setAlignment(checkedImageView, Pos.BOTTOM_RIGHT);
			}

			thumbnails.add(cell);
		}

		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				imageThumbnailsPane.getChildren().addAll(thumbnails.subList(from, thumbnails.size()));

				if (tutorial.shouldShow() && thumbnails.size() > 0) {
					tutorial.add(thumbnails.get(0),2);
					if (thumbnails.size() <= INITIAL_LOAD_AMOUNT) tutorial.presentNext(true);
					else tutorial.presentNext(false);
				}
			}
		});
	}

	private void loadAllUntagged() {
		final ArrayList<NPMDBPicture> pictures = dm.query("SELECT * FROM Picture", "Picture");

		if (pictures.size() == 0)
			return;


        final ArrayList<NPMDBPicture> untagged_images = dm.query("SELECT  Picture.picture_id AS picture_id, Picture.path AS path, Picture.room_id AS room_id, Picture.date AS date, Picture.comment AS comment\n" +
                "FROM Picture\n" +
                " LEFT JOIN Child_Tag_Picture\n" +
                "   ON Picture.picture_id = Child_Tag_Picture.picture_id\n" +
                "EXCEPT\n" +
                "SELECT  Picture.picture_id, Picture.path, Picture.room_id, Picture.date, Picture.comment\n" +
                "FROM Picture\n" +
                "NATURAL JOIN Child_Tag_Picture\n" +
                "INTERSECT\n" +
                "SELECT  Picture.picture_id AS picture_id, Picture.path AS path, Picture.room_id AS room_id, Picture.date AS date, Picture.comment AS comment\n" +
                "FROM Picture\n" +
                " LEFT JOIN Picture_Label\n" +
                "   ON Picture.picture_id = Picture_Label.picture_id\n" +
                "EXCEPT\n" +
                "SELECT  Picture.picture_id, Picture.path, Picture.room_id, Picture.date, Picture.comment\n" +
                "FROM Picture\n" +
                " NATURAL JOIN Picture_Label;" , "Picture");

		exitFullscreen();

		thumbnails.clear();
		imageThumbnailsPane.getChildren().clear();
		untaggedImages.clear();


		loadMoreOnScroll = false;

		NPMImageCell cell;

		for (NPMDBPicture picture : untagged_images) {
			cell = new NPMImageCell(picture);

			if (selectedImages.contains(picture)) {
				Image checkedImage = new Image(getClass().getResourceAsStream("/view/images/icon-tick-theme-" + THEME_ID + ".png"), 25, 25, true, true);
				ImageView checkedImageView = new ImageView(checkedImage);
                cell.getStyleClass().removeAll("selected-image-cell-transparent");
				cell.getStyleClass().add("selected-image-cell");
				cell.getChildren().add(checkedImageView);
				NPMImageCell.setAlignment(checkedImageView, Pos.BOTTOM_RIGHT);
			}

			thumbnails.add(cell);
		}

		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				imageThumbnailsPane.getChildren().addAll(thumbnails);
			}
		});
	}

	private void loadAllSelected() {
		exitFullscreen();

		thumbnails.clear();
		imageThumbnailsPane.getChildren().clear();

		NPMImageCell cell;

		loadMoreOnScroll = false;

		for (NPMDBPicture picture : selectedImages) {
			cell = new NPMImageCell(picture);

			Image checkedImage = new Image(getClass().getResourceAsStream("/view/images/icon-tick-theme-" + THEME_ID + ".png"), 25, 25, true, true);
			ImageView checkedImageView = new ImageView(checkedImage);
            cell.getStyleClass().removeAll("selected-image-cell-transparent");
			cell.getStyleClass().add("selected-image-cell");
			cell.getChildren().add(checkedImageView);
			NPMImageCell.setAlignment(checkedImageView, Pos.BOTTOM_RIGHT);

			thumbnails.add(cell);
		}

		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				imageThumbnailsPane.getChildren().addAll(thumbnails);
			}
		});
	}

	private void clearSelection() {
		selectedImages.clear();
		NPMTagManager.getInstance().clear();

		for (NPMImageCell cell : thumbnails) {
			cell.getStyleClass().remove("selected-image-cell");
            // Clear the selection indicator (the tick):
			if (cell.getChildren().size() > 1) {
				cell.getChildren().remove(1);
			}
		}
	}

	private void exitFullscreen() {
		if (centerPane.getChildren().size() > 1) {
			centerPane.getChildren().remove(1);
			centerPane.getChildren().get(0).setEffect(null);

			if (selectedImages.size() > 0) {
				rightSideBar.showTaggingOptions(true, false);
			} else {
				rightSideBar.showTaggingOptions(false, false);
			}
		}
	}

    private void highlightBtnAllPhotos() {
        clearAllHighligh();
        // Style
        btnAll.getStyleClass().remove("button-default-regular");
        btnAll.getStyleClass().add("button-selected");
        // Clear search bar
        searchBar.getEditor().clear();
    }

    private void highlightBtnUntagged() {
        clearAllHighligh();
        // Style
        btnUntagged.getStyleClass().remove("button-default-regular");
        btnUntagged.getStyleClass().add("button-selected");

        // Clear search bar
        searchBar.getEditor().clear();
    }

    private void highlightBtnSelected() {
        clearAllHighligh();
        // Style
        btnSelected.getStyleClass().remove("button-default-regular");
        btnSelected.getStyleClass().add("button-selected");

        // Clear search bar
        searchBar.getEditor().clear();
    }

	private void clearAllHighligh() {
		btnAll.getStyleClass().remove("button-selected");
		btnAll.getStyleClass().add("button-default-regular");
		btnUntagged.getStyleClass().remove("button-selected");
		btnUntagged.getStyleClass().add("button-default-regular");
		btnSelected.getStyleClass().remove("button-selected");
		btnSelected.getStyleClass().add("button-default-regular");
	}

	/**
	 * NPMSearchListener interface class
	 * @see model.search.NPMSearchListener
	 * @param searchResults the current search results
	 */
	@Override
	public void notify(HashMap searchResults) {
		possibleSearchResults = searchResults;
	}

	public static ObservableList<NPMDBPicture> getSelectedImages() {
		return selectedImages;
	}

	public static ObservableList<NPMImageCell> getThumbnails() {
		return thumbnails;
	}

	public static TreeMap<String, Image> getPreloadedImages() {
		return preloadedImages;
	}

	public Stage getStage(){
        return stage;
    }

	public static void main(String[] args) {
        try {
            URL iconURL = MainView.class.getResource("/view/images/icon-mac-app.png");
            java.awt.Image image = new ImageIcon(iconURL).getImage();
            com.apple.eawt.Application.getApplication().setDockIconImage(image);
        } catch (Exception e) {
            // Won't work on Windows or Linux.
        }
		launch(args);
	}

}
