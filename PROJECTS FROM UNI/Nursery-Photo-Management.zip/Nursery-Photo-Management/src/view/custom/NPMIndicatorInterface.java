package view.custom;

/**
 * Created by alextelek on 21/03/15.
 */
public interface NPMIndicatorInterface {

    /**
     * This method should be called when either a
     * background thread started or tagging is being
     * processed
     *
     * Whenever this method is called update the loading indicator
     * accordingly
     *
     * @param isFinished whether the downloading is
     *                   is finished or not
     */
    public void onChanged(boolean isFinished);
}
