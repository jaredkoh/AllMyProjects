package view.custom;

import view.SettingsView;

/**
 * Custom CSS color theme
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMColorTheme {
	private SettingsView parent;

	private String name;
	private String author;
	private String file;

	public NPMColorTheme(SettingsView parent, String name, String author, String file) {
		this.parent = parent;
		this.name = name;
		this.author = author;
		this.file = file;
	}

	public String createCSSFile() {
		return getClass().getResource(file).toExternalForm();
	}

	public String getName() {
		return name;
	}

	public String getAuthor() {
		return author;
	}

	@Override
	public String toString() {
		return name;
	}
}
