package view.custom;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.layout.HBox;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Custom Indicator class with a ProgressIndicator and a Label
 * Saving time to the local database is quite fast, but if it takes
 * a bit longer then the indicator will show it. After a saving finished
 * we show the loading for 1 more second
 *
 * @see javafx.scene.control.ProgressIndicator
 * @version 1.0
 * Created by Team 3-B on 21/03/15.
 */
public class NPMIndicator extends HBox {
    private ProgressIndicator indicator;
    private Label label;
    private boolean isRunning;

    /**
     * Constructor of the indicator class
     * with the chosen design and label
     */
    public NPMIndicator() {
        super(0);
        setAlignment(Pos.CENTER);

        indicator = new ProgressIndicator();

        Date cd = new Date();
        DateFormat df = new SimpleDateFormat("hh:mm a");

        label = new Label("Saved at " + df.format(cd));
        label.setPadding(new Insets(0,0,0,5));
        label.getStyleClass().add("saving-label");

        getChildren().add(label);
    }

    /**
     * Start animating the indicator
     * before the saving starts
     */
    public void startAnimate() {
        if (!isRunning) {
            isRunning = true;

            label.setText("Saving...");
            getChildren().add(0, indicator);
            indicator.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);
        }
    }

    /**
     * Method to stop animation
     * Once saving to the database finished keep animate
     * the indicator for one second then hide it
     * @see javafx.application.Platform
     * @see java.lang.Runnable
     * @see java.util.TimerTask
     * @see java.util.Timer
     */
    public void stopAnimate() {
        new Timer().schedule(new TimerTask() {
            @Override
            public void run() {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        Date cd = new Date();
                        DateFormat df = new SimpleDateFormat("hh:mm a");

                        label.setText("Saved at " + df.format(cd));
                        getChildren().remove(indicator);

                        isRunning = false;
                    }
                });
            }
        }, 1000);
    }

    /**
     * Getter to return true if the indicator is animating,
     * false otherwise
     * @return true/false
     */
    public boolean isRunning() {
        return isRunning;
    }
}
