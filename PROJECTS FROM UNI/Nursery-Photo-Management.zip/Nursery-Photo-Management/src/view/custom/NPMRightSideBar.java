package view.custom;

import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.stage.DirectoryChooser;
import javafx.util.Callback;

import javafx.util.StringConverter;
import model.database.*;

import model.search.NPMComboBoxListener;
import model.search.NPMSearchListener;
import model.search.NPMSearchManager;
import model.search.NPMSearchResult;
import model.tag.NPMTagManager;
import view.MainView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * A custom VBox that is used as the right side bar
 *
 * @author Team 3-B
 * @version 1.0
 */
@SuppressWarnings("unchecked")
public class NPMRightSideBar extends VBox implements NPMSearchListener, NPMBubbleTagInterface, NPMIndicatorInterface {
	private NPMDBDataManager dm = NPMDBDataManager.getInstance();
	private ArrayList<Node> elements = new ArrayList<>();

	private MainView parent;

	private Label fileName;
	private Label childrenPanePromptText;
	private Label tagsPanePromptText;
	private DatePicker pictureDatePicker;
	private TextArea description;
	private ChoiceBox<String> rooms;
	private FlowPane childrenPane, tagsPane;
	private ComboBox<String> childrenInput, tagsInput;
    private Button exportPictures;
	private NPMIndicator indicator;

	ObservableList roomsList;
	private HashMap<String, NPMSearchResult> possibleSearchResults;

	public NPMRightSideBar(MainView parent) {
		this.parent = parent;
		this.fileName = new Label("IMG 0000");
		this.pictureDatePicker = createDatePicker();
		elements.add(this.pictureDatePicker);
		this.description = new TextArea();
		elements.add(this.description);
		this.rooms = new ChoiceBox<>();
		elements.add(this.rooms);
		this.childrenPane = new FlowPane();
		this.tagsPane = new FlowPane();
		this.childrenInput = new ComboBox<>();
		elements.add(this.childrenInput);
		this.tagsInput = new ComboBox<>();
		elements.add(this.tagsInput);
        this.exportPictures = new Button("Export Selected");
		this.indicator = new NPMIndicator();
		NPMTagManager.getInstance().indicatorInterface = this;
		this.getStyleClass().add("right-side-bar");

		setup();
	}

	private void setup() {
		fileName.getStyleClass().add("filename-label");
		description.setPrefRowCount(5);
		description.setPromptText("Add description...");
		description.setTooltip(new Tooltip("Add a description to the selected picture(s)"));
		description.setWrapText(true);

		description.focusedProperty().addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				if (!newValue) NPMTagManager.getInstance().saveDescription(description.getText(), MainView.getSelectedImages());
			}
		});
		roomsList = FXCollections.observableArrayList();
		ArrayList<NPMDBRoom> dbRoomsList = dm.query("SELECT * FROM Picture_Room", "Room");

		for (NPMDBRoom room : dbRoomsList) {
			roomsList.add(room.roomName);
		}

        rooms.setPrefWidth(250);
		rooms.setTooltip(new Tooltip("Select the room the picture was taken in"));
		rooms.setItems(roomsList);
		rooms.getSelectionModel().selectedIndexProperty().addListener(new ChangeListener<Number>() {
			@Override
			public void changed(ObservableValue<? extends Number> observable, Number oldValue, Number newValue) {
				if (newValue.intValue() >= 0 && oldValue.intValue() != -1) {
					boolean isExtra = !rooms.getItems().equals(roomsList);
					if (isExtra && newValue.intValue() != 0) {
						NPMTagManager.getInstance().saveRoom(new NPMDBRoom(newValue.longValue()), MainView.getSelectedImages());
						rooms.setItems(roomsList);
						rooms.setValue(roomsList.get(newValue.intValue() - 1).toString());
					} else if (!isExtra) NPMTagManager.getInstance().saveRoom(new NPMDBRoom(newValue.longValue() + 1), MainView.getSelectedImages());
				}
			}
		});

		childrenPane.setHgap(5);
		childrenPane.setVgap(5);
		childrenPane.setPadding(new Insets(5));
		childrenPane.setPrefWidth(Double.MAX_VALUE);
		childrenPane.setPrefHeight(80);
		childrenPane.getStyleClass().add("tag-pane");
        childrenPanePromptText = new Label("");
		childrenPanePromptText.setStyle("-fx-font-style: italic; -fx-text-fill: white;");
		childrenPane.getChildren().add(childrenPanePromptText);
		childrenPane.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				childrenInput.requestFocus();
			}
		});

		childrenInput.setPromptText("Enter names of children...");
		childrenInput.setEditable(true);
		childrenInput.setPrefWidth(Double.MAX_VALUE);

		// Create listener for children combobox
		NPMComboBoxListener listener = new NPMComboBoxListener(childrenInput, NPMSearchManager.SearchType.TAG_NAME);
		listener.searchDelegate = this;
		childrenInput.addEventHandler(javafx.scene.input.KeyEvent.ANY, listener);

		childrenInput.getEditor().addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (event.getCode() == KeyCode.ENTER) {
					String childName = childrenInput.getEditor().getText();

					//add code for checking the child name in the database here
					addTagToPane(childName, null, childrenPane, childrenInput, false, true);
					event.consume();

					childrenInput.getEditor().clear();
				}
			}
		});

		tagsPane.setHgap(5);
		tagsPane.setVgap(5);
        tagsPane.setPadding(new Insets(5));
        tagsPane.setPrefWidth(Double.MAX_VALUE);
        tagsPane.setPrefHeight(80);
		tagsPane.getStyleClass().add("tag-pane");
        tagsPanePromptText = new Label("");
		tagsPanePromptText.setStyle("-fx-font-style: italic; -fx-text-fill: white;");
		tagsPane.getChildren().add(tagsPanePromptText);
		tagsPane.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				tagsInput.requestFocus();
			}
		});

		tagsInput.setPromptText("Enter labels...");
		tagsInput.setEditable(true);
		tagsInput.setPrefWidth(Double.MAX_VALUE);

		// Create listener for tag combo box
		listener = new NPMComboBoxListener(tagsInput, NPMSearchManager.SearchType.LABEL_EVENT);
		listener.searchDelegate = this;
		tagsInput.addEventHandler(javafx.scene.input.KeyEvent.ANY, listener);

		tagsInput.getEditor().addEventFilter(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (event.getCode() == KeyCode.ENTER) {
					String tagName = tagsInput.getEditor().getText();

					//add code for checking the tag in the database here
					addTagToPane(tagName, null, tagsPane, tagsInput, false, true);
					event.consume();

					tagsInput.getEditor().clear();
				}
			}
		});

        exportPictures.setPrefWidth(250);
        exportPictures.getStyleClass().add("button-default");
        exportPictures.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                DirectoryChooser directoryChooser1 = new DirectoryChooser();
                File selectedDirectory =
                        directoryChooser1.showDialog(parent.getStage());
                if(selectedDirectory != null){

                    File folder = new File(selectedDirectory.getAbsolutePath());
                    // get all selected images paths
                    ObservableList<NPMDBPicture> paths = MainView.getSelectedImages();
                    for(NPMDBPicture picture : paths){
                        String format;
                        String path = picture.getPath().getKey();
                        File selectedFile = new File(path);
                        if(path.contains("jpg")) {
                            format = ".jpg";
                        }
                        else{
                            format = ".png";
                        }

                        File file = new File(folder + "/" + picture.getFileName() + format);

                        try {
                            FileInputStream inStream = new FileInputStream(selectedFile);
                            FileOutputStream outStream = new FileOutputStream(file);
                            byte[] buffer = new byte[1024];

                            int length;
                            //copy the file content in bytes
                            while ((length = inStream.read(buffer)) > 0){
                                outStream.write(buffer, 0, length);
                            }

                            inStream.close();
                            outStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }

                }

            }
        });

		// Initially hide tagging options
		showTaggingOptions(false, false);

		this.setPrefWidth(250);
		this.setPadding(new Insets(10));
		this.setSpacing(10);

        // Set up traverse function in items which need traverse
        pictureDatePicker.addEventFilter(KeyEvent.KEY_PRESSED, itemSelector());
        description.addEventFilter(KeyEvent.KEY_PRESSED, itemSelector());
        rooms.addEventFilter(KeyEvent.KEY_PRESSED, itemSelector());
        childrenInput.addEventFilter(KeyEvent.KEY_PRESSED, itemSelector());
        tagsInput.addEventFilter(KeyEvent.KEY_PRESSED, itemSelector());


	}

	/**
	 * Create an instance of the date picker
	 * Also create custom (disabled) cells for future dates
	 * @return The instance of the date picker
	 */
	private DatePicker createDatePicker() {
		pictureDatePicker = new DatePicker(LocalDate.now());
		pictureDatePicker.setTooltip(new Tooltip("Pick the day when the picture was taken"));
		pictureDatePicker.setPromptText("Multiple Dates");
        pictureDatePicker.setPrefWidth(250);
		pictureDatePicker.valueProperty().addListener(new ChangeListener<LocalDate>() {
			@Override
			public void changed(ObservableValue<? extends LocalDate> observable, LocalDate oldValue, LocalDate newValue) {
				if (newValue != null) {
					Date date = Date.from(newValue.atStartOfDay(ZoneId.systemDefault()).toInstant());
					NPMTagManager.getInstance().saveDate(date, MainView.getSelectedImages());
					parent.updateTreeViews();
				}
			}
		});

		StringConverter converter = new StringConverter<LocalDate>() {
			DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd MMM yyyy");
			@Override
			public String toString(LocalDate date) {
				if (date != null) {
					return dateFormatter.format(date);
				} else {
					return "";
				}
			}
			@Override
			public LocalDate fromString(String string) {
				if (string != null && !string.isEmpty()) {
					return LocalDate.parse(string, dateFormatter);
				} else {
					return null;
				}
			}
		};
		pictureDatePicker.setConverter(converter);

		final Callback<DatePicker, DateCell> dayCellFactory = new Callback<DatePicker, DateCell>() {
			@Override
			public DateCell call(final DatePicker dp) {
				return new DateCell() {
					@Override
					public void updateItem(LocalDate item, boolean empty) {
						super.updateItem(item, empty);

						if (item.isAfter(LocalDate.now())) {
							setDisable(true);
							setStyle("-fx-background-color: #ffc0cb;");
						}
					}
				};
			}
		};
		pictureDatePicker.setDayCellFactory(dayCellFactory);

		return pictureDatePicker;
	}

	/**
	 * Depending on the parameter, toggle the content
	 * of the right side bar
	 * @param show Show / hide tagging options
	 * @param fullscreen Whether an image is in fullscreen or not
	 */
	public void showTaggingOptions(boolean show, boolean fullscreen) {
		if (show) {
			this.getChildren().clear();
			this.getChildren().addAll(this.fileName, this.pictureDatePicker, this.description, this.rooms, combineTagging(this.childrenInput, this.childrenPane), combineTagging(this.tagsInput, this.tagsPane), this.exportPictures, indicator);
			this.setAlignment(Pos.TOP_LEFT);
		} else {
			this.getChildren().clear();
			Label message;

			if (fullscreen) {
				message = new Label("Close the fullscreen view to go back to the tagging options.\n\n" +
						"To do so, simply click on the image or the dark area behind it.");
			} else {
				message = new Label("Select photos to edit details.\n\n" +
						"To select a photo, simply click on it.\nTo deselect it, click on it again.");
			}
			message.setWrapText(true);
			message.getStyleClass().add("message");
			this.getChildren().add(message);
			this.setAlignment(Pos.CENTER);
		}
	}

	/**
	 * Set the room widget with the appropriate
	 * room name based on the selected images
	 * @param room the room to select, if null then multiple rooms
	 * @param show whether to show the room or not
	 */
	public void setRoomName(NPMDBRoom room, boolean show) {
		if (show) {
			this.rooms.setItems(roomsList);
			this.rooms.setValue(room.roomName);
		}
		else {
			ObservableList rl = FXCollections.observableArrayList();
			rl.add("Multiple rooms");
			rl.addAll(roomsList);
			this.rooms.setItems(rl);
			this.rooms.setValue(rl.get(0).toString());
		}
	}

	/**
	 * Set the description widget with the appropriate
	 * description based on the selected images
	 * @param d the description of the image selected, if null then multiple
	 *          description available
	 * @param show whether to show the description or not
	 */
	public void setDescription(String d, boolean show) {
		if (!show) this.description.setPromptText("Multiple descriptions");
		else this.description.setPromptText("Add description...");
		this.description.setText(d);
	}

	/**
	 * Set the file name of the selected image,
	 * if multiple images are selected then
	 * indicate it's multiple
	 * @param s the string to set
	 */
	public void setFileName(String s) {
		this.fileName.setText(s);
	}

	/**
	 * Set the date for the selected dates
	 * if date null then multiple data available,
	 * so show nothing, just the prompt text
	 * @param d the date to show
	 * @param show whether to show the date or not
	 */
	public void setDate(Date d, boolean show) {
		if (show) {
			Calendar c = Calendar.getInstance();
			c.setTime(d);
			this.pictureDatePicker.setValue(LocalDate.of(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH)));
		}
		else clearDate();
	}

	public void clearDate() {
		this.pictureDatePicker.setValue(null);
	}

	/**
	 * Appends a bubble tag to a pane
	 * @param tag 		 The title (or name) of the tag
	 * @param pane 		 The pane to add the image to
	 * @param from 		 The node that the title was typed into
	 * @param additional is the tag an additional tag, such as a unique label
	 * @param removable  is the tag removable by the user or not
	 *                   unique label shouldn't be removed by user, but by automatically
	 */
	private void addTagToPane(String tag, NPMDBTagElement element, Pane pane, ComboBox from, boolean additional, boolean removable) {
		if (tag != null) {
			NPMBubbleTag newTag = new NPMBubbleTag(tag).createNewTag(removable);
			newTag.delegate = this;
			newTag.setTagElement(element);

			boolean isValid = additional;
			if (!additional)
				isValid = newTag.isValidTag(pane.equals(childrenPane)
						? NPMSearchManager.SearchType.TAG_NAME
						: NPMSearchManager.SearchType.LABEL_EVENT);

			if (!pane.getChildren().isEmpty() && pane.getChildren().get(0).getClass() == Label.class && isValid) {
				pane.getChildren().remove(0);
			}

			if (!pane.getChildren().contains(newTag) && isValid) {
				if (pane.getChildren().size() > 0 && !((NPMBubbleTag)pane.getChildren().get(pane.getChildren().size() - 1)).isRemovable())
					pane.getChildren().add(pane.getChildren().size() - 1, newTag);
				else pane.getChildren().add(newTag);

				if (pane.equals(childrenPane) && from != null) NPMTagManager.getInstance().saveNewTag(newTag, MainView.getSelectedImages());
				if (pane.equals(tagsPane) && from != null) {
					NPMTagManager.getInstance().saveNewLabel(newTag, MainView.getSelectedImages());
					parent.updateTreeViews();
				}
			}
		}
	}

	/**
	 * Overridden method from NPMBubbleTagInterface
	 * @param tag the object to be removed
	 */
	@Override
	public void removeTag(NPMBubbleTag tag) {
		if (!tagsPane.getChildren().isEmpty() &&
				tagsPane.getChildren().get(0).getClass() != Label.class &&
				tagsPane.getChildren().contains(tag)) {
			int size = tagsPane.getChildren().size();
			if (size > 0)  {
				NPMTagManager.getInstance().removeLabel(tag, MainView.getSelectedImages());
				tagsPane.getChildren().remove(tag);
			}
			if (tagsPane.getChildren().size() == 0) tagsPane.getChildren().add(tagsPanePromptText);

			parent.updateTreeViews();
		}
		if (!childrenPane.getChildren().isEmpty() &&
				childrenPane.getChildren().get(0).getClass() != Label.class &&
				childrenPane.getChildren().contains(tag)) {
			int size = childrenPane.getChildren().size();
			if (size > 0) {
				NPMTagManager.getInstance().removeTag(tag, MainView.getSelectedImages());
				childrenPane.getChildren().remove(tag);
			}
			if (childrenPane.getChildren().size() == 0) childrenPane.getChildren().add(childrenPanePromptText);
		}
	}

	//MARK: Loading data from database to the UI

	/**
	 * Load all the data from the database to
	 * the ui for the selected picture
	 * Call this method when an image is selected
	 * @see view.MainView
	 * @see model.database.NPMDBPicture
	 */
	public void loadExistingDataForPicture(NPMDBPicture picture) {
		NPMTagManager.getInstance().loadElementsFromDatabase(picture);
		updateUI(picture, false);
	}

	/**
	 * Remove the data from the ui, based on the image deselected
	 * Call this method when the user deselects an image
	 * @see view.MainView
	 * @see model.database.NPMDBPicture
	 */
	public void removeExistingDataForPicture(NPMDBPicture picture) {
		NPMTagManager.getInstance().removeElementsFromUI(picture);
		updateUI(picture, true);
	}

	/*
	 * Update the ui with the tags currently applicable
	 */
	private void updateUI(NPMDBPicture picture, boolean isRemove) {
		// clear flow panes first
		clearPane(childrenPane, childrenPanePromptText);
		clearPane(tagsPane, tagsPanePromptText);

		ArrayList<NPMDBTagElement> commonElements = NPMTagManager.getInstance().getCommonTagsAndLabels(picture.id, isRemove);

		if (!commonElements.isEmpty()) {
			for (NPMDBTagElement element : commonElements) {
				if (element.getClass().equals(NPMDBTag.class)) {
					addTagToPane(element.getReadableName(), element, childrenPane, null, false, true);
				} else {
					addTagToPane(element.getReadableName(), element, tagsPane, null, false, true);
				}
			}
		}

		// Setup unique labels on the view
		HashMap<String, Integer> uniqueTags = NPMTagManager.getInstance().numberOfUniqueElements();
		int noUniqueTags = uniqueTags.get("tag") - (childrenPane.getChildren().get(0).getClass() == Label.class ? 0 : childrenPane.getChildren().size());
		int noUniqueLabels = uniqueTags.get("label") - (tagsPane.getChildren().get(0).getClass() == Label.class ? 0 : tagsPane.getChildren().size());

		if (noUniqueTags > 0) {
			String s = noUniqueTags == 1 ? "+ " + noUniqueTags + " unique child" : "+ " + noUniqueTags + " unique children";
			addTagToPane(s, null, childrenPane, null, true, false);
		}
		if (noUniqueLabels > 0) {
			String s = noUniqueLabels == 1 ? "+ " + noUniqueLabels + " unique label" : "+ " + noUniqueLabels + " unique labels";
			addTagToPane(s, null, tagsPane, null, true, false);
		}

		if (NPMHelpTutorial.getInstance().shouldShow() && MainView.getSelectedImages().size() == 1) NPMHelpTutorial.getInstance().presentNext(false);
	}

	/*
	 * Clear flow pane contents and place the placeholder strings back in place
	 */
	private void clearPane(FlowPane pane, Label placeholder) {
		if (!pane.getChildren().isEmpty() && pane.getChildren().get(0).getClass() != Label.class) {
			pane.getChildren().clear();
			pane.getChildren().add(placeholder);
		}
	}

	/**
	 * NPMSearchListener interface class
	 * @see model.search.NPMSearchListener
	 * @param searchResults the current search results
	 */
	@Override
	public void notify(HashMap searchResults) {
		possibleSearchResults = searchResults;
	}

	/**
	 * Overridden method from NPMIndicator interface class
	 * @see view.custom.NPMIndicatorInterface
	 * @param isFinished whether the loading is
	 *                   finished or not
	 */
	@Override
	public void onChanged(boolean isFinished) {
		if (isFinished) indicator.stopAnimate();
		else indicator.startAnimate();
	}

	/**
     * Helps to traverse amongst right panel's items to type
     * more conveniently by using tab button
     * @return nextField next item, which will be focused
     */
    private EventHandler itemSelector() {
        final EventHandler nextField = new EventHandler<KeyEvent>() {
            @Override
            public void handle(final KeyEvent event) {

                ArrayList<Node> selectableItems = new ArrayList<>();
                selectableItems.add(pictureDatePicker);
                selectableItems.add(description);
                selectableItems.add(rooms);
                selectableItems.add(childrenInput);
                selectableItems.add(tagsInput);

                if (event.getCode() == KeyCode.TAB) {
                    event.consume();

                    Node node = (Node) event.getSource();

                    int nextItemIndex = 0;

					if (event.isShiftDown()) {
						nextItemIndex = selectableItems.indexOf(node) - 1;
						if (nextItemIndex < 0) {
							nextItemIndex = selectableItems.size() - 1;
						}
					} else {
						nextItemIndex = selectableItems.indexOf(node) + 1;
						if (nextItemIndex > selectableItems.size() - 1) {
							nextItemIndex = 0;
						}
					}

                    Node nextNode = selectableItems.get(nextItemIndex);
                    nextNode.requestFocus();

                    if (nextNode.equals(rooms)) {
                        rooms.show();
                    } else if (nextNode.equals(pictureDatePicker)) {
                        pictureDatePicker.show();
                    }
                }
            }
        };

        return nextField;
    }

	/**
	 * Return the registered nodes with the tutorial
	 * @see javafx.scene.Node
	 * @see view.custom.NPMHelpTutorial
	 * @return array list of nodes
	 */
	public ArrayList<Node> getElements() {
		return elements;
	}

	private VBox combineTagging(Node input, Node pane) {
		VBox container = new VBox(0);
		container.getChildren().addAll(input, pane);
		container.getStyleClass().add("tag-pane-container");
		return container;
	}

}
