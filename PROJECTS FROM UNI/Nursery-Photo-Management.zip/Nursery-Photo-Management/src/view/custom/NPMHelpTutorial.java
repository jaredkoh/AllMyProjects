package view.custom;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import model.database.NPMDBDataManager;
import org.controlsfx.control.PopOver;
import view.MainView;
import java.util.ArrayList;
import java.util.LinkedList;

/**
 * NPMHelpTutorial class which consist a help setup for
 * the user to guide him/her over the main features
 *
 * @version 1.0
 * @see model.database.NPMDBDataManager
 * Created by Team-3B on 22/03/15.
 */
public class NPMHelpTutorial<E> {
    private static NPMHelpTutorial tutorialInstance;

    private int currentPosition = 0;
    private boolean isImageCellAdded = false;
    private boolean isCanceled = false;
    private LinkedList<PopOver> popOvers = new LinkedList<>();
    private LinkedList<E> nodes = new LinkedList<>();
    private ArrayList<E> elements = new ArrayList<>();

    /**
     * Getting the instance of the class
     * based on the Singleton design pattern
     *
     * @return the instance of this class
     */
    public static NPMHelpTutorial getInstance() {
        if (tutorialInstance == null) {
            tutorialInstance = new NPMHelpTutorial();
        }
        return tutorialInstance;
    }

    /**
     * Convenient method to add as many nodes
     * as we want in order of the tutorial
     * @param elements
     */
    public void addAll(E... elements) {
        for (E e : elements) {
            this.elements.add(e);
        }
    }

    /**
     * Add one node element to the list of
     * the tutorial in a specific index.
     * @param element the element to add
     * @param index the index to insert it
     */
    public void add(E element, int index) {
        if ((element.getClass() == NPMImageCell.class) && (!isImageCellAdded && currentPosition < 4)) {
            if (currentPosition == 1) nodes.add(index, element);
            else if (currentPosition == 2) nodes.add(index - 2, element);
            else nodes.addFirst(element);
            isImageCellAdded = true;
        }
    }

    /**
     * Start the tutorial from the position the
     * ended last time. Or this is the first time
     */
    public void start() {
        currentPosition = NPMDBDataManager.getInstance().queryInteger("SELECT * FROM Settings", "tutorial_id") + 1;

        // Use the switch statement without a break, so if
        // the current settings is at 5, the user will only
        // get 5,6,7,8
        switch (currentPosition) {
            case 1: addHelpWith("Welcome to a short guide of your new photo-management app.\nThe next few messages will help you get acquainted with its\nfeatures and layout.", false, true, 1, PopOver.ArrowLocation.LEFT_TOP);
                    nodes.addLast(elements.get(0));
            case 2: addHelpWith("After you have transferred your images from your camera\nto your computer, import them into the photo-management application\nby clicking on the Import button. " +
                    "After you have imported your images,\nthey will show on the right-hand side, where you can\nbegin the tagging process.", true, true, 2, PopOver.ArrowLocation.LEFT_TOP);
                    nodes.addLast(elements.get(0));
            case 3: addHelpWith("To begin tagging an image, simply click it once to select it.\nYou can select multiple images by clicking on each one individually,\nand you can deselect them by clicking on them a second time.", true, true, 3, PopOver.ArrowLocation.LEFT_TOP);
            case 4: addHelpWith("The date the image was taken is shown here for your convenience,\nand is completely editable should you wish to change it.", true, true, 4, PopOver.ArrowLocation.RIGHT_TOP);
                    nodes.addLast(elements.get(1));
            case 5: addHelpWith("Enter any comments or observations regarding the photo here.\nThere is no character limit.", true, true, 5, PopOver.ArrowLocation.RIGHT_CENTER);
                    nodes.addLast(elements.get(2));
            case 6: addHelpWith("The room in which the picture was taken.\nSimply select an entry from the drop-down menu.", true, true, 6, PopOver.ArrowLocation.RIGHT_CENTER);
                    nodes.addLast(elements.get(3));
            case 7: addHelpWith("To tag children into photos, simply begin typing their name\nand select an entry from the suggestions below.\nTo remove a tag, simply click on the \"x\"\non the right hand side of the bubble.", true, true, 7, PopOver.ArrowLocation.RIGHT_CENTER);
                    nodes.addLast(elements.get(4));
            case 8: addHelpWith("To tag anything else other than children (e.g. Christmas, or Cake)\nsimply type it here and hit the \"Enter\" key.", true, true, 8, PopOver.ArrowLocation.RIGHT_CENTER);
                    nodes.addLast(elements.get(5));
            case 9: addHelpWith("From the Settings panel you can add or remove children and rooms,\nand backup the database. You can find further instructions\nregarding the back-up procedure in the Installation Manual. Enjoy!", true, false, 9, PopOver.ArrowLocation.LEFT_BOTTOM);
                    nodes.addLast(elements.get(6));
            default: break;
        }
        
        if (shouldShow() && currentPosition != 3) {
            // show first help
            PopOver first = popOvers.getFirst();
            Node firstNode = (Node)nodes.getFirst();
            first.show(firstNode);
        }
    }

    /**
     * Call this method when presentNext is needed
     * It is forcing to go too the next one, shouldn't
     * be used just if really needed!
     */
    public void presentNext(boolean fetchNextOne) {
        PopOver next = popOvers.getFirst();
        Node nextNode = (Node)nodes.getFirst();
        next.show(nextNode);

        if (fetchNextOne) currentPosition++;
    }

    private void addHelpWith(String text, boolean addCancel, boolean addNext, int step, PopOver.ArrowLocation arrowLocation) {
        // Create a popOver object and setup all the design
        // settings, content and options
        PopOver popOver = new PopOver();
        popOver.setArrowLocation(arrowLocation);
        popOver.setDetachable(false);
        popOver.setMaxSize(300,200);

        BorderPane content = new BorderPane();
        Label headerLabel = new Label("Step " + step);
        headerLabel.setStyle("-fx-font-family: Roboto; -fx-font-size: 18; -fx-text-alignment: justify; -fx-text-fill: #213B72");
        headerLabel.setPadding(new Insets(10, 0, 20, 10));

        Label textLabel = new Label(text);
        textLabel.setStyle("-fx-font-family: Roboto; -fx-font-size: 15; -fx-text-alignment: justify; -fx-text-fill: #636363");
        textLabel.setPadding(new Insets(0,10,20,10));

        HBox btnBox = new HBox();
        if (addCancel) {
            String cancelString = step == 9 ? "Done" : "Cancel";
            Button btnCancel = new Button(cancelString);
            btnCancel.getStyleClass().clear();
            btnCancel.getStyleClass().add("button-tutorial");
            btnCancel.setPadding(new Insets(5,5,5,5));
            btnCancel.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    exit();
                }
            });
            btnBox.getChildren().add(btnCancel);
            BorderPane.setAlignment(btnCancel, Pos.BOTTOM_RIGHT);
        }

        if (addNext) {
            Button btnNext = new Button("Next");
            btnNext.getStyleClass().clear();
            btnNext.getStyleClass().add("button-tutorial");
            btnNext.setPadding(new Insets(5,5,5,5));
            btnNext.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    next();
                }
            });
            btnBox.getChildren().add(btnNext);
            BorderPane.setAlignment(btnNext, Pos.BOTTOM_RIGHT);
        }

        btnBox.setAlignment(Pos.BOTTOM_RIGHT);

        content.setTop(headerLabel);
        content.setCenter(textLabel);
        content.setBottom(btnBox);

        popOver.setContentNode(content);

        popOvers.addLast(popOver);
    }

    private void next() {
        PopOver remove = popOvers.removeFirst();
        remove.hide();
        nodes.removeFirst();

        // Make sure the it saves the current position
        NPMDBDataManager.getInstance().update("UPDATE Settings SET tutorial_id=" + currentPosition);

        if ((currentPosition != 2 || MainView.getThumbnails().size() > 0) && shouldShow()) {
            // go to the next one
            PopOver next = popOvers.getFirst();
            Node nextNode = (Node)nodes.getFirst();
            next.show(nextNode);
            currentPosition++;
        }
    }

    private void exit() {
        PopOver remove = popOvers.removeFirst();
        remove.hide();
        nodes.removeFirst();
        isCanceled = true;

        NPMDBDataManager.getInstance().update("UPDATE Settings SET tutorial_id=" + currentPosition);
    }

    /**
     * Method should return true or false based on the
     * tutorial is presentable or not
     * @return true if the user should see the tutorial
     *         false if not
     */
    public boolean shouldShow() {
        if (isCanceled) return false;
        if (popOvers.size() > 0) {
            if (currentPosition > 3 && MainView.getSelectedImages().size() > 0) return true;
            else if (currentPosition == 3 && MainView.getThumbnails().size() > 0) return true;
            else if (currentPosition < 3) return true;
        }
        return  false;
    }
}
