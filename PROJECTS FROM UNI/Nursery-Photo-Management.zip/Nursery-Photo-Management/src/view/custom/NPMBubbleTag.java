package view.custom;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.text.Font;
import model.NPMTuple;
import model.database.NPMDBDataManager;
import model.database.NPMDBTagElement;
import model.search.NPMSearchManager;

/**
 * A (bubble shaped) tag label
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMBubbleTag extends HBox {
    public NPMBubbleTagInterface delegate;
    private boolean removable;
    private Button btnClose;
    private String tagName;
    private NPMDBTagElement tagElement;

    public NPMBubbleTag(String tagName) {
        this.tagName = tagName;
    }

    /**
     * Create a new custom HBox tag-box and return it,
     * so it can be added to the tagging field
     * @return new tag box
     */
    public NPMBubbleTag createNewTag(boolean removable) {
        this.removable = removable;
        getStyleClass().add("bubble-tag");
        setPrefHeight(25);

        Label lblName = new Label(tagName);
        if (removable) lblName.setPadding(new Insets(4,0,0,5));
        else lblName.setPadding(new Insets(4,5,0,5));
        lblName.getStyleClass().add("bubble-tag-label");
        HBox.setHgrow(lblName, Priority.ALWAYS);

        if (removable) {
            btnClose = new Button("x");
            btnClose.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    delegate.removeTag(NPMBubbleTag.this);
                }
            });
            btnClose.setMnemonicParsing(false);
            btnClose.setTextFill(javafx.scene.paint.Paint.valueOf("#b4b4b4"));
            btnClose.getStyleClass().add("bubble-tag-button");

            getChildren().addAll(lblName, btnClose);
        } else {
            getChildren().add(lblName);
        }

        return this;
    }

    /**
     * Find out if the tag we adding is new or already exist in the database
     * @param searchType the type of the search we are performing
     *                   TAG_NAME - We're not allowing random tags
     *                   LABEL_EVENT - new tags can be defined
     * @return true if the tag is already defined in the database (just if its a child, for label event is always true)
     *         false if the tag is random, should be allowed for better UX
     */
    public boolean isValidTag(NPMSearchManager.SearchType searchType) {
        if (tagName.equals("")) return false;
        if (searchType == NPMSearchManager.SearchType.TAG_NAME) {
            if (!tagName.contains(" ")) return false;
            NPMTuple<String, String> name = getTagName(searchType);
            String sql = "SELECT * FROM Child NATURAL JOIN Child_Tag_Picture NATURAL JOIN Picture WHERE first_name LIKE '" + name.getKey() + "' AND last_name LIKE '" + name.getValue() +"'";
            if (NPMDBDataManager.getInstance().query(sql, "Picture").size() > 0) return true;
        }
        return true;
    }

    /**
     * Getter method for the tag name
     * Either return a child name or a label name
     *
     * @see model.database.NPMDBTagElement
     *
     * @return the tag element used for this bubble tag
     */
    public NPMDBTagElement getTagElement() {
        return tagElement;
    }

    /**
     * Set the tag element to the bubble tag after
     * creation. So when we are at the remove stage, we
     * can just refer to this
     *
     * @see model.database.NPMDBTagElement
     *
     * @param tagElement the tag element used for this bubble
     *                   either a NPMDBLabel or NPMDBTag
     */
    public void setTagElement(NPMDBTagElement tagElement) {
        this.tagElement = tagElement;
    }

    /**
     * Get the string printed on the bubble tag
     * in the format either 'FirstName LastName'
     * or 'Label'
     *
     * @see model.search.NPMSearchManager
     *
     * @return the string on the bubble tag
     */
    public NPMTuple<String, String> getTagName(NPMSearchManager.SearchType searchType) {
        if (searchType == NPMSearchManager.SearchType.TAG_NAME) {
            String firstName = tagName.substring(0, tagName.indexOf(" "));
            String lastName = tagName.substring(tagName.indexOf(" ") + 1, tagName.length());
            return new NPMTuple<>(firstName, lastName);
        }
        return new NPMTuple<>(tagName, tagName);
    }

    /**
     * Getter method if the tag is removable by the
     * user or not
     * @return true if removable
     *         false if not
     */
    public boolean isRemovable() {
        return removable;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj.getClass() == this.getClass()) {
            return ((NPMBubbleTag)obj).tagName.equals(this.tagName);
        }
        return super.equals(obj);
    }
}
