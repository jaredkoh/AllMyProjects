package view.custom;

import controller.NPMImageCellClickHandler;
import javafx.event.EventHandler;
import javafx.scene.CacheHint;
import javafx.scene.Cursor;
import javafx.scene.effect.ColorAdjust;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import model.database.NPMDBPicture;
import view.MainView;

import java.util.TreeMap;

/**
 * A custom StackPane to display images
 *
 * @author Team 3-B
 * @version 1.0
 */
@SuppressWarnings("unchecked")
public class NPMImageCell extends StackPane {
	private static final double RATIO_3_BY_2 = 1.5;
	private static final double RATIO_4_BY_3 = 1.3333333333;

	public static final double IMAGE_WIDTH = 1080;
	public static final double IMAGE_HEIGHT = calculateHeight(RATIO_4_BY_3, IMAGE_WIDTH);
	public static final double THUMBNAIL_WIDTH = 180;
	public static final double THUMBNAIL_HEIGHT = calculateHeight(RATIO_4_BY_3, THUMBNAIL_WIDTH);
	public static final double FULL_SCREEN_WIDTH = 720;
	public static final double FULL_SCREEN_HEIGHT = calculateHeight(RATIO_4_BY_3, FULL_SCREEN_WIDTH);

	private NPMDBPicture picture;
	private Image image;
	private ImageView imageView;

	public NPMImageCell(NPMDBPicture picture) {
		this.picture = picture;

		TreeMap<String, Image> preloadedImages = MainView.getPreloadedImages();

		if (picture.getPath().getValue()) {
			if (preloadedImages.containsKey(picture.getPath().getKey())) {
				this.image = preloadedImages.get(picture.getPath().getKey());
			} else {
				this.image = new Image("file:" + picture.getPath().getKey(), THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT, true, true, true);

				if (preloadedImages.size() < MainView.PRELOADED_IMAGE_COUNT) {
					preloadedImages.put(picture.getPath().getKey(), this.image);
				}
			}
		} else {
			this.image = new Image(getClass().getResourceAsStream(picture.getPath().getKey()), THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT, false, false);
		}

		this.imageView = new ImageView(image);

        this.setPrefHeight(128);
        this.setMaxHeight(128);
        this.setMinHeight(128);
		setup();

		setOnMouseClicked(new NPMImageCellClickHandler());
	}

	private void setup() {
        imageView.setFitHeight(122);
        imageView.setSmooth(true);
        imageView.setCache(true);
        imageView.setCacheHint(CacheHint.SPEED);

		this.setCursor(Cursor.HAND);

		imageView.setOnMouseEntered(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) { imageView.setEffect(new ColorAdjust(0.0, -0.2, -0.5, 0.0)); }
		});
		imageView.setOnMouseExited(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				imageView.setEffect(null);
			}
		});

		this.getChildren().add(imageView);
        this.getStyleClass().add("selected-image-cell-transparent");
	}

	public NPMDBPicture getPicture() {
		return picture;
	}

	private static double calculateHeight(double ratio, double width) {
		return width * (1 / (ratio));
	}
}
