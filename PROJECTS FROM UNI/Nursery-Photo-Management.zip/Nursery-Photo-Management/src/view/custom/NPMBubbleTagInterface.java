package view.custom;

/**
 * Bubble tag interface
 *
 * @author Team 3-B
 * @version 1.0
 */
public interface NPMBubbleTagInterface {
    /**
     * REmove tag method to remove a tag from
     * the flow pane. Order doesn't matter, it should
     * require the tag object, that needs to be removed
     * @param tag the tag to be removed
     */
    public void removeTag(NPMBubbleTag tag);
}
