package controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;

import model.database.NPMDBPicture;

import view.MainView;
import view.custom.NPMImageCell;
import view.custom.NPMRightSideBar;

/**
 * Custom EventHandler to listen to clicks on images
 *
 * @version 1.0
 * Created by Team 3-B on 10/03/15.
 */
public class NPMImageCellClickHandler implements EventHandler {
	private BorderPane mainBorderPane;
	private StackPane centerStackPane;
	private BorderPane imageDisplay;
	private NPMRightSideBar rightSideBar;

	private int indexCell;
	private NPMDBPicture picture;
	private ImageView imageView;

	private ObservableList<NPMImageCell> pictures = MainView.getThumbnails();
	private ObservableList<NPMDBPicture> selectedImages = MainView.getSelectedImages();

	public NPMImageCellClickHandler() {}

	@Override
	public void handle(Event event) {
		MouseEvent mouseEvent = ((MouseEvent) event);

		NPMImageCell clickedCell = (NPMImageCell) mouseEvent.getSource();
		mainBorderPane = ((BorderPane) clickedCell.getScene().getRoot());
		centerStackPane = ((StackPane) mainBorderPane.getCenter());
		rightSideBar = ((NPMRightSideBar) mainBorderPane.getRight());

		NPMRightSideBar rightSideBar = ((NPMRightSideBar) mainBorderPane.getRight());

		picture = clickedCell.getPicture();
		indexCell = pictures.indexOf(clickedCell);
//		imageView = clickedCell.getImageView();

        Image checkedImage = new Image(getClass().getResourceAsStream("/view/images/icon-tick-theme-" + MainView.THEME_ID + ".png"), 25, 25, true, true);
        ImageView checkedImageView = new ImageView(checkedImage);

		if (mouseEvent.getClickCount() == 2) {
			centerStackPane.getChildren().get(0).setEffect(new GaussianBlur(10));
			centerStackPane.getChildren().add(createFullImageView());
			rightSideBar.showTaggingOptions(false, true);
		} else if (mouseEvent.getClickCount() == 1) {
			if (selectedImages.contains(picture)) {
				selectedImages.remove(picture);
				clickedCell.getStyleClass().remove("selected-image-cell");
                clickedCell.getStyleClass().add("selected-image-cell-transparent");
                if (clickedCell.getChildren().size() > 0) {
                    clickedCell.getChildren().remove(1);
                }
            } else {
				selectedImages.add(picture);
                clickedCell.getStyleClass().removeAll("selected-image-cell-transparent");
                clickedCell.getStyleClass().add("selected-image-cell");
                clickedCell.getChildren().add(checkedImageView);
                NPMImageCell.setAlignment(checkedImageView, Pos.BOTTOM_RIGHT);
			}
		}
	}

	/**
	 * Display image in big, with blurred dark background
	 *
	 * @return The pane containing the image and navigation arrows
	 */
	private BorderPane createFullImageView() {
		imageDisplay = new BorderPane();

		imageDisplay.setStyle("-fx-background-color: rgba(0, 0, 0, 0.7)");
		imageView = new ImageView();
//		imageView.setFitWidth(NPMImageCell.FULL_SCREEN_WIDTH);
//		imageView.setFitHeight(NPMImageCell.FULL_SCREEN_HEIGHT);
		imageDisplay.setCenter(imageView);
		setImage(picture);

		Button btnLeft = new Button();
        Image img_ButtonLeft = new Image(getClass().getResourceAsStream("/view/images/image-arrow-left.png"), 26, 26, false, false);
        btnLeft.setGraphic(new ImageView(img_ButtonLeft));
        btnLeft.getStyleClass().add("button-navigation");
		btnLeft.setPrefHeight(60);
		btnLeft.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				--indexCell;
				if (indexCell < 0) {
					indexCell = pictures.size() - 1;
				}
				setImage(pictures.get(indexCell).getPicture());
			}
		});

		Button btnRight = new Button();
        Image img_ButtonRight = new Image(getClass().getResourceAsStream("/view/images/image-arrow-right.png"), 26, 26, false, false);
        btnRight.setGraphic(new ImageView(img_ButtonRight));
        btnRight.getStyleClass().add("button-navigation");
		btnRight.setPrefHeight(60);
		btnRight.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				++indexCell;
				if (indexCell == pictures.size()) {
					indexCell = 0;
				}
				setImage(pictures.get(indexCell).getPicture());
			}
		});

		EventHandler<KeyEvent> keyListener = new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent event) {
				if (event.getCode() == KeyCode.LEFT) {
					--indexCell;
					if (indexCell < 0) {
						indexCell = pictures.size() - 1;
					}
					setImage(pictures.get(indexCell).getPicture());
				} else if (event.getCode() == KeyCode.RIGHT) {
					++indexCell;
					if (indexCell == pictures.size()) {
						indexCell = 0;
					}
					setImage(pictures.get(indexCell).getPicture());
				}
				event.consume();
			}
		};

		imageDisplay.addEventFilter(KeyEvent.KEY_PRESSED, keyListener);

		imageDisplay.setLeft(btnLeft);
        BorderPane.setAlignment(btnLeft, Pos.CENTER);
		imageDisplay.setRight(btnRight);
		BorderPane.setAlignment(btnRight, Pos.CENTER);

		imageDisplay.setOnMouseClicked(new EventHandler<MouseEvent>() {
			@Override
			public void handle(MouseEvent event) {
				centerStackPane.getChildren().remove(1);
				centerStackPane.getChildren().get(0).setEffect(null);
				exitFullscreen();
			}
		});

		return imageDisplay;
	}

	private void exitFullscreen() {
		if (imageDisplay.getChildren().size() > 1) {
			imageDisplay.getChildren().remove(1);
			imageDisplay.getChildren().get(0).setEffect(null);

			if (selectedImages.size() > 0) {
				rightSideBar.showTaggingOptions(true, false);
			} else {
				rightSideBar.showTaggingOptions(false, false);
			}
		}
	}

	/**
	 * Set the image of the full screen ImageView
	 *
	 * @param picture The picture database object
	 */
	private void setImage(NPMDBPicture picture) {
        Image image;
		if (picture.getPath().getValue()) {
            image = new Image("file:" + picture.getPath().getKey(), NPMImageCell.IMAGE_WIDTH, NPMImageCell.IMAGE_HEIGHT, true, true, false);
            imageView.setImage(image);
        } else {
            image = new Image(getClass().getResourceAsStream(picture.getPath().getKey()), NPMImageCell.IMAGE_WIDTH, NPMImageCell.IMAGE_HEIGHT, true, true);
            imageView.setImage(image);
        }

        if (image.getWidth() < image.getHeight()) {
            imageView.setFitHeight(NPMImageCell.FULL_SCREEN_HEIGHT);
            imageView.setPreserveRatio(true);
        } else {
            imageView.setFitWidth(NPMImageCell.FULL_SCREEN_WIDTH);
            imageView.setPreserveRatio(true);
        }
	}
}
