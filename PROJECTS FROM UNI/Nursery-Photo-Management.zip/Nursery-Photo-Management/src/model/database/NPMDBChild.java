package model.database;

import javafx.beans.property.*;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Database class for Children
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMDBChild {
	private SimpleLongProperty id;
	private SimpleStringProperty firstName, lastName, keyWorker;
	private SimpleBooleanProperty active;

    /**
     * Constructor for NPMDBChild class
     *
     * @param rs A ResultSet object returned by the SQL query
     * @throws SQLException
     */
    public NPMDBChild(ResultSet rs) throws SQLException {
        this.id = new SimpleLongProperty(rs.getInt("child_id"));
        this.firstName = new SimpleStringProperty(rs.getString("first_name"));
        this.lastName = new SimpleStringProperty(rs.getString("last_name"));
        this.keyWorker = new SimpleStringProperty(rs.getString("key_worker"));
        this.active = new SimpleBooleanProperty(rs.getBoolean("active"));

		active.addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				active.set(newValue.booleanValue());
				saveEntity();
			}
		});
    }

	/**
	 * Add a new child to the database based on the
	 * parameters the user provides in the settings panel
	 *
	 * @see model.database.NPMDBDataManager
	 *
	 * @param firstName the first name of the child
	 * @param lastName the last name of the child
	 * @param keyWorker the name of the key worker
	 * @param bool true if the child is active in the nursery
	 *                 false otherwise
	 */
	public NPMDBChild(String firstName, String lastName, String keyWorker, boolean bool) {
		this.firstName = new SimpleStringProperty(firstName);
		this.lastName = new SimpleStringProperty(lastName);
		this.keyWorker = new SimpleStringProperty(keyWorker);
		this.active = new SimpleBooleanProperty(bool);

		String sql = "INSERT INTO Child (first_name, last_name, key_worker, active) VALUES ('" +
				firstName.replaceAll("'", "''") + "', '" + lastName.replaceAll("'", "''") +"', '" +
				keyWorker.replaceAll("'", "''") + "', '" + (active.get() ? 1 : 0) + "');";

		// Returns the key (id) that was generated (by auto increment)
		this.id = new SimpleLongProperty(NPMDBDataManager.getInstance().update(sql));

		active.addListener(new ChangeListener<Boolean>() {
			@Override
			public void changed(ObservableValue<? extends Boolean> observable, Boolean oldValue, Boolean newValue) {
				active.set(newValue.booleanValue());
				saveEntity();
			}
		});
	}

	/**
	 * Save the table in the local SQL database
	 * @return Whether the update was successful
	 */
	public boolean saveEntity() {
		String sql = "UPDATE Child SET " +
				"first_name='" + firstName.get().replaceAll("'", "''") + "', " +
				"last_name='" + lastName.get().replaceAll("'", "''") + "', " +
				"key_worker='" + keyWorker.get().replaceAll("'", "''") + "', " +
				"active=" + (active.get() ? 1 : 0) + " " +
				"WHERE child_id=" + id.get() + ";";

		// Returns 0 (not the key that was generated)
		return NPMDBDataManager.getInstance().update(sql) != -1;
	}

	public long getId() {
		return id.get();
	}

	public String getFirstName() {
		return firstName.get();
	}

	public String getLastName() {
		return lastName.get();
	}

	public String getKeyWorker() {
		return keyWorker.get();
	}

	public boolean isActive() {
		return active.get();
	}

	public SimpleStringProperty firstNameProperty() {
		return firstName;
	}

	public SimpleStringProperty lastNameProperty() {
		return lastName;
	}

	public SimpleStringProperty keyWorkerProperty() {
		return keyWorker;
	}

	public SimpleBooleanProperty activeProperty() {
		return active;
	}

	public void setFirstName(String firstName) {
		this.firstName.set(firstName);
		saveEntity();
	}

	public void setLastName(String lastName) {
		this.lastName.set(lastName);
		saveEntity();
	}

	public void setKeyWorker(String keyWorker) {
		this.keyWorker.set(keyWorker);
		saveEntity();
	}

	public void setActive(boolean active) {
		this.active.set(active);
		saveEntity();
	}

	@Override
	public String toString() {
		return id.get() + "," + firstName.get() + "," + lastName.get() + "," + keyWorker.get() + "," + active.get();
	}
}
