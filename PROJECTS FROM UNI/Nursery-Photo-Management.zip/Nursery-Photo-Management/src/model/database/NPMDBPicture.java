package model.database;

import model.NPMTuple;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Database class for Pictures
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMDBPicture {
	public long id;
	public Date date;
	private String path;
	public String comment;
	public NPMDBRoom room;

	/**
	 * Constructor for NPMDBPicture class
	 *
	 * @param rs A ResultSet object returned by the SQL query
	 * @throws SQLException
	 */
	public NPMDBPicture(ResultSet rs) throws SQLException, ParseException {
		this.id = rs.getInt("picture_id");
		this.room = new NPMDBRoom(rs.getLong("room_id"));
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		this.date = df.parse(String.valueOf(rs.getInt("date")));
		this.path = rs.getString("path");
		this.comment = rs.getString("comment");
	}

	public NPMDBPicture(String path) {
		this.id = 0;
		this.room = new NPMDBRoom(1);
		this.date = new Date();
		this.path = path;
		this.comment = "Test Constructor";
	}

	/**
	 * Save the table in the local SQL database
	 * @return Whether the update was successful
	 */
	public boolean saveEntity() {
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		String commentSQL = comment != null ? ", comment='" + comment.replaceAll("'", "''") + "' " : " ";

		String sql = "UPDATE Picture SET " +
				"room_id=" + room.id + ", " +
				"date=" + Integer.valueOf(df.format(date)) + ", " +
				"path='" + path.replaceAll("'", "''") + "'" + commentSQL +
				"WHERE picture_id=" + id + ";";

		return NPMDBDataManager.getInstance().update(sql) != -1;
	}

	/**
	 * Get the name of the file with a regular expression
	 * @return The name of the file without the extension
	 */
	public String getFileName() {
		String osName = System.getProperty("os.name");
		String separator;

		if (osName.substring(0, osName.indexOf(" ")).equalsIgnoreCase("windows")) {
			separator = "\\\\";
		} else {
			separator = "/";
		}

		String withExtension = path.replaceFirst(".+" + separator, "");
		return withExtension.substring(0, withExtension.lastIndexOf('.'));
	}

	/**
	 * Get the extension of the file with a regular expression
	 * @return The extension of the file
	 */
	public String getFileExtension() {
		return path.replaceFirst(".+\\.", "");
	}

	/**
	 * Getter method for the file path. Return the
	 * image path if exists.
	 * @return  <the original image path if exists, true>
	 * 			<the default image path if not, false>
	 */
	public NPMTuple<String, Boolean> getPath() {
		if (new File (path).exists())
			return new NPMTuple<>(path, true);

		return new NPMTuple<>("/view/images/image-not-found.png", false);
	}

	@Override
	public String toString() {
		return id + "," + path + "," + room.id + "," + date + "," + comment;
	}

	@Override
	public boolean equals(Object obj) {
		return path.equals(((NPMDBPicture) obj).path);
	}
}
