package model.database;

import com.drew.imaging.ImageMetadataReader;
import com.drew.imaging.ImageProcessingException;
import com.drew.metadata.Metadata;
import com.drew.metadata.exif.ExifSubIFDDirectory;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Class for managing the database, query and update operations
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMDBDataManager {
    private static NPMDBDataManager dataManagerInstance;

	/**
     * Getting the instance of the class
     * based on the Singleton design pattern
     *
     * @return the instance of this class
     */
    public static NPMDBDataManager getInstance() {
        if (dataManagerInstance == null) {
            createTables();
            dataManagerInstance = new NPMDBDataManager();
        }


        return dataManagerInstance;
    }

    /**
     * Make database connection
     * and return the connection instance for creating tables,
     * querying or updating data
     */
    private static Connection connect() {
        Connection connection = null;
        try {
            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection("jdbc:sqlite:nursery.db");
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
        return connection;
    }

    /**
     * Upload image data to database from a given path
     *
     * @param folder The File object that points to the folder containing the images
     * @return The list of files (and directories)
     */
    public int importImages(File folder) {
        File[] filesInFolder;

        // Number of images imported
        int imageCount = 0;

        if (folder.isDirectory())
            filesInFolder = folder.listFiles();
        else {
            System.err.println("Target is not a directory!");
            return 0;
        }

        if (filesInFolder.length > 0) {
            Connection connection = connect();

            BasicFileAttributes bfa;
            Date date = null;
            String sql = "";
            String extension;

			int duplicate = 0;

            for (File f : filesInFolder) {
				duplicate = dataManagerInstance.query("SELECT * FROM Picture WHERE path='" + f.getPath().replaceAll("'", "''") + "'", "Picture").size();

				if (duplicate == 0) {
					// Recursively import images from sub-folders
					if (f.isDirectory())
						importImages(f);
					else {
						extension = f.getPath().substring(f.getPath().lastIndexOf(".") + 1).toUpperCase();

						if (extension.equals("JPG") || extension.equals("JPEG") || extension.equals("PNG") || extension.equals("GIF")) {
                            try {
                                Metadata metadata = ImageMetadataReader.readMetadata(f);
                                ExifSubIFDDirectory directory =
                                        metadata.getDirectory(ExifSubIFDDirectory.class);

                                if (directory != null) {
                                    date = directory.getDate(ExifSubIFDDirectory.TAG_DATETIME_ORIGINAL);
                                    if (date == null || !(Integer.parseInt(date.toInstant().toString().substring(0,4)) > 1970)) {
                                        bfa = Files.getFileAttributeView(Paths.get(f.getPath()), BasicFileAttributeView.class).readAttributes();
                                        date = new Date(bfa.creationTime().toMillis());
                                    }
                                } else {
                                    bfa = Files.getFileAttributeView(Paths.get(f.getPath()), BasicFileAttributeView.class).readAttributes();
                                    date = new Date(bfa.creationTime().toMillis());
                                }
                            } catch (IOException | ImageProcessingException e) {
                                System.err.println(e.getClass().getName() + ": " + e.getMessage());
                            }

							DateFormat df = new SimpleDateFormat("yyyyMMdd");

                            sql += "INSERT INTO Picture (path, room_id, date) VALUES ";
                            sql += "('" + f.getPath().replaceAll("'", "''") + "', " + 1 + ", " + Integer.valueOf(df.format(date)) + ");\n";

							imageCount++;
						}
					}
				}
            }

            try {
                Statement statement = connection.createStatement();
                statement.executeUpdate(sql);
            } catch (Exception e) {
                System.err.println(e.getClass().getName() + ": " + e.getMessage());
            }
            return imageCount;
        } else {
            System.err.println("Specified folder is empty");
            return 0;
        }
    }

    /**
     * Make a query and get data from database
     * based on the SQL command
     *
     * @param sql The SQL query to be executed
     * @param className Short name of a table
     * @return ArrayList of className objects that the query returned or null
     */
    public ArrayList query(String sql, String className) {
        // Get the connection
        Connection connection = connect();

        // Capitalise first letter
        className = className.substring(0, 1).toUpperCase() + className.substring(1).toLowerCase();

        // If the parameter is invalid, return null
        if (!(className.equals("Child") || className.equals("Label") || className.equals("Picture") || className.equals("Tag") || className.equals("Room")))
            return null;

        Class dbClass = null;
        try {
            // Create the appropriate class with the assembled class name
            dbClass = Class.forName("model.database.NPMDB" + className);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        ArrayList<Object> alResults = new ArrayList<>();

        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sql + ";");
            while (rs.next()) {
                // Initialise a new class for every row in database
                if (dbClass != null) {
                    alResults.add(dbClass.getConstructor(ResultSet.class).newInstance(rs));
                }
            }


            rs.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            e.printStackTrace();
        }

        return alResults;
    }

    /**
     * Make a query and get a single integer from
     * the database. This method is mainly for querying
     * settings and return a single integer
     *
     * @param sql The SQL query to be executed
     * @return integer, the value in the table
     */
    public int queryInteger(String sql, String columnName) {
        // Get the connection
        Connection connection = connect();

        // Capitalise first letter
        columnName = columnName.substring(0, 1).toUpperCase() + columnName.substring(1).toLowerCase();

        int toReturn = 1;
        try {
            Statement statement = connection.createStatement();
            ResultSet rs = statement.executeQuery(sql + ";");
            toReturn = rs.getInt(columnName);
            rs.close();
            statement.close();
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
            e.printStackTrace();
        }

        return toReturn;
    }

    /**
     * Execute an update method on the local database
     *
     * @return true if it succeeded, false otherwise
     */
    public long update(String sql) {
        Connection connection = connect();
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(sql,
                    Statement.RETURN_GENERATED_KEYS);
            preparedStatement.executeUpdate();
            ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getLong(1);
            }
            preparedStatement.close();
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
        return -1;
    }

    /**
     * Import data from CSV file
	 *
     * @param folder File path
     */
    public void importData(File folder) throws IOException, SQLException {

        try {
			for (File file : folder.listFiles()) {
				if (file.getAbsolutePath().toLowerCase().contains(".csv")) {
					importingFile(file);
				}
			}
        } catch(Exception e){
			e.printStackTrace();
        }
    }

    /**
     * Exporting data to CSV to desired location
	 *
     * @param folder File path
     */
    public void exportData(File folder, boolean zip) {

		ArrayList child_data = query("SELECT * FROM CHILD", "Child");
        child_data = query("SELECT * FROM CHILD", "Child");
		ArrayList child_tag_picture_data = query("SELECT * FROM Child_Tag_Picture", "Tag");
		ArrayList picture_data = query("SELECT * FROM Picture", "Picture");
		ArrayList picture_label_data = query("SELECT * FROM Picture_Label", "Label");
		ArrayList picture_room_data = query("SELECT * FROM Picture_Room", "Room");

		FileWriter writer;
		File[] exportFiles = new File[5];

        try {
            exportFiles[0] = new File(folder + "/Child.csv");
            writer = new FileWriter(exportFiles[0], false);
            writer.append("child_id, first_name, last_name, key_worker, active"+ '\n');
			for (Object data : child_data) {
				NPMDBChild child = (NPMDBChild) data;
				writer.append(child.toString());
				writer.append('\n');
			}
            writer.flush();
            writer.close();

			exportFiles[1] = new File(folder + "/ChildTagPicture.csv");
            writer = new FileWriter(exportFiles[1], false);
            writer.append("tag_id, child_id, picture_id" + '\n');
			for (Object data : child_tag_picture_data) {
				NPMDBTag tag = (NPMDBTag) data;
				writer.append(tag.toString());
				writer.append('\n');
			}
            writer.flush();
            writer.close();

			exportFiles[2] = new File(folder + "/Picture.csv");
            writer = new FileWriter(exportFiles[2], false);
            writer.append("picture_id , path , room_id , date , comment" + '\n');
			for (Object data : picture_data) {
				NPMDBPicture picture = (NPMDBPicture) data;
				writer.append(picture.toString());
				writer.append('\n');

			}
            writer.flush();
            writer.close();

			exportFiles[3] = new File(folder + "/PictureLabel.csv");
            writer = new FileWriter(exportFiles[3], false);
            writer.append("label_id , label_name , picture_id" + '\n');
			for (Object data : picture_label_data) {
				NPMDBLabel label = (NPMDBLabel) data;
				writer.append(label.toString());
				writer.append('\n');
			}
            writer.flush();
            writer.close();

			exportFiles[4] = new File(folder + "/PictureRoom.csv");
            writer = new FileWriter(exportFiles[4], false);
            writer.append("room_id , room_name" + '\n');
			for (Object data : picture_room_data) {
				NPMDBRoom room = (NPMDBRoom) data;
				writer.append(room.toString());
				writer.append("\n");
			}
            writer.flush();
            writer.close();

			if (zip) {
				FileOutputStream fileOutputStream = new FileOutputStream(folder + "/csv_export.zip");
				ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);

				for (File file : exportFiles) {
					addFileToZip(file, zipOutputStream);
				}

				zipOutputStream.close();
				fileOutputStream.close();
			}
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

	private void addFileToZip(File file, ZipOutputStream out) throws IOException {
		FileInputStream in = new FileInputStream(file);
		ZipEntry zipEntry = new ZipEntry(file.getName());

		out.putNextEntry(zipEntry);

		byte[] bytes = new byte[1048576];
		int length;
		while ((length = in.read(bytes)) >= 0) {
			out.write(bytes, 0, length);
		}

		out.closeEntry();
		in.close();
	}

    private void importingFile(File fileName) throws FileNotFoundException {
        Connection connection = connect();

        PreparedStatement stmt;
        String query = null;
        BufferedReader br = new BufferedReader(new FileReader(fileName));
        String line;
        try {
            line = br.readLine();
            String[] values = line.split(",");

            if (values[0].contains("child_id")) {
                while ((line = br.readLine()) != null) {
                     values = line.split(","); // Separates by the , generated by csv
                        query = "REPLACE INTO Child VALUES('" + values[0] + "','" + values[1] + "' , '" + values[2] + "','" + values[3] + "','" + values[4] + "')";
                    stmt = connection.prepareStatement(query);
                    stmt.executeUpdate();
                }
            } else if (values[0].contains("tag_id")) {
                while ((line = br.readLine()) != null) {
                     values = line.split(","); // Separates by the , generated by csv
                        query = "REPLACE INTO Child_Tag_Picture VALUES('" + values[0] + "','" + values[1] + "' , '" + values[2] + "')";
                    stmt = connection.prepareStatement(query);
                    stmt.executeUpdate();

                }
            } else if (values[0].contains("picture_id")) {

                while ((line = br.readLine()) != null) {
                     values = line.split(","); // Separates by the , generated by csv
                        query = "REPLACE INTO Picture VALUES('" + values[0] + "','" + values[1] + "' , '" + values[2] + "','" + values[3] + "','" + values[4] + "')";
                    stmt = connection.prepareStatement(query);
                    stmt.executeUpdate();
                }
            } else if (values[0].contains("label_id")) {

                while ((line = br.readLine()) != null) {
                     values = line.split(","); // Separates by the , generated by csv
                        query = "REPLACE INTO Picture_Label VALUES('" + values[0] + "','" + values[1] + "' , '" + values[2] + "')";
                    stmt = connection.prepareStatement(query);
                    stmt.executeUpdate();

                }
            } else if (values[0].contains("room_id")) {
                while ((line = br.readLine()) != null) {
                     values = line.split(","); // Separates by the , generated by csv
                        query = "REPLACE INTO Picture_Room VALUES('" + values[0] + "','" + values[1] + "')";
                    stmt = connection.prepareStatement(query);
                    stmt.executeUpdate();

                }
            }
            br.close();


        } catch (Exception e) {
            e.printStackTrace();
            stmt = null;
        }

    }

    /*
     * Create tables in the database if necessary
     * from the sql file then close the connection
     */
    private static void createTables() {
        if (new File ("nursery.db").exists()) return;

        Connection connection = connect();
        Statement statement = null;
        try {
            statement = connection.createStatement();
            String sql = new Scanner(new File("nursery.sql")).useDelimiter("\\Z").next();
            statement.executeUpdate(sql);
            statement.close();
            connection.close();
        } catch (Exception e) {
            System.err.println(e.getClass().getName() + ": " + e.getMessage());
        }
    }
}
