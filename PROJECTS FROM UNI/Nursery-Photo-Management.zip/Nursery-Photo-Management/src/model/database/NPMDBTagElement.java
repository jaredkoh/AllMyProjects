package model.database;

import model.NPMTuple;

/**
 * Tag Element
 *
 * @author Team 3-B
 * @version 1.0
 */
public interface NPMDBTagElement {

    /**
     * This is an interface method for the Tag element, implemented
     * in NPMDBTag and NPMDBLabel classes.
     *
     * The method should return the readable name of the tag/label, that
     * can be used as a label on the bubble tag widget
     *
     * @see model.database.NPMDBTag
     * @see model.database.NPMDBLabel
     * @see view.custom.NPMBubbleTag
     *
     * @return the readable name in the format of a tuple
     */
    public String getReadableName();

    /**
     * This is an interface method for the Tag element, implemented
     * in NPMDBTag and NPMDBLabel classes.
     *
     * The method should return the readable name of the tag/label, that
     * can be used as a label on the bubble tag widget in a format
     * of a tuple. In the case of a name it's <FirstName, LastName>.
     * If it's a label it's <LabelName, LabelName>
     *
     * @see model.database.NPMDBTag
     * @see model.database.NPMDBLabel
     * @see view.custom.NPMBubbleTag
     * @see model.NPMTuple
     *
     * @return the readable name in the format of a tuple
     */
    public NPMTuple<String, String> getTupleName();

    /**
     * This is an interface method to return the tag or
     * label identifier for further identification as it is possible
     * that an image has more than one tag or label. In that particular
     * case we need the tag/label id too
     *
     * @see model.database.NPMDBTag
     * @see model.database.NPMDBLabel
     *
     * @return the id of the tagElement
     */
    public String getID();
}
