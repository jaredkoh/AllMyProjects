package model.database;

import model.NPMTuple;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Database class for Labels
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMDBLabel implements NPMDBTagElement {
	private long id;
	private String labelName;
	public NPMDBPicture picture;

	/**
	 * Constructor for NPMDBLabel class
	 *
	 * @param rs A ResultSet object returned by the SQL query
	 * @throws java.sql.SQLException
	 */
	public NPMDBLabel(ResultSet rs) throws SQLException {
		this.id = rs.getInt("label_id");
		this.labelName = rs.getString("label_name");
		this.picture = (NPMDBPicture) NPMDBDataManager.getInstance().query("SELECT * FROM Picture WHERE picture_id=" + rs.getInt("picture_id"), "Picture").get(0);
	}

	/**
	 * Constructor for NPMDBLabel class, based on the given
	 * child and picture parameter
	 *
	 * @param labelName label name we using for the picture
	 * @param picture the labeled picture
	 */
	public NPMDBLabel(String labelName, NPMDBPicture picture) {
		this.labelName = labelName;
		this.picture = picture;

		labelName = labelName.replaceAll("'", "''");
		String sql = "INSERT INTO Picture_Label (label_name, picture_id) VALUES ('" + labelName + "', " + picture.id +");";
		this.id = NPMDBDataManager.getInstance().update(sql);
	}

	/**
	 * This is an interface method that should define the implementation
	 * for the Tag database files how to save a new entity
	 *
	 * It needs to create a Update SQL query and save the data in the database
	 *
	 * @see model.database.NPMDBTag
	 * @see model.database.NPMDBLabel
	 *
	 * @return true if it is success
	 *         false if it failed
	 */
	public boolean saveEntity() {
		String sql = "UPDATE Picture_Label SET label_id=" + id + ", label_name='" + labelName.replaceAll("'", "''") + "', picture_id=" + picture.id +
				" WHERE label_id=" + id + ";";

		return NPMDBDataManager.getInstance().update(sql) != -1;
	}

	/**
	 * Overridden method from NPMDBTagElement
	 * to return the readable name of a label
	 * @return  the label name in the format of
	 * 			'LabelName'
	 */
	@Override
	public String getReadableName() {
		return labelName;
	}

	/**
	 * Overridden method from NPMDBTagElement
	 * to return the readable name of a label
	 * @return  the label name in the format of
	 * 			<LabelName, LabelName>
	 */
	@Override
	public NPMTuple<String, String> getTupleName() {
		return new NPMTuple<>(labelName, labelName);
	}

	/**
	 * Overridden method from NPMDBTagElement
	 * to return the id of the label
	 * @return the id as a string
	 */
	@Override
	public String getID() {
		return String.valueOf(id);
	}

    public String toString(){
        return id + "," + labelName + "," + picture.id;
    }
}
