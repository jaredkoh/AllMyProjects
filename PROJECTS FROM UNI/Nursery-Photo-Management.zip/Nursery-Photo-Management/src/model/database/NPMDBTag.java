package model.database;

import model.NPMTuple;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Database class for Tags
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMDBTag implements NPMDBTagElement {
	private long id;
	public NPMDBChild child;
	public NPMDBPicture picture;

	/**
	 * Constructor for NPMDBTag class
	 *
	 * @param rs A ResultSet object returned by the SQL query
	 * @throws java.sql.SQLException
	 */
	public NPMDBTag(ResultSet rs) throws SQLException {
		this.id = rs.getInt("tag_id");
		this.child = (NPMDBChild) NPMDBDataManager.getInstance().query(
				"SELECT * FROM Child WHERE child_id=" + rs.getInt("child_id"), "Child").get(0);
		this.picture = (NPMDBPicture) NPMDBDataManager.getInstance().query(
				"SELECT * FROM Picture WHERE picture_id=" + rs.getInt("picture_id"), "Picture").get(0);
	}

	/**
	 * Constructor for NPMDBTag class, based on the given
	 * child and picture parameter
	 *
	 * @param child the child tagged on the picture
	 * @param picture the tagged picture
	 */
	public NPMDBTag(NPMDBChild child, NPMDBPicture picture) {
		String sql = "INSERT INTO Child_Tag_Picture (child_id, picture_id) VALUES (" + child.getId() + ", " + picture.id +");";
		this.id = NPMDBDataManager.getInstance().update(sql);
		this.child = child;
		this.picture = picture;
	}

	/**
	 * This is an interface method that should define the implementation
	 * for the Tag database files how to save a new entity
	 *
	 * It needs to create a Update SQL query and save the data in the database
	 *
	 * @see model.database.NPMDBTag
	 * @see model.database.NPMDBLabel
	 *
	 * @return true if it is success
	 *         false if it failed
	 */
	public boolean saveEntity() {
		String sql = "UPDATE Child_Tag_Picture SET tag_id=" + id + ", child_id=" + child.getId() + ", picture_id=" + picture.id +
				" WHERE tag_id=" + id + ";";

		return NPMDBDataManager.getInstance().update(sql) != -1;
	}

	/**
	 * Overridden method from NPMDBTagElement
	 * to return the readable name of a tag
	 * @return  the tagged child first and last name
	 * 			in the format of 'FirstName  LastName'
	 */
	@Override
	public String getReadableName() {
		return child.getFirstName() + " " + child.getLastName();
	}

	/**
	 * Overridden method from NPMDBTagElement
	 * to return the readable name of a tag
	 * @return  the tagged child first and last name
	 * 			in the format of Tuple<FirstName, LastName>
	 */
	@Override
	public NPMTuple<String, String> getTupleName() {
		return new NPMTuple<>(child.getFirstName(), child.getLastName());
	}

	/**
	 * Overridden method from NPMDBTagElement
	 * to return the id of the tag
	 * @return the id as a string
	 */
	@Override
	public String getID() {
		return String.valueOf(id);
	}

	@Override
	public String toString() {
		return id + "," + child.getId() + "," + picture.id;
	}
}
