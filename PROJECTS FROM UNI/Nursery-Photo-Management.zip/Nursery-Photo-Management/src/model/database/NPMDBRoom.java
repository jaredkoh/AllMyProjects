package model.database;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Database file for Rooms
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMDBRoom {
    public long id;
    public String roomName;

    /**
     * Constructor for NPMDBPicture class
     *
     * @param rs A ResultSet object returned by the SQL query
     * @throws java.sql.SQLException
     */
    public NPMDBRoom(ResultSet rs) throws SQLException {
        this.id = rs.getInt("room_id");
        this.roomName = rs.getString("room_name");
    }

    /**
     * DOES NOT INSERT INTO THE DATABASE
     * Constructor of the database room class
     * It returns a new instance of the class
     * based on the id of the room
     *
     * @see model.database.NPMDBRoom
     */
    public NPMDBRoom(long id) {
        NPMDBRoom r = (NPMDBRoom) NPMDBDataManager.getInstance().query(
                "SELECT * FROM Picture_Room WHERE room_id=" + id, "Room").get(0);
        this.id = r.id;
        this.roomName = r.roomName;
    }

    /**
     * CREATES A NEW ENTITY IN THE DATABASE
     * Constructor of the database room class.
     * It creates a new room and saves it into the database
     *
     * @see model.database.NPMDBDataManager
     *
     * @param roomName the name of the new room
     */
    public NPMDBRoom(String roomName) {
        this.roomName = roomName;
        roomName = roomName.replaceAll("'", "''");
        String sql = "INSERT INTO Picture_Room (room_name) VALUES ('" + roomName + "')";
        this.id = NPMDBDataManager.getInstance().update(sql);
    }

    /**
     * Remove the room that we calling
     * this method from
     *
     * @see model.database.NPMDBDataManager
     *
     */
    public boolean removeEntity() {
        String sql = "DELETE FROM Picture_Room WHERE room_id=" + id;
        this.id = NPMDBDataManager.getInstance().update(sql);
        if (this.id != -1) return true;
        return false;
    }

    public String toString(){
        return id + "," + roomName;
    }
}
