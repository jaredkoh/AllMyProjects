package model;

/**
 * Custom NPM Tuple class for storing two values in a data structures
 * For example storing the first name and last name separately.
 *
 * @see view.custom.NPMBubbleTag
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMTuple<K,V> {
    private K key;
    private V value;

    /**
     * The constructor to create a key value
     * tuple pair
     * @param key the key of the tuple of type K
     * @param value the value of the tuple of the type V
     */
    public NPMTuple(K key, V value) {
        this.key = key;
        this.value = value;
    }

    /**
     * Get the key of the tuple in O(1).
     * @return the key of the tuple of the type K
     */
    public K getKey() {
        return key;
    }

    /**
     * Get the value of the tuple in O(1).
     * @return the value of the tuple of the type V
     */
    public V getValue() {
        return value;
    }
}
