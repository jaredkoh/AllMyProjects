package model.search;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.ComboBox;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;

import java.util.HashMap;

/**
 * Custom listener for ComboBoxes
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMComboBoxListener<T> implements EventHandler<KeyEvent> {
    private ComboBox comboBox;

    private NPMSearchManager.SearchType searchType;
    private NPMSearchManager searchManager = NPMSearchManager.getInstance();
    public NPMSearchListener searchDelegate;

    private boolean moveCaretToPos = false;
    private int caretPos;

    public NPMComboBoxListener(final ComboBox comboBox, NPMSearchManager.SearchType searchType) {
        this.comboBox = comboBox;
        this.searchType = searchType;
        this.comboBox.setEditable(true);
        this.comboBox.setOnKeyPressed(new EventHandler<KeyEvent>() {

            @Override
            public void handle(KeyEvent t) {
                comboBox.hide();
            }
        });
    }

    @Override
    public void handle(KeyEvent event) {

        if (event.getCode() == KeyCode.UP) {
            caretPos = -1;
            moveCaret(comboBox.getEditor().getText().length());
            return;
        } else if (event.getCode() == KeyCode.DOWN) {
            if (!comboBox.isShowing()) {
                comboBox.show();
            }
            caretPos = -1;
            moveCaret(comboBox.getEditor().getText().length());
            return;
        } else if (event.getCode() == KeyCode.BACK_SPACE) {
            moveCaretToPos = true;
            caretPos = comboBox.getEditor().getCaretPosition();
        } else if (event.getCode() == KeyCode.DELETE) {
            moveCaretToPos = true;
            caretPos = comboBox.getEditor().getCaretPosition();
        }

        if (event.getCode() == KeyCode.RIGHT || event.getCode() == KeyCode.LEFT
                || event.isControlDown() || event.getCode() == KeyCode.HOME
                || event.getCode() == KeyCode.END || event.getCode() == KeyCode.TAB) {
            return;
        }

        ObservableList list = FXCollections.observableArrayList();
        // start searching on the database
        String searchText = comboBox.getEditor().getText();

        if (!searchText.isEmpty()) {
            HashMap<String, NPMSearchResult> possibleSearchResults;
            switch (searchType) {
                case TAG_NAME:
                    possibleSearchResults = searchManager.search(searchText, searchType);
                    break;
                case LABEL_EVENT:
                    possibleSearchResults = searchManager.search(searchText, searchType);
                    break;
                default:
                    possibleSearchResults = searchManager.search(searchText, null);
                    break;
            }

            searchDelegate.notify(possibleSearchResults);

            if (searchType == NPMSearchManager.SearchType.LABEL_EVENT) {
                for (NPMSearchResult results : possibleSearchResults.values()) {
                    list.add(results.getQueryKeyword());
                }
            } else {
                for (String results : possibleSearchResults.keySet()) {
                    list.add(results);
                }
            }
        }

        comboBox.setItems(list);
        comboBox.getEditor().setText(searchText);
        if (!moveCaretToPos) {
            caretPos = -1;
        }
        moveCaret(searchText.length());
        if (!list.isEmpty()) {
            comboBox.show();
        }
    }

    private void moveCaret(int textLength) {
        if (caretPos == -1) {
            comboBox.getEditor().positionCaret(textLength);
        } else {
            comboBox.getEditor().positionCaret(caretPos);
        }
        moveCaretToPos = false;
    }
}