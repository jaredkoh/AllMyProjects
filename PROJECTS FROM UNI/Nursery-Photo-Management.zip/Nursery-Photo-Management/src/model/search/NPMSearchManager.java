package model.search;

import model.database.NPMDBChild;
import model.database.NPMDBDataManager;
import model.database.NPMDBLabel;
import model.database.NPMDBPicture;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

/**
 * Search manager for staring a new search with a keyword
 * (new keyword every time the user enters something to the TextField)
 * @author Team-3B (h4x0rz)
 * @version 1.0
 */
public class NPMSearchManager {
    private static NPMSearchManager searchManagerInstance;
    private static NPMDBDataManager dataManager;
    private String keyword;
    private SearchType searchType;

    /**
     * The type of the search request the user asked for
     */
    public enum SearchType {
        ALL,
        TAG_NAME, TAG_WORKER, TAG_ACTIVE,
        PICTURE_ROOM, PICTURE_DATE, PICTURE_COMMENT,
        LABEL_EVENT
    }

    /**
     * Constructor of the Search class, which creates a database
     * manager instance
     */
    private NPMSearchManager() {
        dataManager = NPMDBDataManager.getInstance();
    }

    /**
     * Getting the instance of the class
     * based on the Singleton design pattern
     * @return the instance of this class
     */
    public static NPMSearchManager getInstance() {
        if (searchManagerInstance == null) {
            searchManagerInstance = new NPMSearchManager();
        }
        return searchManagerInstance;
    }

    /**
     * Start a search based on a keyword entered by the user
     * @param keyword the search keyword
     * @param searchType TAG_NAME - if only name searching needed, such as tagging
     *                   LABEL_EVENT - if we tagging a label/event, show hint for user
     *                   NULL - if user search for everything (search textfield)
     * @return the possible search results
     */
    @SuppressWarnings("unchecked")
    public HashMap search(String keyword, SearchType searchType) {
        this.keyword = keyword;
        this.searchType = searchType;

        HashMap<String,NPMSearchResult> finalPossibleSearchResults = new HashMap<>();

        if (searchType == SearchType.TAG_NAME)
            finalPossibleSearchResults.putAll(searchChildTable());
        else if (searchType == SearchType.LABEL_EVENT)
            finalPossibleSearchResults.putAll(searchLabelTable());
        else {
            finalPossibleSearchResults.putAll(searchChildTable());
            finalPossibleSearchResults.putAll(searchPictureTable());
            finalPossibleSearchResults.putAll(searchLabelTable());
        }

        return finalPossibleSearchResults;
    }

    /**
     * Get the images based on the search result
     * @param searchResult the class represents the chosen search result
     * @return the chosen result option pictures
     */
    @SuppressWarnings("unchecked")
    public ArrayList<NPMDBPicture> getSearchResult(NPMSearchResult searchResult) {
        String sql = "";

        switch (searchResult.getSearchType()) {
            case TAG_NAME:
                String name = searchResult.getQueryKeyword();
                String firstName = name.substring(0, name.indexOf(" "));
                String lastName = name.substring(name.indexOf(" ") + 1, name.length());
                sql = "SELECT * FROM Child NATURAL JOIN Child_Tag_Picture NATURAL JOIN Picture WHERE first_name LIKE '" + firstName + "' AND last_name LIKE '" + lastName +"'";
                break;
            case TAG_WORKER:
                sql = "SELECT * FROM Picture NATURAL JOIN Child_Tag_Picture NATURAL JOIN Child WHERE key_worker='" + searchResult.getQueryKeyword() + "'";
                break;
            case TAG_ACTIVE:
                sql = "SELECT * FROM Picture NATURAL JOIN Child_Tag_Picture NATURAL JOIN Child WHERE active=1";
                break;
            case PICTURE_ROOM:
                sql = "SELECT * FROM Picture WHERE room_id=" + searchResult.getQueryKeyword();
                break;
            case PICTURE_COMMENT:
                sql = "SELECT * FROM Picture WHERE comment='" + searchResult.getQueryKeyword() + "'";
                break;
            case PICTURE_DATE:
                sql = "SELECT * FROM Picture WHERE date=" + searchResult.getQueryKeyword();
                break;
            case LABEL_EVENT:
                sql = "SELECT * FROM Picture NATURAL JOIN Picture_Label WHERE label_name='" + searchResult.getQueryKeyword() + "'";
                break;
        }

        return dataManager.query(sql, "Picture");
    }

    @SuppressWarnings("unchecked")
    private HashMap searchChildTable() {
        // Getting all information which is related to a child
        String keyword = this.keyword.replaceAll("'", "''");
        String sql = "SELECT * FROM Child WHERE first_name LIKE '%" + keyword + "%' OR last_name LIKE '%" + keyword + "%' OR key_worker LIKE '%" + keyword + "%'";
        ArrayList<NPMDBChild> children = dataManager.query(sql, "Child");

        // return search options
        HashMap<String, NPMSearchResult> possibleSearchResults = new HashMap<>();
        for (NPMDBChild ch : children) {
            if (ch.getFirstName().toLowerCase().contains(keyword.toLowerCase()) || ch.getLastName().toLowerCase().contains(keyword.toLowerCase())) {
                NPMSearchResult result = new NPMSearchResult(ch.getFirstName() + " " + ch.getLastName(),ch.getFirstName() + " " + ch.getLastName(),SearchType.TAG_NAME);
                possibleSearchResults.put(result.getReadableName(),result);
            }

            if (ch.getKeyWorker().toLowerCase().contains(keyword.toLowerCase())) {
                NPMSearchResult result = new NPMSearchResult(ch.getKeyWorker(), ch.getKeyWorker(), SearchType.TAG_WORKER);
                possibleSearchResults.put(result.getReadableName(), result);
            }

        }
        if ("active".contains(keyword.toLowerCase()) && searchType != SearchType.TAG_NAME) {
            NPMSearchResult result = new NPMSearchResult("All active children", "1", SearchType.TAG_ACTIVE);
            possibleSearchResults.put(result.getReadableName(), result);
        }

        return possibleSearchResults;
    }

    @SuppressWarnings("unchecked")
    private HashMap searchPictureTable() {
        // Getting all the information related to the pictures
        String sql = "SELECT * FROM Picture";
        ArrayList<NPMDBPicture> pictures = dataManager.query(sql, "Picture");

        // return search options
        HashMap<String, NPMSearchResult> possibleSearchResults = new HashMap<>();

        for (NPMDBPicture pic : pictures) {
            if (pic.room.roomName.toLowerCase().contains(keyword.toLowerCase())) {
                NPMSearchResult result = new NPMSearchResult("All pictures in '" + pic.room.roomName + "'", String.valueOf(pic.room.id), SearchType.PICTURE_ROOM);
                possibleSearchResults.put(result.getReadableName(), result);
            }

            if (pic.comment != null && pic.comment.toLowerCase().contains(keyword.toLowerCase())) {
                NPMSearchResult result = new NPMSearchResult(pic.comment, pic.comment, SearchType.PICTURE_COMMENT);
                possibleSearchResults.put(result.getReadableName(), result);
            }

            Calendar calendar = Calendar.getInstance();
            DateFormat df = new SimpleDateFormat("yyyyMMdd");
            calendar.setTime(pic.date);
            String year = String.valueOf(calendar.get(Calendar.YEAR));
            String day = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
            String month = new SimpleDateFormat("MMMM").format(calendar.getTime());

            int monthValue = calendar.get(Calendar.MONTH) + 1;

            if (day.contains(keyword.toLowerCase()) || month.toLowerCase().contains(keyword.toLowerCase()) || year.toLowerCase().contains(keyword.toLowerCase())
                    || String.valueOf(monthValue).equals(keyword.toLowerCase())) {
                NPMSearchResult result = new NPMSearchResult("All pictures on '" + day + " " + month + ", " + year + "'", "" + Integer.valueOf(df.format(pic.date)), SearchType.PICTURE_DATE);
                possibleSearchResults.put(result.getReadableName(), result);
            }

        }

        return possibleSearchResults;
    }

    @SuppressWarnings("unchecked")
    private HashMap searchLabelTable() {
        // Getting all the information relevant to a label
        String keyword = this.keyword.replaceAll("'", "''");
        String sql = "SELECT * FROM Picture_Label WHERE label_name LIKE '%" + keyword + "%'";
        ArrayList<NPMDBLabel> labels = dataManager.query(sql, "Label");

        // return search options
        HashMap<String, NPMSearchResult> possibleSearchResults = new HashMap<>();

        for (NPMDBLabel lb : labels) {
            NPMSearchResult result = new NPMSearchResult("All pictures with label '" + lb.getReadableName() + "'", lb.getReadableName(), SearchType.LABEL_EVENT);
            possibleSearchResults.put(result.getReadableName(), result);
        }

        return possibleSearchResults;
    }
}
