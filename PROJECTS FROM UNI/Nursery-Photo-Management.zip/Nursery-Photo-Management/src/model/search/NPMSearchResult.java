package model.search;

/**
 * Search result class to store the type of the search, the keyword that
 * we have to query and a readable name
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMSearchResult {
    private String readableName;
    private NPMSearchManager.SearchType searchType;
    private String queryKeyword;

    /**
     * Constructor for the search result class to
     * store information about a search
     * @param readableName the name should be presented for the user
     * @param queryKeyword the keyword should be used for query pictures
     *                     after a search
     * @param searchType the type of the search, so we know what to query
     */
    public NPMSearchResult(String readableName, String queryKeyword, NPMSearchManager.SearchType searchType) {
        this.readableName = readableName;
        this.searchType = searchType;
        this.queryKeyword = queryKeyword;
    }

    /**
     * Getter for the readable name
     * @return the readable name, representing the search option
     */
    public String getReadableName() {
        return readableName;
    }

    /**
     * Getter for the search type
     * based on the chosen search option
     * @return the search type
     */
    public NPMSearchManager.SearchType getSearchType() {
        return searchType;
    }

    /**
     * Getter for the query keyword, so we can query for the images
     * @return the keyword
     */
    public String getQueryKeyword() {
        return queryKeyword.replace("'", "''");
    }

    @Override
    public String toString() {
        return "NPMSearchResult {" +
                "\n\treadableName: " + readableName +
                "\n\tqueryWord: " + queryKeyword +
                "\n\tsearchType: " + searchType +
                "\n}";
    }
}
