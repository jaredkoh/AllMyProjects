package model.search;

import java.util.HashMap;

/**
 * Search listener interface
 *
 * @author Team 3-B
 * @version 1.0
 */
public interface NPMSearchListener {
    /**
     * This method should notify all the observers that are registered as a
     * delegate in the class, used by the setDelegateMethod.
     * @param searchResults the current search results
     */
    public void notify(HashMap searchResults);
}
