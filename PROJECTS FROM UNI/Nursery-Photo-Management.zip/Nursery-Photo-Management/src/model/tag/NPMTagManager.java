package model.tag;

import model.NPMTuple;
import model.database.*;
import model.search.NPMSearchManager;
import view.custom.NPMBubbleTag;
import view.custom.NPMIndicatorInterface;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
   * NPMTagManager class for managing tags and labels on pictures
   * Either save them or delete from the database
 *
 * @author Team 3-B
 * @version 1.0
 */
public class NPMTagManager {
    private static NPMTagManager instance;
    public NPMIndicatorInterface indicatorInterface;

    private int numberOfSelectedImages;
    private ArrayList<String> commonTagNames;
    private HashMap<String, NPMDBTagElement> tagElements;

    /**
     * Getting the instance of the class
     * based on the Singleton design pattern
     * @return the instance of this class
     */
    public static NPMTagManager getInstance() {
        if (instance == null) instance = new NPMTagManager();
        return instance;
    }

    /**
     * Constructor for the NPMTagManager class
     * It should be only called by the getInstance method
     */
    private NPMTagManager() {
        tagElements = new HashMap<>();
        commonTagNames = new ArrayList<>();
        numberOfSelectedImages = 0;
    }

    /**
     * Method to save a new tag in the database based on the tag name and the pictures selected
      * @see model.database.NPMDBPicture
      * @param tag the tag to save (get child from it)
      * @param pictures the pictures we tagging people
      */
    public void saveNewTag(NPMBubbleTag tag, Collection<NPMDBPicture> pictures) {
        indicatorInterface.onChanged(false);
        for (NPMDBPicture picture : pictures) {
            NPMTuple<String, String> name = tag.getTagName(NPMSearchManager.SearchType.TAG_NAME);
            NPMDBChild child = (NPMDBChild) NPMDBDataManager.getInstance().query(
                    "SELECT * FROM Child WHERE first_name='" + name.getKey() + "' AND last_name='" + name.getValue() + "'", "Child").get(0);
            NPMDBTag newTag = new NPMDBTag(child, picture);

            // Set the values
            tag.setTagElement(newTag);
            tagElements.put("Tag(" + picture.id +  "" + newTag.getTupleName().getKey() + newTag.getTupleName().getValue() + ")", newTag);
        }
        indicatorInterface.onChanged(true);
    }

    /**
     * Remove a tag from an array of pictures
      * and delete it from the database
      *
     * @see model.database.NPMDBPicture
     * @see model.search.NPMSearchManager
     *
      * @param pictures the pictures we modifying the tags on
      */
    public void removeTag(NPMBubbleTag tag, Collection<NPMDBPicture> pictures) {
        indicatorInterface.onChanged(false);
        for (NPMDBPicture picture : pictures) {
            String sql = "DELETE FROM Child_Tag_Picture WHERE picture_id=" + picture.id
                    + " AND child_id IN (SELECT child_id FROM Child WHERE first_name='"
                    + tag.getTagElement().getTupleName().getKey() + "' AND last_name='"
                    + tag.getTagElement().getTupleName().getValue() + "')";
            NPMDBDataManager.getInstance().update(sql);
            tagElements.remove("Tag(" + picture.id + "" + tag.getTagElement().getTupleName().getKey() + tag.getTagElement().getTupleName().getValue() + ")", tag.getTagElement());
        }
        commonTagNames.remove(tag.getTagElement().getReadableName());
        indicatorInterface.onChanged(true);
    }

    /**
      * Save a new label in the database, which can be
      * an event or any label we want
      * @see model.database.NPMDBPicture
      * @param tag the tag which has to be saved as a label
      * @param pictures the pictures we tagging the labels on
      */
    public void saveNewLabel(NPMBubbleTag tag, Collection<NPMDBPicture> pictures) {
        indicatorInterface.onChanged(false);
        for (NPMDBPicture picture : pictures) {
            String name = tag.getTagName(NPMSearchManager.SearchType.LABEL_EVENT).getKey();
            NPMDBLabel newTag = new NPMDBLabel(name, picture);

            // Set the values
            tag.setTagElement(newTag);
            tagElements.put("Label(" + picture.id + "" + newTag.getTupleName().getKey() + ")", newTag);
        }
        indicatorInterface.onChanged(true);
    }

    /**
      * Remove a label from a picture or an arrays of picture
      * and save the changes in the database
      *
     * @see model.database.NPMDBPicture
      *
     * @param pictures the array of the picture we modifying
      */
    public void removeLabel(NPMBubbleTag tag, Collection<NPMDBPicture> pictures) {
        indicatorInterface.onChanged(false);
        for (NPMDBPicture picture : pictures) {
            String sql = "DELETE FROM Picture_Label WHERE label_name='" + tag.getTagElement().getReadableName() + "' AND picture_id=" + picture.id;
            NPMDBDataManager.getInstance().update(sql);
            tagElements.remove("Label(" + picture.id + "" + tag.getTagElement().getTupleName().getKey() + ")", tag.getTagElement());
        }
        commonTagNames.remove(tag.getTagElement().getReadableName());
        indicatorInterface.onChanged(true);
    }

    /**
     * Save description into the database, which is used for
     * observations wrote by the user
     *
     * @see model.database.NPMDBPicture
     *
     * @param description the string of the description
     * @param pictures the collection of pictures we
     *                 want to tag the description
     */
    public void saveDescription(String description, Collection<NPMDBPicture> pictures) {
        indicatorInterface.onChanged(false);
        for (NPMDBPicture picture : pictures) {
            if (picture.comment == null || !picture.comment.equals(description)) {
                picture.comment = description;
                picture.saveEntity();
            }
        }
        indicatorInterface.onChanged(true);
    }

    /**
     * Save date into the database for the selected images
     *
     * @see model.database.NPMDBPicture
     *
     * @param date the date user selected
     * @param pictures the selected pictures
     */
    public void saveDate(Date date, Collection<NPMDBPicture> pictures) {
        indicatorInterface.onChanged(false);
        for (NPMDBPicture picture : pictures) {
            if (!picture.date.equals(date)) {
                picture.date = date;
                picture.saveEntity();
            }
        }
        indicatorInterface.onChanged(true);
    }

    /**
     * Save room into the database for the selected images
     *
     * @see model.database.NPMDBPicture
     * @see model.database.NPMDBRoom
     *
     * @param room the selected room to save
     * @param pictures the selected pictures we are modifying
     */
    public void saveRoom(NPMDBRoom room, Collection<NPMDBPicture> pictures) {
        indicatorInterface.onChanged(false);
        for (NPMDBPicture picture : pictures) {
            if (!picture.room.roomName.equals(room.roomName)) {
                picture.room = room;
                picture.saveEntity();
            }
        }
        indicatorInterface.onChanged(true);
    }

    /**
     * Determine if the selected images have multiple data
     * or not. check date, room and description. If multiple date presented,
     * then show the appropriate string
     *
     * @param pictures the selected pictures by the user
     *
     * @return the hash map contains the strings to be presented
     *         date - date string to present
     *         description - description string to present
     *         room - room string to present (can be parsed to integer)
     */
    public HashMap<String, Boolean> isMultipleData(Collection<NPMDBPicture> pictures) {
        DateFormat df = new SimpleDateFormat("yyyyMMdd");
        HashMap<String, Boolean> toReturn = new HashMap<>();

        int isMultipleDate = 0;
        int isMultipleDescription = 0;
        int isMultipleRoom = 0;

        String date = df.format(((NPMDBPicture)pictures.toArray()[0]).date);
        String roomName = ((NPMDBPicture)pictures.toArray()[0]).room.roomName;
        String description = ((NPMDBPicture)pictures.toArray()[0]).comment;

        for (NPMDBPicture picture : pictures) {
            if ((picture.date != null && isMultipleDate == 0 && !df.format(picture.date).equals(date))) ++isMultipleDate;
            if ((picture.comment != null && isMultipleDescription == 0 && !picture.comment.equals(description))) ++isMultipleDescription;
            if ((picture.room != null && isMultipleRoom == 0 && !picture.room.roomName.equals(roomName))) ++isMultipleRoom;
        }

        // Fill up hashMap
        toReturn.put("date", isMultipleDate != 0);
        toReturn.put("description", isMultipleDescription != 0);
        toReturn.put("room", isMultipleRoom != 0);

        return toReturn;
    }

    /**
     * Get common tags and labels the can be show in the ui
     * based on the images selected.
     *
     * @param id       the current picture id we are selected at the last time
     *                 so we can compare to the current tags
     * @param isRemove true if the image is selected on the ui
     *                 false if image is deselected on the gui
     * @return an array of tags that should be displayed on the UI
     */
    public ArrayList<NPMDBTagElement> getCommonTagsAndLabels(long id, boolean isRemove) {
        ArrayList<NPMDBTagElement> commonTagsAndLabels = new ArrayList<>();
        // temp array for just the names
        ArrayList<String> tmp = new ArrayList<>();

        if (numberOfSelectedImages == 1) {
            for (NPMDBTagElement element : tagElements.values()) {
                commonTagsAndLabels.add(element);
                tmp.add(element.getReadableName());
            }
        } else {
            if (isRemove) {
                // deselecting images, so we should recheck the tags
                HashMap<String, Integer> recheck = new HashMap<>();
                for (NPMDBTagElement element : tagElements.values()) {
                    Object o = recheck.get(element.getReadableName());
                    int currentCount = o == null ? 0 : Integer.parseInt(o.toString());
                    recheck.put(element.getReadableName(), ++currentCount);

                    if (currentCount == numberOfSelectedImages) {
                        commonTagsAndLabels.add(element);
                        tmp.add(element.getReadableName());
                    }
                }
            } else {
                // Selecting new pictures, so use the current common tag array
                for (String key : tagElements.keySet()) {
                    NPMDBTagElement element = tagElements.get(key);
                    if (commonTagNames.contains(element.getReadableName())
                            && (key.equals("Tag(" + id +  "" + element.getTupleName().getKey() + element.getTupleName().getValue() + ")")
                            || key.equals("Label(" + id +  "" + element.getTupleName().getKey() + ")"))) {
                        commonTagsAndLabels.add(element);
                        tmp.add(element.getReadableName());
                    }
                }
            }
        }

        commonTagNames.clear();
        commonTagNames.addAll(tmp);

        return commonTagsAndLabels;
    }

    /**
     * Get the number of unique tags and labels based on
     * the selected images. If there is more then one image
     * selected there might might be tags or labels which is not
     * so in this case we return the number of those tags/labels to show the user
     * there is something
     *
     * @see model.database.NPMDBTagElement
     * @see model.database.NPMDBLabel
     * @see model.database.NPMDBTag
     *
     * @return a hash map of the unique tags and labels
     *         "tag" - number of unique tags (Integer)
     *         "label" - number of unique labels (Integer)
     */
    public HashMap<String, Integer> numberOfUniqueElements() {
        HashMap<String, NPMDBTagElement> uniqueElements = new HashMap<>();
        int numberOfTags = 0;
        int numberOfLabels = 0;

        for (NPMDBTagElement element : tagElements.values()) {
            NPMDBTagElement oldValue =  uniqueElements.put(element.getReadableName(), element);
            if (element.getClass().equals(NPMDBTag.class) && oldValue == null) ++numberOfTags;
            else if (element.getClass().equals(NPMDBLabel.class) && oldValue == null) ++numberOfLabels;
        }

        HashMap<String, Integer> toReturn = new HashMap<>();
        toReturn.put("tag", numberOfTags);
        toReturn.put("label", numberOfLabels);
        return toReturn;
    }

    /**
      * Load all the child tags from the database to show them
      * when a user selects one or more tags. It will return all
     * the children that are tagged on those images
      *
     * @see model.database.NPMDBTagElement
     *
      * @param picture the picture we want to see the tags on
      * @return a map of the picture id and the tag elements on the UI
      */
    public void loadElementsFromDatabase(NPMDBPicture picture) {
        String tagSQL = "SELECT * FROM Child_Tag_Picture WHERE picture_id=" + picture.id;
        ArrayList<NPMDBTag> tags = NPMDBDataManager.getInstance().query(tagSQL, "Tag");
        for (NPMDBTag tag : tags) {
            tagElements.put("Tag(" + tag.picture.id +  "" + tag.getTupleName().getKey() + tag.getTupleName().getValue() + ")", tag);
        }

        String labelSQL = "SELECT * FROM Picture_Label WHERE picture_id=" + picture.id;
        ArrayList<NPMDBLabel> labels = NPMDBDataManager.getInstance().query(labelSQL, "Label");
        for (NPMDBLabel label : labels) {
            tagElements.put("Label(" + label.picture.id +  "" + label.getTupleName().getKey() + ")", label);
        }
        ++numberOfSelectedImages;
    }

    /**
      * Remove all the labels and tags from the hashMap
     * that is associated with this particular image
      * @see model.database.NPMDBTagElement
      * @param picture the picture we want to use to remove the labels/tags
     *                from the UI
      * @return a map of the picture id and the tag elements still on the UI
     */
    public void removeElementsFromUI(NPMDBPicture picture) {
        Iterator it = tagElements.entrySet().iterator();

        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry)it.next();
            NPMDBTagElement element = (NPMDBTagElement)pair.getValue();

            if (tagElements.containsKey("Tag(" + picture.id +  "" + element.getTupleName().getKey() + element.getTupleName().getValue() + ")")
                    || tagElements.containsKey("Label(" + picture.id +  "" + element.getTupleName().getKey() + ")")) {
                if (element.getClass().equals(NPMDBTag.class)) {
                    if  (((NPMDBTag)element).picture.id == picture.id) it.remove();
                } else {
                    if  (((NPMDBLabel)element).picture.id == picture.id) it.remove();
                }
            }
        }
        --numberOfSelectedImages;
    }

    /**
     * Clear all the currently load tags and labels
     * so we can clear the UI
     */
    public void clear() {
        tagElements.clear();
		numberOfSelectedImages = 0;
        commonTagNames.clear();
    }
}