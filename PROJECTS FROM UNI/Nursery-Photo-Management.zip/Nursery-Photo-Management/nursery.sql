CREATE TABLE IF NOT EXISTS Child (
    child_id integer NOT NULL PRIMARY KEY AUTOINCREMENT,
    first_name varchar(255) NOT NULL,
    last_name varchar(255) NOT NULL,
    key_worker varchar(255) NOT NULL,
    active integer NOT NULL
);
CREATE TABLE IF NOT EXISTS Child_Tag_Picture (
    tag_id integer NOT NULL PRIMARY KEY AUTOINCREMENT,
    child_id integer NOT NULL,
    picture_id integer NOT NULL,
    FOREIGN KEY (child_id) REFERENCES Child (child_id),
    FOREIGN KEY (picture_id) REFERENCES Picture (picture_id)
);
CREATE TABLE IF NOT EXISTS Picture (
    picture_id integer NOT NULL PRIMARY KEY,
    path varchar(255) NOT NULL,
    room_id integer NOT NULL,
    date integer NOT NULL,
    comment text,
    FOREIGN KEY (room_id) REFERENCES Picture_Room (room_id)
);
CREATE TABLE IF NOT EXISTS Picture_Label (
    label_id integer NOT NULL PRIMARY KEY AUTOINCREMENT,
    label_name varchar(255) NOT NULL,
    picture_id integer NOT NULL,
    FOREIGN KEY (picture_id) REFERENCES Picture (picture_id)
);
CREATE TABLE IF NOT EXISTS Picture_Room (
    room_id integer NOT NULL PRIMARY KEY AUTOINCREMENT,
    room_name varchar(255) NOT NULL
);
CREATE TABLE IF NOT EXISTS Settings (
    tutorial_id integer NOT NULL,
    theme_id integer NOT NULL
);
INSERT INTO Picture_Room (room_id, room_name) VALUES (1, 'Main Room');
INSERT INTO Picture_Room (room_id, room_name) VALUES (2, 'Baby Room');
INSERT INTO Picture_Room (room_id, room_name) VALUES (3, 'Garden');
INSERT INTO Picture_Room (room_id, room_name) VALUES (4, 'Other');
INSERT INTO Settings (tutorial_id, theme_id) VALUES (0, 1);
